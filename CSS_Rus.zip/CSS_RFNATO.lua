--[[
Боевое десантирование войск и тылового обеспечения
Позволяет вертолетам и C130 перевозить личный состав внутри салона, а вертолетам — доставлять на поле боя подразделения материально-технического обеспечения и транспортные средства с помощью подвесных контейнеров.
без необходимости во внешних модах.
Поддерживает все исходные функции CTTS, такие как автоматическая загрузка и выгрузка войск ИИ, а также групповой респаун и предварительная загрузка войск в юниты.
Поддерживает развертывание системы автоматического определения местоположения в полевых условиях

    See https://github.com/ciribob/DCS-CTLD for a user manual and the latest version

	Скрипт модифицирован:
    автор - ИркутЪ 
    https://boosty.to/irkutvrn
 ]]

ctld = {} -- НЕ УДАЛЯЙТЕ!

--- Идентификатор. С этого начинается весь вывод в DCS.log
ctld.Id = "CTLD - "

--- Версия.
ctld.Version = "01"

-- уровень отладки, специфичный для этого модуля
ctld.Debug = false
-- уровень трассировки, специфичный для этого модуля
ctld.Trace = false

ctld.alreadyInitialized = false -- если true, ctld.initialize() не будет выполняться

-- ************************************************************************
-- *********************  КОНФИГУРАЦИЯ ПОЛЬЗОВАТЕЛЯ ******************************
-- ************************************************************************
ctld.staticBugWorkaround = false -- В DCS была ошибка, из-за которой уничтожение статичных объектов приводило к сбою.  Если это повторится, установите значение TRUE

ctld.disableAllSmoke = false -- если установлено значение false, вы можете загружать ящики с помощью меню F10, не наводя курсор... Только если вы не используете настоящие ящики!

ctld.hoverPickup = true -- Если установлено значение false, вы можете загружать ящики через меню F10, не наводя курсор... Только если вы не используете настоящие ящики!

ctld.enableCrates = true -- если значение равно false, Хелис не сможет создавать или распаковывать ящики, поэтому будет работать в обычном режиме CTTS
ctld.slingLoad = false -- если значение равно false, ящики можно использовать БЕЗ строповки, зависнув над ящиком и имитируя строповку, но не учитывая вес...
-- При строповке могут возникать ошибки, приводящие к сбоям. В этом случае установите для slingLoad значение false
-- чтобы использовать другой метод.
-- Установите для staticBugFix значение FALSE, если используете set ctld.slingLoad со значением TRUE

ctld.maxExtractDistance = 125 -- максимальное расстояние от машины до войск, чтобы можно было провести групповую эвакуацию
ctld.maximumDistanceLogistic = 200 -- максимальное расстояние от машины до войск, чтобы можно было провести групповую эвакуацию
ctld.maximumSearchDistance = 4000 -- максимальное расстояние, на котором войска могут искать врага
ctld.maximumMoveDistance = 2000 -- Максимальное расстояние, на которое войска могут отойти от точки падения, если поблизости нет противника
ctld.autoGroundSearchRange = 6450 -- дальность поиска наземного противника после активации
ctld.autoGroundSearchDelay = 10 -- поиск цели через 10 секунд после появления группы
ctld.autoReconCheckInterval = 10 -- проверка состояния уже найденной цели наводчиком
ctld.jtacReconSearchRange = 6500 -- дальность поиска противника пешим ПАН
ctld.jtacReconStandOffRange = 3500 -- первый рубеж сближения пешего ПАН
ctld.infantryAssaultSearchRange = 6500
ctld.infantryAssaultStandOffRange = 50
-- Смешанная группа с РПГ/пулемётами в DCS начинает бежать от 14 км/ч;
-- 13 км/ч движок переводит в медленный шаг около 4–5 км/ч.
ctld.infantryMarchSpeed = 14 / 3.6 -- максимальный темп пехоты, м/с
ctld.generatedCombatGroups = {}
ctld.suppressedCombatLossGroups = {}
ctld.generatedCombatEventHandler = {}
-- Названия для единственного сообщения о первом огневом контакте группы.
ctld.combatContactUnitNames = {
    ["CHAP_BMPT"] = "БМ Терминатор",
    ["BRDM-2_malyutka"] = "БР Малютка",
    ["CHAP_T90M"] = "Т-90М",
    ["CHAP_M1296"] = "БТР Dragoon",
    ["M1134 Stryker ATGM"] = "ПТРК Stryker",
    ["ZTZ96B"] = "Танк ZTZ",
}
ctld.airDefenseContactUnitTypes = {
    ["2S6 Tunguska"] = true, ["Tor 9A331"] = true,
    ["ZSU-23-4 Shilka"] = true, ["Osa 9A33 ln"] = true,
    ["CHAP_PantsirS1"] = true, ["Kub 2P25 ln"] = true,
    ["SA-11 Buk LN 9A310M1"] = true,
    ["Patriot ln"] = true, ["CHAP_IRISTSLM_LN"] = true,
    ["M6 Linebacker"] = true, ["CHAP_PGZ09"] = true,
    ["HQ-7_LN_SP"] = true, ["CHAP_Centurion_CRAM"] = true,
    ["Roland ADS"] = true,
}
ctld.autoArtillerySearchRange = 6450 -- дальность поиска цели артиллерией после активации
ctld.autoMortarSearchRange = 6450 -- дальность поиска цели миномётной батареей после активации
ctld.autoArtilleryMinimumRange = 2900 -- рубеж огня РЗО: после достижения вести огонь по цели
ctld.autoArtilleryCheckInterval = 10
ctld.m270AmmoCheckInterval = 10
ctld.m270PostAmmoDeleteDelay = 120
ctld.autoSupportCheckDelay = 10 -- проверка союзников для машин снабжения после активации
ctld.autoSupportSearchRange = 2200 -- дальность поиска союзных сил для Урал-375/БК и АТЗ-10
ctld.autoSupportStandOffRange = 120
ctld.autoAttackUnitTypes = {
    ["CHAP_BMPT"] = true,
    ["BRDM-2_malyutka"] = true,
    ["CHAP_T90M"] = true,
    ["T-80UD"] = true,
    -- NATO
    ["CHAP_M1296"] = true,
    ["M1134 Stryker ATGM"] = true,
    ["ZTZ96B"] = true,
    ["M6 Linebacker"] = true,
    ["CHAP_PGZ09"] = true,
}

ctld.autoAdvanceUnitTypes = {
    ["CHAP_BMPT"] = true,
    ["BRDM-2_malyutka"] = true,
    ["CHAP_T90M"] = true,
    ["T-80UD"] = true,
    -- NATO
    ["CHAP_M1296"] = true,
    ["M1134 Stryker ATGM"] = true,
    ["ZTZ96B"] = true,
}
ctld.standardActiveUnitTypes = {
    ["CHAP_PantsirS1"] = true,
    ["Kub 2P25 ln"] = true,
    ["Kub 1S91 str"] = true,
    ["SA-11 Buk LN 9A310M1"] = true,
    ["SA-11 Buk SR 9S18M1"] = true,
    ["SA-11 Buk CC 9S470M1"] = true,
    -- NATO ПВО и радиолокационные комплексы: активировать ИИ и штатную оборону.
    ["FPS-117"] = true,
    ["Patriot cp"] = true,
    ["Patriot EPP"] = true,
    ["Patriot ECS"] = true,
    ["Patriot ln"] = true,
    ["Patriot AMG"] = true,
    ["Patriot str"] = true,
    ["CHAP_IRISTSLM_STR"] = true,
    ["CHAP_IRISTSLM_LN"] = true,
    ["CHAP_IRISTSLM_CP"] = true,
    ["HQ-7_LN_SP"] = true,
    ["HQ-7_STR_SP"] = true,
    ["Roland Radar"] = true,
    ["Roland ADS"] = true,
    ["M6 Linebacker"] = true,
    ["CHAP_PGZ09"] = true,
    ["CHAP_Centurion_CRAM"] = true,
}
ctld.autoGroundAttackProfiles = {}
ctld.autoArtilleryUnitTypes = {
    ["2B11 mortar"] = true,
    ["CHAP_TOS1A"] = true,
    ["Grad-URAL"] = true,
    ["SAU Msta"] = true,
    -- NATO: М270, как Град/Солнцепёк, получает координаты цели без визуального контакта.
    ["MLRS"] = true,
    ["M-109"] = true,
}
ctld.autoArtilleryProfiles = {
    -- РЗО получают координаты цели без визуального контакта, выдвигаются
    -- до рубежа огня и накрывают район цели.
    -- Солнцепёк и Град сохраняют исходную скорость маршрута 50 м/с.
    ["CHAP_TOS1A"] = { searchRange = 6450, fireRange = 3000, requiresVisual = false, moveSpeed = 50 },
    ["Grad-URAL"] = { searchRange = 6450, fireRange = 3000, requiresVisual = false, moveSpeed = 50 },
    -- M270 не применяет ракеты с ближней дистанции: для него задана
    -- отдельная зона огня 11-30 км. На меньшей дистанции машина отходит
    -- на рубеж пуска, вместо безрезультатной команды FireAtPoint.
    ["MLRS"] = { searchRange = 30000, fireRange = 30000, minimumFireRange = 11000, requiresVisual = false, moveSpeed = 16.6666666666667 },
    -- Paladin получает координаты цели, выходит на рубеж огня и работает
    -- FireAtPoint без обязательного визуального контакта.
    ["M-109"] = { searchRange = 6450, fireRange = 3000, requiresVisual = false, moveSpeed = 10 },
    -- Миномётная батарея работает с позиции развёртывания: получает
    -- координаты противника и ведёт огонь без требования прямой видимости.
    ["mortar"] = { searchRange = 6500, fireRange = 6500, requiresVisual = false },
}
ctld.autoReconUnitTypes = {
    ["CHAP_UralTyphoon"] = true,
    ["CHAP_Titan"] = true,
    ["ПАН разведчик"] = true,
    ["CHAP_M1130"] = true,
}
ctld.autoSupportUnitTypes = {
    ["Ural-375"] = true, -- Урал-375-БП
    ["ATZ-10"] = true,
    ["CHAP_M1083"] = true,
    ["M978 HEMTT Tanker"] = true,
}

ctld.minimumDeployDistance = 1000 -- минимальное расстояние от дружественной пикап-зоны, где можно разместить ящик

ctld.numberOfTroops = 10 -- максимальный размер группы, помещающейся в вертолёт.
ctld.enableFastRopeInsertion = true -- позволяет сбрасывать войска с помощью фалдинга!
ctld.fastRopeMaximumHeight = 18.28 -- в метрах, что составляет 60 футов (не для спуска по веревке) безопасной высоты!

ctld.aaLaunchers = 3 -- контролирует, сколько пусковых установок добавить в kub/buk при его порождении.
ctld.hawkLaunchers = 8 -- определяет, сколько пусковых установок добавить к ястребу при его порождении.

ctld.spawnRPGWithCoalition = true --Порождает дружественный отряд RPG с коалиционными силами
ctld.spawnStinger = false -- Порождает солдата стингера/иглы с группой из 6 или более солдат!

ctld.crateWaitTime = 120 -- время ожидания в секундах до появления следующего ящика
ctld.autoUnpackDelay = 30 -- автоматическая распаковка выгруженного ящика с техникой

ctld.forceCrateToBeMoved = true -- Ящик нужно хотя бы раз поднять и переместить, прежде чем его можно будет распаковать. Это помогает уменьшить количество спама с ящикам

-- Моделирование конфигурации стропового груза

ctld.minimumHoverHeight = 3.5 -- Наименьшая допустимая высота для наведения ящика
ctld.maximumHoverHeight = 15.0 -- Наибольшая допустимая высота для нависания ящика
ctld.maxDistanceFromCrate = 12.0 -- Максимальное расстояние от ящика при наведении
ctld.hoverTime = 5 -- Время удержания ховера над ящиком для загрузки в секундах
-- конец настройки имитации нагрузки на стропы

-- Минимальный остаток прочности вертолёта для выгрузки десанта или контейнера.
-- 0.20 = 20%. Меняется только это число: например, 0.50 запретит выгрузку
-- при повреждении борта более чем на 50%. Не влияет на F10-меню и загрузку.
ctld.minimumTransportLifeForUnload = 0.20

-- КОНФИГУРАЦИЯ СИСТЕМЫ АВАРИЙНОЙ ЧИСТКИ --
-- Устанавливает ограничение на количество активных систем аварийной опорожнизации, которые можно построить для RED.
-- Система считается активной, если она полностью функциональна и все ее части
-- Если система частично разрушена, она не учитывается при подсчете общего количества
-- При достижении этого лимита игрок по-прежнему сможет получать ящики для системы аварийной опорожнизации, но не сможет
-- их распаковывать
ctld.AASystemLimitRED = 20 -- Предел со стороны красных

ctld.AASystemLimitBLUE = 20 -- Предел со стороны СИНИХ

--КОНЕЦ НАСТРОЕК СИСТЕМ ПВО --

-- ***************** НАСТРОЙКИ JTAC *****************

ctld.JTAC_MAX_ACTIVE_PER_COALITION = 6 -- ПАН всех типов: активные, в ящиках и на борту

ctld.JTAC_dropEnabled = true -- разрешить JTAC Crate появляться из меню F10

ctld.JTAC_maxDistance = 6450 -- дальность визуального поиска и подсветки целей ПАН

ctld.JTAC_smokeOn_RED = false -- дым ставится только командой F10 «Обозначить цель.»
ctld.JTAC_smokeOn_BLUE = false -- дым ставится только командой F10 «Обозначить цель.»

ctld.JTAC_smokeColour_RED = 4 -- Цвет дыма с КРАСНОЙ стороны -- Зеленый = 0, Красный = 1, Белый = 2, Оранжевый = 3, Синий = 4
ctld.JTAC_smokeColour_BLUE = 1 -- Цвет дыма с СИНЕЙ стороны -- Green = 0 , Red = 1, White = 2, Orange = 3, Blue = 4

ctld.JTAC_smokeOffset_x = 0.0 -- расстояние в направлении X от цели до дыма (метры)
ctld.JTAC_smokeOffset_y = 2.0 -- distance in the Y direction from target to smoke (meters)
ctld.JTAC_smokeOffset_z = 0.0 -- distance in the z direction from target to smoke (meters)

ctld.JTAC_jtacStatusF10 = true -- включает меню F10 JTAC Status

ctld.JTAC_location = true -- показывает местоположение цели в сообщении JTAC
ctld.location_DMS = false -- показывает координаты как градусы-минуты-секунды вместо градусов-десятичных минут

ctld.JTAC_lock = "all" -- "vehicle" OR "troop" OR "all" заставляет JTAC блокировать только транспортные средства, войска или все наземные подразделения.

ctld.JTAC_allowStandbyMode = true -- если true, позволяет игрокам включать/выключать освещение
ctld.JTAC_laseSpotCorrections = true -- Если это так, то в меню каждого JTAC будет доступна специальная опция (включить/выключить), чтобы попытаться вести цель, принимая во внимание текущие условия ветра и скорость цели (особенно полезно против движущейся тяжелой брони).
ctld.JTAC_allowSmokeRequest = true -- если true, позволяет игрокам запрашивать дым на цели (временно)
ctld.JTAC_allow9Line = true -- если true, позволяет игрокам запрашивать 9Line (индивидуальный) для определенной цели JTAC

-- Точки погрузки пехоты: trigger zone pickzoneRED1...30 / pickzoneBLUE1...30.
ctld.pickupZones = {}
for _index = 1, 30 do
    table.insert(ctld.pickupZones, { "pickzoneRED" .. _index, "none", -1, "yes", 1 })
    table.insert(ctld.pickupZones, { "pickzoneBLUE" .. _index, "none", -1, "yes", 2 })
end


-- CTLD доступен всем игрокам на разрешённых типах вертолётов, а не по именам МТО.
ctld.transportPilotNames = {}
ctld.playerTransportTypes = {
    ["CH-47Fbl1"] = true, ["CH-47F"] = true,
    ["UH-1H"] = true, ["Mi-8MT"] = true, ["Mi-8MTV2"] = true,
    ["OH-58D"] = true, ["OH58D"] = true, ["Mi-24P"] = true,
    ["SA342M"] = true, ["SA342L"] = true, ["SA342Mistral"] = true, ["SA342Minigun"] = true,
}

-- Статические объекты логистики соответствуют одноимённым pickzoneRED/BLUE;
-- должны называться logisticRED1...30 и logisticBLUE1...30.
ctld.logisticUnits = {}
for _index = 1, 30 do
    table.insert(ctld.logisticUnits, "logisticRED" .. _index)
    table.insert(ctld.logisticUnits, "logisticBLUE" .. _index)
end

-- ************** НАСТРОЙКА МАКСИМАЛЬНОГО ЧИСЛА БОЙЦОВ ДЛЯ ТИПОВ ЮНИТОВ ******************

-- Укажите имя юнита, для которого нужно ограничить размер перевозимой группы.
-- i.e
-- ["UH-1H"] = 10,
--
-- Ограничит UH-1 перевозкой групп размером не более 10 человек.
-- Имя юнита должно быть точным, иначе настройка не сработает.

ctld.unitLoadLimits = {

    -- Уберите -- ниже, чтобы включить настройку.
    -- ["SA342Mistral"] = 4,
    -- ["SA342L"] = 4,
    -- ["SA342M"] = 4,

}


-- ************** ДОСТУПНЫЕ ДЕЙСТВИЯ ДЛЯ ТИПОВ ЮНИТОВ ******************

-- Укажите имя юнита, для которого нужно ограничить действия.
-- ВАЖНО: юнит должен быть указан в списке transportPilotNames выше.
-- Можно использовать вместе с ограничением размера группы.
-- По умолчанию доступны и ящики, и пехота, если ниже не задано иное.
-- i.e
-- ["UH-1H"] = {crates=true, troops=false},
--
-- Ограничит UH-1 перевозкой только ЯЩИКОВ, без ПЕХОТЫ.
--
-- ["SA342Mistral"] = {crates=fales, troops=true},
-- Разрешит Mistral Gazelle перевозить только ящики, без пехоты.

ctld.unitActions = {
    -- Лёгкие/ударные вертолёты перевозят только пехоту.
    ["OH-58D"] = {crates=false, troops=true},
    ["OH58D"] = {crates=false, troops=true},
    ["Mi-24P"] = {crates=false, troops=true},
    ["SA342M"] = {crates=false, troops=true},
    ["SA342L"] = {crates=false, troops=true},
    ["SA342Mistral"] = {crates=false, troops=true},
    ["SA342Minigun"] = {crates=false, troops=true},

}

-- Ка-50 и Ка-50 III имеют категорию вертолёта в DCS, однако для F10
-- используют только меню JTAC, как самолёты.
ctld.jtacOnlyAircraftTypes = {
    ["Ka-50"] = true,
    ["Ka-50_3"] = true,
}

-- ************** РАСЧЁТ ВЕСА ГРУПП ПЕХОТЫ ******************

-- Вес группы пехоты рассчитывается по ролям бойцов и весу их снаряжения.
-- Вес каждого бойца составляет 90–120% от ctld.SOLDIER_WEIGHT; все несут рюкзак и шлем (ctld.KIT_WEIGHT).
-- Обычные бойцы несут винтовку и боеприпасы (ctld.RIFLE_WEIGHT).
-- Бойцы ПВО несут ПЗРК (ctld.MANPAD_WEIGHT).
-- Противотанковые бойцы несут РПГ и ракету (ctld.RPG_WEIGHT).
-- Пулемётчики несут групповой пулемёт и 200 патронов (ctld.MG_WEIGHT).
-- JTAC несут лазерный целеуказатель, радиостанцию и бинокль (ctld.JTAC_WEIGHT).
-- Миномётный расчёт несёт миномёт и несколько мин (ctld.MORTAR_WEIGHT).

ctld.SOLDIER_WEIGHT = 80 -- kg, will be randomized between 90% and 120%
ctld.KIT_WEIGHT = 20 -- kg
ctld.RIFLE_WEIGHT = 5 -- kg
ctld.MANPAD_WEIGHT = 18 -- kg
ctld.RPG_WEIGHT = 7.6 -- kg
ctld.MG_WEIGHT = 10 -- kg
ctld.MORTAR_WEIGHT = 26 -- kg
ctld.JTAC_WEIGHT = 15 -- kg

-- ************** ГРУППЫ ПЕХОТЫ ДЛЯ ЗАХВАТА ******************
-- Типы бойцов
-- inf — обычная пехота.
-- mg is M249
-- at is RPG-16
-- aa — боец со Stinger или «Иглой».
-- mortar — расчёт миномёта 2Б11.
-- jtac - солдат JTAC, который будет использовать JTACAutoLase
-- Для работы необходимо задать имя группы.
-- Можно дополнительно задать коалицию, чтобы ограничить группу одной стороной.
-- Для side: 2 — синие, 1 — красные.
ctld.loadableGroups = {
    {name = "Штурмовой взвод", inf = 6, mg = 2, at = 2 }, -- создаст загружаемую группу с 6 пехотинцами, 2 MG и 2 противотанковыми орудиями для обеих коалиций
    {name = "Взвод ПЗРК", mg = 2, aa = 3  },
    {name = "Противотанковый расчет", mg = 2, at = 4 },
    {name = "Минометная батарея", mortar = 6 },
    {name = "ПАН разведчик", jtac = 1 }, -- создаст загружаемую группу с одним солдатом JTAC для обеих коалиций
    -- {name = "Mortar Squad Red", inf = 2, mortar = 5, side =1 }, --сделает группу доступной только для RED
}

-- ************** СОЗДАВАЕМЫЕ ЯЩИКИ ******************
-- Вес каждого ящика должен быть уникальным: по нему определяется, какой юнит появится
-- при развёртывании груза.
--
ctld.spawnableCrates = {
    -- имя подменю F10 для создания ящиков.
    ["Техника ПВО"] = {
        { weight = 645, desc = "ЗПРК Тунгуска", unit = "2S6 Tunguska"}, 
        { weight = 679, desc = "ЗРК ТОР", unit = "Tor 9A331"},
        { weight = 680, desc = "ЗСУ 234 Шилка", unit = "ZSU-23-4 Shilka"},
        { weight = 557, desc = "ЗРК Оса БМ", unit = "Osa 9A33 ln" },
        { weight = 405, desc = "ЗРК Панцирь", unit = "CHAP_PantsirS1", cratesRequired = 2 },
    },
    ["Техника АБТС"] = {
        --краты, которые вы можете ИЗМЕНЯТЬ
        -- вес в КГ
        -- Desc - описание в МЕНЮ F10
        -- unit - название модели порождаемого блока
        -- cratesRequired - если задано, то для создания юнита необходимо, чтобы в радиусе 100 м друг от друга находилось столько-то ящиков одного типа
        -- side - опционально, но 2 - синие, а 1 - красные.
        -- не используйте эту опцию с ящиками HAWK
            -- шилка
      
        { weight = 610, desc = "БМ Терминатор", unit = "CHAP_BMPT" },
        { weight = 615, desc = "БР Малютка", unit = "BRDM-2_malyutka" },

        { weight = 725, desc = "ПАН Титан", unit = "CHAP_Titan" }, -- used as jtac and unarmed, not on the crate list if JTAC is disabled

        { weight = 970, desc = "РЗО Солнцепёк", unit = "CHAP_TOS1A", cratesRequired = 2 },

        { weight = 850, desc = "РСЗО Град", unit = "Grad-URAL", cratesRequired = 2 },

        { weight = 652, desc = "Урал-375`БК", unit = "Ural-375" },

        { weight = 611, desc = "АТЗ-10", unit = "ATZ-10" },

        { weight = 990, desc = "ОБТ Т-80", unit = "T-80UD" },

    },
    ["Батарея КУБ"] = {
        -- СИСТЕМА КУБ
        { weight = 560, desc = "КУБ ПУ 2П25", unit = "Kub 2P25 ln" },
        { weight = 565, desc = "КУБ CУРН 1С91", unit = "Kub 1S91 str" },
        { weight = 570, desc = "КУБ ремкомплект", unit = "KUB Repair" },
        -- Конец системы КУБ
    },
    ["Батарея БУК"] = {
        -- Система БУК
        { weight = 575, desc = "БУК СОУ", unit = "SA-11 Buk LN 9A310M1"},
        { weight = 580, desc = "БУК Радар", unit = "SA-11 Buk SR 9S18M1"},
        { weight = 585, desc = "БУК КП", unit = "SA-11 Buk CC 9S470M1"},
        { weight = 590, desc = "БУК ремкомплект", unit = "BUK Repair"},
        -- Конец системы БУК
    },
}

-- Порядок категорий в F10 задаётся явно: pairs() не гарантирует порядок пунктов.
ctld.crateMenuOrderRED = { "Техника ПВО", "Техника АБТС", "Батарея КУБ", "Батарея БУК" }
ctld.crateMenuOrderBLUE = {
    "Бронетехника", "РЛС ДРЛО", "ЗРК Patriot", "Комплекс IRIS", "Техника ПВО НАТО"
}

-- Ящики NATO доступны только синей коалиции. Уникальный вес является идентификатором
-- груза CTLD; значения 1101–1129 не пересекаются с существующими ящиками РФ.
ctld.spawnableCrates["Бронетехника"] = {
    { weight = 1101, desc = "БТР Dragoon",       unit = "CHAP_M1296",              side = 2 },
    { weight = 1102, desc = "ПТРК Stryker",      unit = "M1134 Stryker ATGM",      side = 2 },
    { weight = 1103, desc = "ПТРК КМ JTAC",      unit = "CHAP_M1130",              side = 2 },
    { weight = 1104, desc = "РСЗО М270",         unit = "MLRS",                    side = 2, cratesRequired = 2 },
    { weight = 1105, desc = "САУ Paladin",       unit = "M-109",                   side = 2, cratesRequired = 2 },
    { weight = 1106, desc = "М1083/БК",          unit = "CHAP_M1083",              side = 2 },
    { weight = 1107, desc = "HEMTT/ГСМ",         unit = "M978 HEMTT Tanker",       side = 2 },
    { weight = 1108, desc = "Танк ZTZ",          unit = "ZTZ96B",                  side = 2 },
}
ctld.spawnableCrates["РЛС ДРЛО"] = {
    { weight = 1110, desc = "РЛС ДРЛО FPS",      unit = "FPS-117",                 side = 2, cratesRequired = 2 },
}
ctld.spawnableCrates["ЗРК Patriot"] = {
    { weight = 1111, desc = "Patriot ПБУ",       unit = "Patriot cp",              side = 2 },
    { weight = 1112, desc = "Patriot EPP",       unit = "Patriot EPP",             side = 2 },
    { weight = 1113, desc = "Patriot КП",        unit = "Patriot ECS",             side = 2 },
    { weight = 1114, desc = "Patriot ПУ",        unit = "Patriot ln",              side = 2 },
    { weight = 1115, desc = "Patriot РТС",       unit = "Patriot AMG",             side = 2 },
    { weight = 1116, desc = "Patriot РПН",       unit = "Patriot str",             side = 2 },
}
ctld.spawnableCrates["Комплекс IRIS"] = {
    { weight = 1120, desc = "IRIS РЛС",          unit = "CHAP_IRISTSLM_STR",       side = 2 },
    { weight = 1121, desc = "IRIS ПУ",           unit = "CHAP_IRISTSLM_LN",        side = 2 },
    { weight = 1122, desc = "IRIS МУ",           unit = "CHAP_IRISTSLM_CP",        side = 2 },
}
ctld.spawnableCrates["Техника ПВО НАТО"] = {
    { weight = 1123, desc = "ЗРК Linebacker",    unit = "M6 Linebacker",           side = 2 },
    { weight = 1124, desc = "SPAAG",             unit = "CHAP_PGZ09",              side = 2 },
    { weight = 1125, desc = "HQ-7 ПУ [2]",       unit = "HQ-7_LN_SP",              side = 2 },
    { weight = 1126, desc = "HQ-7 РЛС [2]",      unit = "HQ-7_STR_SP",             side = 2 },
    { weight = 1127, desc = "ЗАУ Centurion",     unit = "CHAP_Centurion_CRAM",     side = 2, cratesRequired = 2 },
    { weight = 1128, desc = "Roland РЛО [2]",    unit = "Roland Radar",             side = 2 },
    { weight = 1129, desc = "Roland ADS [2]",    unit = "Roland ADS",               side = 2 },
}

--- 3D-модель, используемая для отображения загружаемого ящика; по умолчанию — генератор.
ctld.spawnableCratesModel_load = {
    ["category"] = "Cargos",
    ["shape_name"] = "iso_container_cargo",
    ["type"] = "iso_container"
}

--- 3D-модель, используемая для отображения ящика на внешней подвеске; по умолчанию — ящик.
ctld.spawnableCratesModel_sling = {
    ["category"] = "Cargos",
    ["shape_name"] = "iso_container_cargo",
    ["type"] = "iso_container"
}

--[[ Заготовка для других типов грузовых контейнеров.
    ["shape_name"] = "ab-212_cargo",
    ["type"] = "uh1h_cargo" --new type for the container previously used

    ["shape_name"] = "ammo_box_cargo",
    ["type"] = "ammo_cargo",

    ["shape_name"] = "barrels_cargo",
    ["type"] = "barrels_cargo",

    ["shape_name"] = "bw_container_cargo",
    ["type"] = "container_cargo",

    ["shape_name"] = "f_bar_cargo",
    ["type"] = "f_bar_cargo",

    ["shape_name"] = "fueltank_cargo",
    ["type"] = "fueltank_cargo",

    ["shape_name"] = "iso_container_cargo",
    ["type"] = "iso_container",

    ["shape_name"] = "iso_container_small_cargo",
    ["type"] = "iso_container_small",

    ["shape_name"] = "oiltank_cargo",
    ["type"] = "oiltank_cargo",

    ["shape_name"] = "pipes_big_cargo",
    ["type"] = "pipes_big_cargo",

    ["shape_name"] = "pipes_small_cargo",
    ["type"] = "pipes_small_cargo",

    ["shape_name"] = "tetrapod_cargo",
    ["type"] = "tetrapod_cargo",

    ["shape_name"] = "trunks_long_cargo",
    ["type"] = "trunks_long_cargo",

    ["shape_name"] = "trunks_small_cargo",
    ["type"] = "trunks_small_cargo",
]]--

-- если подразделение находится в этом списке, то при развертывании оно будет преобразовано в JTAC
ctld.jtacUnitTypes = {
    "SKP", "Hummer", "CHAP_Titan", "CHAP_M1130" -- Есть некоторые странные проблемы с кодировкой, поэтому если вы напишете SKP-11, это не будет соответствовать, так как знак "-" кодируется по-другому...
}


-- **************************************************************************
-- **************** Функции редактора миссий *********************
-- **************************************************************************
-----------------------------------------------------------------
-- Создайте группу в триггере и сделайте их извлекаемыми. Использование:
-- ctld.spawnGroupAtTrigger("groupside", number, "triggerName", radius)
-- Переменные:
-- "groupSide" = "red" для России, "blue" для США
-- _number = количество создаваемых групп ИЛИ описание группы
-- "triggerName" = название триггера в редакторе миссий, разделенное запятыми
-- _searchRadius = случайное расстояние, на которое юниты будут удаляться от точки появления (при значении 0 войска останутся на месте появления — без поиска противника)
--
-- Пример: ctld.spawnGroupAtTrigger("red", 2, "spawn1", 1000)
--
-- В этом примере в указанной точке появятся 2 группы русских
-- и они будут искать противника или двигаться в случайном направлении в радиусе 1000 м
-- ИЛИ
--
-- ctld.spawnGroupAtTrigger("blue", {mg=1,at=2,aa=3,inf=4,mortar=5},"spawn2", 2000)
-- Вызывает 1 пулемёт, 2 противотанковых орудия, 3 зенитных орудия, 4 обычных солдата и 5 миномётов
--
function ctld.spawnGroupAtTrigger(_groupSide, _number, _triggerName, _searchRadius)
    local _spawnTrigger = trigger.misc.getZone(_triggerName) -- trigger to use as reference position

    if _spawnTrigger == nil then
        trigger.action.outText("CTLD.lua ERROR: Cant find trigger called " .. _triggerName, 10)
        return
    end

    local _country
    if _groupSide == "red" then
        _groupSide = 1
        _country = 0
    else
        _groupSide = 2
        _country = 2
    end

    if _searchRadius < 0 then
        _searchRadius = 0
    end

    local _pos2 = { x = _spawnTrigger.point.x, y = _spawnTrigger.point.z }
    local _alt = land.getHeight(_pos2)
    local _pos3 = { x = _pos2.x, y = _alt, z = _pos2.y }

    local _groupDetails = ctld.generateTroopTypes(_groupSide, _number, _country)

    local _droppedTroops = ctld.spawnDroppedGroup(_pos3, _groupDetails, false, _searchRadius);

    if _groupSide == 1 then
        table.insert(ctld.droppedTroopsRED, _droppedTroops:getName())
    else
        table.insert(ctld.droppedTroopsBLUE, _droppedTroops:getName())
    end
end


-----------------------------------------------------------------
-- Создаёт группу в точке Vec3 и делает её доступной для эвакуации. Использование:
-- ctld.spawnGroupAtPoint("groupside", number,Vec3 Point, radius)
-- Параметры:
-- "groupSide" = "red" для России, "blue" для США.
-- _number = количество создаваемых групп ИЛИ описание группы.
-- Vec3 Point = точка Vec3 вида {x=1,y=2,z=3}; её можно получить у юнита так: Unit.getName("Unit1"):getPoint().
-- _searchRadius = случайная дистанция движения от точки появления (0 оставит войска на месте — без поиска противника).
--
-- Пример: ctld.spawnGroupAtPoint("red", 2, {x=1,y=2,z=3}, 1000)
--
-- Этот пример создаст 2 группы российских войск в указанной точке.
-- Они будут искать противника либо случайно перемещаться в радиусе 1000 м.
-- OR
--
-- ctld.spawnGroupAtPoint("blue", {mg=1,at=2,aa=3,inf=4,mortar=5}, {x=1,y=2,z=3}, 2000)
-- Создаёт 1 пулемётчика, 2 противотанковых бойцов, 3 бойцов ПВО, 4 обычных бойца и 5 миномётных расчётов.
function ctld.spawnGroupAtPoint(_groupSide, _number, _point, _searchRadius)

    local _country
    if _groupSide == "red" then
        _groupSide = 1
        _country = 0
    else
        _groupSide = 2
        _country = 2
    end

    if _searchRadius < 0 then
        _searchRadius = 0
    end

    local _groupDetails = ctld.generateTroopTypes(_groupSide, _number, _country)

    local _droppedTroops = ctld.spawnDroppedGroup(_point, _groupDetails, false, _searchRadius);

    if _groupSide == 1 then
        table.insert(ctld.droppedTroopsRED, _droppedTroops:getName())
    else
        table.insert(ctld.droppedTroopsBLUE, _droppedTroops:getName())
    end
end


-- Предварительно загружает в транспорт пехоту или технику.
-- Заменяет любые войска, уже находящиеся на борту.
function ctld.preLoadTransport(_unitName, _number, _troops)

    local _unit = ctld.getTransportUnit(_unitName)

    if _unit ~= nil then

        -- заменит любые подразделения, уже находящиеся на борту.
        --        if not ctld.troopsOnboard(_unit,_troops)  then
        ctld.loadTroops(_unit, _troops, _number)
        --        end
    end
end


-- Непрерывно подсчитывает ящики в зоне и записывает их число в указанный флаг.
-- Это позволяет запускать действия по количеству ящиков и выводить сообщения до достижения нужного значения.
-- Передайте имя зоны и номер флага в одноразовом (НЕ непрерывном) триггере.
-- Работает как с ящиками редактора миссий, так и с созданными ящиками.
-- e.g. ctld.cratesInZone("DropZone1", 5)
function ctld.cratesInZone(_zone, _flagNumber)
    local _triggerZone = trigger.misc.getZone(_zone) -- trigger to use as reference position

    if _triggerZone == nil then
        trigger.action.outText("CTLD.lua ERROR: Cant find zone called " .. _zone, 10)
        return
    end

    local _zonePos = mist.utils.zoneToVec3(_zone)

    -- игнорировать сторону; использованный ящик не учитывается в счётчике.
    local _crateTables = { ctld.spawnedCratesRED, ctld.spawnedCratesBLUE, ctld.missionEditorCargoCrates }

    local _crateCount = 0

    for _, _crates in pairs(_crateTables) do

        for _crateName, _dontUse in pairs(_crates) do

            -- получить ящик.
            local _crate = ctld.getCrateObject(_crateName)

            -- работа с ящиками в воздухе нестабильна, поэтому при полёте проверяется высота над землёй и скорость.
            if _crate ~= nil and _crate:getLife() > 0
                    and (ctld.inAir(_crate) == false) then

                local _dist = ctld.getDistance(_crate:getPoint(), _zonePos)

                if _dist <= _triggerZone.radius then
                    _crateCount = _crateCount + 1
                end
            end
        end
    end

    -- записать значение во флаг.
    trigger.action.setUserFlag(_flagNumber, _crateCount)

    -- env.info("FLAG ".._flagNumber.." crates ".._crateCount)

    -- повторить через 5 секунд.
    timer.scheduleFunction(function(_args)

        ctld.cratesInZone(_args[1], _args[2])
    end, { _zone, _flagNumber }, timer.getTime() + 5)
end

-- ФУНКЦИЯ ДЛЯ НЕПРЕРЫВНОГО ТРИГГЕРА
-- Подсчитывает текущее количество доступных для эвакуации КРАСНЫХ и СИНИХ
-- ГРУПП в зоне и записывает значения в два флага.
-- Группа учитывается в зоне только тогда, когда её ведущий юнит находится в зоне.
-- Использование: ctld.countDroppedGroupsInZone("Имя зоны", флагСиних, флагКрасных)
function ctld.countDroppedGroupsInZone(_zone, _blueFlag, _redFlag)

    local _triggerZone = trigger.misc.getZone(_zone) -- trigger to use as reference position

    if _triggerZone == nil then
        trigger.action.outText("CTLD.lua ERROR: Cant find zone called " .. _zone, 10)
        return
    end

    local _zonePos = mist.utils.zoneToVec3(_zone)

    local _redCount = 0;
    local _blueCount = 0;

    local _allGroups = {ctld.droppedTroopsRED,ctld.droppedTroopsBLUE}
    for _, _extractGroups in pairs(_allGroups) do
        for _,_groupName  in pairs(_extractGroups) do
            local _groupUnits = ctld.getGroup(_groupName)

            if #_groupUnits > 0 then
                local _zonePos = mist.utils.zoneToVec3(_zone)
                local _dist = ctld.getDistance(_groupUnits[1]:getPoint(), _zonePos)

                if _dist <= _triggerZone.radius then

                    if (_groupUnits[1]:getCoalition() == 1) then
                        _redCount = _redCount + 1;
                    else
                        _blueCount = _blueCount + 1;
                    end
                end
            end
        end
    end
    -- записать значения во флаги.
    trigger.action.setUserFlag(_blueFlag, _blueCount)
    trigger.action.setUserFlag(_redFlag, _redCount)

    --  env.info("Groups in zone ".._blueCount.." ".._redCount)

end

-- ФУНКЦИЯ ДЛЯ НЕПРЕРЫВНОГО ТРИГГЕРА
-- Подсчитывает текущее количество доступных для эвакуации КРАСНЫХ и СИНИХ
-- ЮНИТОВ в зоне и записывает значения в два флага.

-- Использование: ctld.countDroppedUnitsInZone("Имя зоны", флагСиних, флагКрасных)
function ctld.countDroppedUnitsInZone(_zone, _blueFlag, _redFlag)

    local _triggerZone = trigger.misc.getZone(_zone) -- trigger to use as reference position

    if _triggerZone == nil then
        trigger.action.outText("CTLD.lua ERROR: Cant find zone called " .. _zone, 10)
        return
    end

    local _zonePos = mist.utils.zoneToVec3(_zone)

    local _redCount = 0;
    local _blueCount = 0;

    local _allGroups = {ctld.droppedTroopsRED,ctld.droppedTroopsBLUE}

    for _, _extractGroups in pairs(_allGroups) do
        for _,_groupName  in pairs(_extractGroups) do
            local _groupUnits = ctld.getGroup(_groupName)

            if #_groupUnits > 0 then

                local _zonePos = mist.utils.zoneToVec3(_zone)
                for _,_unit in pairs(_groupUnits) do
                    local _dist = ctld.getDistance(_unit:getPoint(), _zonePos)

                    if _dist <= _triggerZone.radius then

                        if (_unit:getCoalition() == 1) then
                            _redCount = _redCount + 1;
                        else
                            _blueCount = _blueCount + 1;
                        end
                    end
                end
            end
        end
    end


    -- записать значения во флаги.
    trigger.action.setUserFlag(_blueFlag, _blueCount)
    trigger.action.setUserFlag(_redFlag, _redCount)

    --  env.info("Units in zone ".._blueCount.." ".._redCount)
end


-- Активирует зону погрузки.
-- Зона погрузки активируется при вызове из триггера.
-- Пример: ctld.activatePickupZone("pickzone3")
-- Делает pickzone3 доступной как зону погрузки для заданных групп.
function ctld.activatePickupZone(_zoneName)
    ctld.logDebug(string.format("ctld.activatePickupZone(_zoneName=%s)", ctld.p(_zoneName)))

    local _triggerZone = trigger.misc.getZone(_zoneName) -- trigger to use as reference position

    if _triggerZone == nil then
        local _ship = ctld.getTransportUnit(_triggerZone)

        if _ship then
            local _point = _ship:getPoint()
            _triggerZone = {}
            _triggerZone.point = _point
        end

    end

    if _triggerZone == nil  then
        trigger.action.outText("CTLD.lua ERROR: Cant find zone or ship called " .. _zoneName, 10)
    end

    for _, _zoneDetails in pairs(ctld.pickupZones) do

        if _zoneName == _zoneDetails[1] then

            -- повторное включение активной зоны создаёт лишний дым, поэтому сначала проверяется её состояние.
            if _zoneDetails[4] == 1 then
                -- возможно, используется непрерывный триггер, поэтому предупреждение скрыто.
                --trigger.action.outText("CTLD.lua ERROR: Pickup Zone already active: " .. _zoneName, 10)
                return
            end

            _zoneDetails[4] = 1 -- активировать зону.

            if ctld.disableAllSmoke == true then -- дым отключён.
            return
            end

            if _zoneDetails[2] >= 0 then

                -- включить дымовой маркер.
                -- При следующем обновлении дыма маркеры могут кратко наложиться,
                -- но это произойдёт только один раз.
                local _pos2 = { x = _triggerZone.point.x, y = _triggerZone.point.z }
                local _alt = land.getHeight(_pos2)
                local _pos3 = { x = _pos2.x, y = _alt, z = _pos2.y }

                trigger.action.smoke(_pos3, _zoneDetails[2])
            end
        end
    end
end


-- Деактивирует зону погрузки.
-- Зона погрузки деактивируется при вызове из триггера.
-- Пример: ctld.deactivatePickupZone("pickzone3")
-- Отключает pickzone3: её больше нельзя использовать для погрузки.
-- Эти функции можно вызывать триггерами: например, сделать зону неработоспособной
-- после уничтожения заданных зданий.
function ctld.deactivatePickupZone(_zoneName)

    local _triggerZone = trigger.misc.getZone(_zoneName) -- trigger to use as reference position

    if _triggerZone == nil then
        local _ship = ctld.getTransportUnit(_triggerZone)

        if _ship then
            local _point = _ship:getPoint()
            _triggerZone = {}
            _triggerZone.point = _point
        end

    end

    if _triggerZone == nil then
        trigger.action.outText("CTLD.lua ERROR: Cant find zone called " .. _zoneName, 10)
        return
    end

    for _, _zoneDetails in pairs(ctld.pickupZones) do

        if _zoneName == _zoneDetails[1] then

            -- если зона уже деактивирована, просто игнорируем вызов.
            --            if _zoneDetails[4] == 0 then --this really needed??
            --            trigger.action.outText("CTLD.lua ERROR: Pickup Zone already deactiveated: " .. _zoneName, 10)
            --            return
            --            end

            _zoneDetails[4] = 0 -- деактивировать зону.
        end
    end
end

-- Изменяет количество групп, ещё доступных для погрузки в зоне.
-- Например: ctld.changeRemainingGroupsForPickupZone("pickup1", 5) -- добавляет 5 групп.
-- ctld.changeRemainingGroupsForPickupZone("pickup1", -3) -- удаляет 3 группы.
function ctld.changeRemainingGroupsForPickupZone(_zoneName, _amount)
    local _triggerZone = trigger.misc.getZone(_zoneName) -- trigger to use as reference position

    if _triggerZone == nil then
        local _ship = ctld.getTransportUnit(_triggerZone)

        if _ship then
            local _point = _ship:getPoint()
            _triggerZone = {}
            _triggerZone.point = _point
        end

    end

    if _triggerZone == nil  then
        trigger.action.outText("CTLD.lua ctld.changeRemainingGroupsForPickupZone ERROR: Cant find zone called " .. _zoneName, 10)
        return
    end

    for _, _zoneDetails in pairs(ctld.pickupZones) do

        if _zoneName == _zoneDetails[1] then
            ctld.updateZoneCounter(_zoneName, _amount)
        end
    end


end

-- Добавляет обратный вызов, выполняемый для многих игровых действий.
function ctld.addCallback(_callback)

    table.insert(ctld.callbacks,_callback)

end

-- Создаёт ящик, доступный для внешней подвески, в триггерной зоне.
--
-- Вес ящиков указан в списке ctld.spawnableCrates.
-- Например: ctld.spawnCrateAtZone("red", 500,"triggerzone1") -- создать HMMWV в triggerzone1 для красных.
-- Например: ctld.spawnCrateAtZone("blue", 505,"triggerzone1") -- создать HMMWV с ПТУР в triggerzone1 для синих.
--
function ctld.spawnCrateAtZone(_side, _weight,_zone)
    local _spawnTrigger = trigger.misc.getZone(_zone) -- trigger to use as reference position

    if _spawnTrigger == nil then
        trigger.action.outText("CTLD.lua ERROR: Cant find zone called " .. _zone, 10)
        return
    end

    local _crateType = ctld.crateLookupTable[tostring(_weight)]

    if _crateType == nil then
        trigger.action.outText("CTLD.lua ERROR: Cant find crate with weight " .. _weight, 10)
        return
    end

    local _country
    if _side == "red" then
        _side = 1
        _country = 0
    else
        _side = 2
        _country = 2
    end

    local _pos2 = { x = _spawnTrigger.point.x, y = _spawnTrigger.point.z }
    local _alt = land.getHeight(_pos2)
    local _point = { x = _pos2.x, y = _alt, z = _pos2.y }

    local _unitId = ctld.getNextUnitId()

    local _name = string.format("%s #%i", _crateType.desc, _unitId)

    local _spawnedCrate = ctld.spawnCrateStatic(_country, _unitId, _point, _name, _crateType.weight,_side)

end

-- Создаёт ящик, доступный для внешней подвески, в заданной точке.
--
-- Вес ящиков указан в списке ctld.spawnableCrates.
-- Точку можно задать вручную или получить из позиции юнита: Unit.getByName("PilotName"):getPoint().
-- e.g. ctld.spawnCrateAtZone("red", 500,{x=1,y=2,z=3}) -- spawn a humvee at triggerzone 1 for red side at a specified point
-- e.g. ctld.spawnCrateAtZone("blue", 505,{x=1,y=2,z=3}) -- spawn a tow humvee at triggerzone1 for blue side at a specified point
--
--
function ctld.spawnCrateAtPoint(_side, _weight,_point)


    local _crateType = ctld.crateLookupTable[tostring(_weight)]

    if _crateType == nil then
        trigger.action.outText("CTLD.lua ERROR: Cant find crate with weight " .. _weight, 10)
        return
    end

    local _country
    if _side == "red" then
        _side = 1
        _country = 0
    else
        _side = 2
        _country = 2
    end

    local _unitId = ctld.getNextUnitId()

    local _name = string.format("%s #%i", _crateType.desc, _unitId)

    local _spawnedCrate = ctld.spawnCrateStatic(_country, _unitId, _point, _name, _crateType.weight,_side)

end

-- ***************************************************************
-- **************** БУДЬТЕ ОСТОРОЖНЫ ************************
-- ***************************************************************

--- Сообщает CTLD, какие многокомпонентные системы AA существуют и какие части им нужны
-- Сообщает CTLD, какие многокомпонентные системы AA существуют и какие части им нужны
ctld.AASystemTemplate = {
    {
        name = "HAWK AA System",
        count = 4,
        parts = {
            {name = "Hawk ln", desc = "HAWK Launcher", launcher = true},
            {name = "Hawk tr", desc = "HAWK Track Radar"},
            {name = "Hawk sr", desc = "HAWK Search Radar"},
            {name = "Hawk pcp", desc = "HAWK PCP"},
            {name = "Hawk cwar", desc = "HAWK CWAR"},
        },
        repair = "HAWK Repair",
    },
    {
        name = "Patriot AA System",
        count = 6,
        parts = {
            {name = "Patriot cp",  desc = "Patriot ПБУ"},
            {name = "Patriot EPP", desc = "Patriot EPP"},
            {name = "Patriot ECS", desc = "Patriot КП"},
            {name = "Patriot ln",  desc = "Patriot ПУ", launcher = true, amount = 1},
            {name = "Patriot AMG", desc = "Patriot РТС"},
            {name = "Patriot str", desc = "Patriot РПН"},
        },
    },
	{
        name = "BUK AA System",
        count = 3,
        parts = {
            {name = "SA-11 Buk LN 9A310M1", desc = "BUK Launcher" , launcher = true},
            {name = "SA-11 Buk CC 9S470M1", desc = "BUK CC Radar"},
            {name = "SA-11 Buk SR 9S18M1", desc = "BUK Search Radar"},
        },
        repair = "BUK Repair",
    },
    {
        name = "KUB AA System",
        count = 2,
        parts = {
            {name = "Kub 2P25 ln", desc = "KUB Launcher", launcher = true},
            {name = "Kub 1S91 str", desc = "KUB Radar"},
        },
        repair = "KUB Repair",
    },
    -- NATO: все части системы доставляются в ящиках и после распаковки
    -- появляются одной AI-группой, как КУБ/БУК у красной коалиции.
    {
        name = "IRIS-T SLM NATO System",
        count = 3,
        parts = {
            { name = "CHAP_IRISTSLM_STR", desc = "IRIS РЛС" },
            { name = "CHAP_IRISTSLM_LN",  desc = "IRIS ПУ", launcher = true, amount = 1 },
            { name = "CHAP_IRISTSLM_CP",  desc = "IRIS МУ" },
        },
    },
    {
        name = "HQ-7 NATO System",
        count = 2,
        parts = {
            { name = "HQ-7_LN_SP",  desc = "HQ-7 ПУ", launcher = true, amount = 1 },
            { name = "HQ-7_STR_SP", desc = "HQ-7 РЛС" },
        },
    },
    {
        name = "Roland NATO System",
        count = 2,
        parts = {
            { name = "Roland Radar", desc = "Roland РЛО" },
            { name = "Roland ADS",   desc = "Roland ADS", launcher = true, amount = 1 },
        },
    },
}


ctld.crateWait = {}
ctld.crateMove = {}
ctld.f10MenuRoots = {}

----------------- ВНУТРЕННИЕ ФУНКЦИИ ----------------
---
---
-------------------------------------------------------------------------------------------------------------------------------------------------------------
-- Вспомогательные методы.
-------------------------------------------------------------------------------------------------------------------------------------------------------------

--- Выводит объект в журнал отладки.
function ctld.p(o, level)
    -- Все вызовы p() используются диагностикой. Не строим глубокую строку
    -- таблицы, когда подробный журнал выключен.
    if not ctld.Debug and not ctld.Trace then return "" end
    local MAX_LEVEL = 20
    if level == nil then level = 0 end
    if level > MAX_LEVEL then
        ctld.logError("max depth reached in ctld.p : "..tostring(MAX_LEVEL))
        return ""
    end
    local text = ""
    if (type(o) == "table") then
        text = "\n"
        for key,value in pairs(o) do
            for i=0, level do
                text = text .. " "
            end
            text = text .. ".".. key.."="..ctld.p(value, level+1) .. "\n"
        end
    elseif (type(o) == "function") then
        text = "[function]"
    elseif (type(o) == "boolean") then
        if o == true then
            text = "[true]"
        else
            text = "[false]"
        end
    else
        if o == nil then
            text = "[nil]"
        else
            text = tostring(o)
        end
    end
    return text
end

function ctld.logError(message)
    env.info(" E - " .. ctld.Id .. message)
end

function ctld.logInfo(message)
    env.info(" I - " .. ctld.Id .. message)
end

function ctld.logDebug(message)
    if message and ctld.Debug then
        env.info(" D - " .. ctld.Id .. message)
    end
end

function ctld.logTrace(message)
    if message and ctld.Trace then
        env.info(" T - " .. ctld.Id .. message)
    end
end

ctld.nextUnitId = 1;
ctld.getNextUnitId = function()
    ctld.nextUnitId = ctld.nextUnitId + 1

    return ctld.nextUnitId
end

ctld.nextGroupId = 1;

ctld.getNextGroupId = function()
    ctld.nextGroupId = ctld.nextGroupId + 1

    return ctld.nextGroupId
end

function ctld.getTransportUnit(_unitName)

    if _unitName == nil then
        return nil
    end

    local _heli = Unit.getByName(_unitName)

    if _heli ~= nil and _heli:isActive() and _heli:getLife() > 0 then

        return _heli
    end

    return nil
end

-- Числовая category у модулей DCS неоднозначна. Определяем класс борта по
-- штатным атрибутам модели: Planes или Helicopters.
function ctld.hasUnitAttribute(_unit, _attribute)
    if not _unit or not _unit.hasAttribute then return false end
    local _ok, _hasAttribute = pcall(function() return _unit:hasAttribute(_attribute) end)
    return _ok and _hasAttribute == true
end

function ctld.isPlaneUnit(_unit)
    return ctld.hasUnitAttribute(_unit, "Planes")
end

function ctld.isHelicopterUnit(_unit)
    return ctld.hasUnitAttribute(_unit, "Helicopters")
end

-- Список формируется по фактическим игрокам: имена МТО в редакторе больше не нужны.
function ctld.refreshPlayerTransportNames()
    local _names, _seen = {}, {}
    for _, _side in ipairs({coalition.side.RED, coalition.side.BLUE}) do
        for _, _unit in ipairs(coalition.getPlayers(_side) or {}) do
            local _isHelicopter = ctld.isHelicopterUnit(_unit)
            if _unit and _unit:isExist() and _unit:isActive() and _unit:getLife() > 0
                and (_isHelicopter or ctld.playerTransportTypes[_unit:getTypeName()])
                and not _seen[_unit:getName()] then
                _seen[_unit:getName()] = true
                table.insert(_names, _unit:getName())
            end
        end
    end
    ctld.transportPilotNames = _names
end

-- Сборщик вызывается редко из обновления F10. Он очищает только записи,
-- для которых объект DCS уже исчез, не вмешиваясь в активные группы.
function ctld.cleanupRuntimeState()
    local _now = timer.getTime()
    if ctld.nextRuntimeCleanup and _now < ctld.nextRuntimeCleanup then return end
    ctld.nextRuntimeCleanup = _now + 60

    local _activeGroups = {}
    for _, _unitName in ipairs(ctld.transportPilotNames) do
        local _unit = ctld.getTransportUnit(_unitName)
        if _unit then
            local _groupId = ctld.getGroupId(_unit)
            if _groupId then _activeGroups[tostring(_groupId)] = _unitName end
        end
    end

    for _groupId in pairs(ctld.addedTo) do
        if _activeGroups[_groupId] ~= ctld.addedTo[_groupId] then
            ctld.addedTo[_groupId] = nil
            ctld.f10MenuRoots[_groupId] = nil
        end
    end

    -- Пункт статуса ПАН создаётся отдельно от корневого CTLD-меню.
    -- Удаляем его запись для ушедших слотов, чтобы повторная посадка
    -- или повторный вызов меню не оставляли дубликаты.
    for _groupId in pairs(ctld.jtacRadioAdded) do
        if not _activeGroups[_groupId] then
            ctld.jtacRadioAdded[_groupId] = nil
        end
    end

    for _unitName in pairs(ctld.inTransitTroops) do
        if not ctld.getTransportUnit(_unitName) then
            ctld.inTransitTroops[_unitName] = nil
        end
    end
    for _unitName in pairs(ctld.inTransitSlingLoadCrates) do
        if not ctld.getTransportUnit(_unitName) then
            ctld.inTransitSlingLoadCrates[_unitName] = nil
        end
    end
    for _unitName in pairs(ctld.transportCargoUnitIds) do
        if not ctld.getTransportUnit(_unitName) then
            ctld.transportCargoUnitIds[_unitName] = nil
        end
    end
    for _unitName in pairs(ctld.hoverStatus) do
        if not ctld.getTransportUnit(_unitName) then
            ctld.hoverStatus[_unitName] = nil
        end
    end
    for _playerName, _readyTime in pairs(ctld.crateWait) do
        if _readyTime <= _now then
            ctld.crateWait[_playerName] = nil
        end
    end

    local function cleanCrates(_crates)
        for _crateName in pairs(_crates) do
            local _crate = ctld.getCrateObject(_crateName)
            if not _crate or _crate:getLife() <= 0 then
                _crates[_crateName] = nil
                ctld.crateMove[_crateName] = nil
            end
        end
    end
    cleanCrates(ctld.spawnedCratesRED)
    cleanCrates(ctld.spawnedCratesBLUE)

    local function cleanDroppedGroups(_groups)
        local _live = {}
        for _, _groupName in ipairs(_groups) do
            local _group = Group.getByName(_groupName)
            local _hasLiveUnit = false
            if _group and _group:isExist() then
                for _, _unit in ipairs(_group:getUnits() or {}) do
                    if _unit and _unit:isExist() and _unit:getLife() > 0 then
                        _hasLiveUnit = true
                        break
                    end
                end
            end
            if _hasLiveUnit then table.insert(_live, _groupName) end
        end
        return _live
    end

    ctld.droppedTroopsRED = cleanDroppedGroups(ctld.droppedTroopsRED)
    ctld.droppedTroopsBLUE = cleanDroppedGroups(ctld.droppedTroopsBLUE)

    for _groupName in pairs(ctld.completeAASystems) do
        local _group = Group.getByName(_groupName)
        if not _group or not _group:isExist() then
            ctld.completeAASystems[_groupName] = nil
        end
    end
end

function ctld.spawnCrateStatic(_country, _unitId, _point, _name, _weight,_side)

    local _crate
    local _spawnedCrate

    if ctld.staticBugWorkaround and ctld.slingLoad == false then
        local _groupId = ctld.getNextGroupId()
        local _groupName = "Crate Group #".._groupId

        local _group = {
            ["visible"] = false,
           -- ["groupId"] = _groupId,
            ["hidden"] = false,
            ["units"] = {},
            --        ["y"] = _positions[1].z,
            --        ["x"] = _positions[1].x,
            ["name"] = _groupName,
            ["task"] = {},
        }

        _group.units[1] = ctld.createUnit(_point.x , _point.z , 0, {type="UAZ-469",name=_name,unitId=_unitId})

        -- переключить на MiST.
        _group.category = Group.Category.GROUND;
        _group.country = _country;

        local _spawnedGroup = Group.getByName(mist.dynAdd(_group).name)

        -- отключить ИИ.
        trigger.action.setGroupAIOff(_spawnedGroup)

        _spawnedCrate = Unit.getByName(_name)
    else

        if ctld.slingLoad then
            _crate = mist.utils.deepCopy(ctld.spawnableCratesModel_sling)
            _crate["canCargo"] = true
    	else
            _crate = mist.utils.deepCopy(ctld.spawnableCratesModel_load)
            _crate["canCargo"] = false
        end

        _crate["y"] = _point.z
        _crate["x"] = _point.x
        _crate["mass"] = _weight
        _crate["name"] = _name
        _crate["heading"] = 0
        _crate["country"] = _country

        ctld.logTrace(string.format("_crate=%s", ctld.p(_crate)))
        mist.dynAddStatic(_crate)

        _spawnedCrate = StaticObject.getByName(_crate["name"])
    end


    local _crateType = ctld.crateLookupTable[tostring(_weight)]

    if _side == 1 then
        ctld.spawnedCratesRED[_name] =_crateType
    else
        ctld.spawnedCratesBLUE[_name] = _crateType
    end

    return _spawnedCrate
end

function ctld.spawnCrate(_arguments)

    local _status, _err = pcall(function(_args)

        -- использовать вес груза для определения типа юнита: описание передать невозможно.

        local _crateType = ctld.crateLookupTable[tostring(_args[2])]
        local _heli = ctld.getTransportUnit(_args[1])

        if _crateType ~= nil and _heli ~= nil and ctld.inAir(_heli) == false then

            if ctld.inLogisticsZone(_heli) == false then

                ctld.displayMessageToGroup(_heli, "Вы находитесь далеко от зоны погрузки МТО, см. карту!", 10)

                return
            end

            if ctld.isJTACUnitType(_crateType.unit) then
                if not ctld.canRequestJTAC(_heli:getCoalition()) then
                    ctld.notifyJTACLimitToGroup(_heli)
                    return
                end
            end

            local _position = _heli:getPosition()

            -- проверить спам ящиками.
            if _heli:getPlayerName() ~= nil and ctld.crateWait[_heli:getPlayerName()] and  ctld.crateWait[_heli:getPlayerName()] > timer.getTime() then

                ctld.displayMessageToGroup(_heli,"Командир, не так быстро, подожди "..(ctld.crateWait[_heli:getPlayerName()]  - timer.getTime()).. " секунд для получения следующего груза", 20)
                return
            end

            if _heli:getPlayerName() ~= nil then
                ctld.crateWait[_heli:getPlayerName()] = timer.getTime() + ctld.crateWaitTime
            end
                --   trigger.action.outText("Spawn Crate".._args[1].." ".._args[2],10)

            local _heli = ctld.getTransportUnit(_args[1])

            local _point = ctld.getPointAt12Oclock(_heli, 30)

            local _unitId = ctld.getNextUnitId()

            local _side = _heli:getCoalition()

            local _name = string.format("%s #%i", _crateType.desc, _unitId)

            local _spawnedCrate = ctld.spawnCrateStatic(_heli:getCountry(), _unitId, _point, _name, _crateType.weight,_side)
            local _groupId = ctld.getGroupId(_heli)
            if _groupId then trigger.action.outSoundForGroup(_groupId, "ready_for_loading.ogg") end

            -- добавить в таблицу перемещений.
            ctld.crateMove[_name] = _name

            ctld.displayMessageToGroup(_heli, string.format("Контейнер с %s весом %s кг появился прямо перед Вами ", _crateType.desc, _crateType.weight), 20, false, true)

        else
            env.info("Couldn't find crate item to spawn")
        end
    end, _arguments)

    if (not _status) then
        env.error(string.format("CTLD ERROR: %s", _err))
    end
end

function ctld.getPointAt12Oclock(_unit, _offset)

    local _position = _unit:getPosition()
    local _angle = math.atan2(_position.x.z, _position.x.x)
    local _xOffset = math.cos(_angle) * _offset
    local _yOffset = math.sin(_angle) * _offset

    local _point = _unit:getPoint()
    return { x = _point.x + _xOffset, z = _point.z + _yOffset, y = _point.y }
end

function ctld.troopsOnboard(_heli, _troops)

    if ctld.inTransitTroops[_heli:getName()] ~= nil then

        local _onboard = ctld.inTransitTroops[_heli:getName()]

        if _troops then

            if _onboard.troops ~= nil and _onboard.troops.units ~= nil and #_onboard.troops.units > 0 then
                return true
            else
                return false
            end
        else

            if _onboard.vehicles ~= nil and _onboard.vehicles.units ~= nil and #_onboard.vehicles.units > 0 then
                return true
            else
                return false
            end
        end

    else
        return false
    end
end

-- Если груз выгружен ИИ, имени игрока нет — вернуть тип юнита.
function ctld.getPlayerNameOrType(_heli)

    if _heli:getPlayerName() == nil then

        return _heli:getTypeName()
    else
        return _heli:getPlayerName()
    end
end

-- Высадка на тросах безопасна, если скорость менее 0,5 м/с.
function ctld.safeToFastRope(_heli)

    if ctld.enableFastRopeInsertion == false then
        return false
    end

    -- на земле либо скорость менее 8 км/ч и высота меньше предельной для тросов.
    if (ctld.inAir(_heli) == false or (ctld.heightDiff(_heli) <= ctld.fastRopeMaximumHeight + 3.0 and mist.vec.mag(_heli:getVelocity()) < 2.2)) then
        return true
    end
end

function ctld.metersToFeet(_meters)

    local _feet = _meters * 3.2808399

    return mist.utils.round(_feet)
end

function ctld.inAir(_heli)

    if _heli:inAir() == false then
        return false
    end

    -- менее 5 см/с — значит, сел.
    -- НО ИИ может идеально висеть, поэтому ИИ игнорируется.
    if mist.vec.mag(_heli:getVelocity()) < 0.05 and _heli:getPlayerName() ~= nil then
        return false
    end
    return true
end

-- Выгрузка запрещается только при критически повреждённом живом борте.
-- getLife0() возвращает исходную прочность конкретного типа вертолёта, поэтому
-- проверка корректно работает для разных модулей и динамических слотов.
function ctld.canTransportUnload(_heli)
    if not _heli or not _heli:isExist() then return false, 0 end
    local _ok, _currentLife, _initialLife = pcall(function()
        return _heli:getLife(), _heli:getLife0()
    end)
    if not _ok or not _initialLife or _initialLife <= 0 then
        return true, 100
    end
    local _percent = (_currentLife / _initialLife) * 100
    -- Ровно на пороге выгрузка уже запрещена: требуется строго больше 20%.
    return _percent > ctld.minimumTransportLifeForUnload * 100, _percent
end

-- Аварийный сброс: при несовместимых повреждениях груз считается потерянным.
-- Объекты не создаются на земле, так как сброс мог быть запрошен в воздухе.
function ctld.discardTransportCargo(_heli)
    if not _heli or not _heli:isExist() then return end
    local _unitName = _heli:getName()
    ctld.inTransitTroops[_unitName] = nil
    ctld.inTransitSlingLoadCrates[_unitName] = nil
    ctld.hoverStatus[_unitName] = nil
    ctld.adaptWeightToCargo(_unitName)
end

function ctld.requireTransportReadyForUnload(_heli)
    local _allowed, _percent = ctld.canTransportUnload(_heli)
    if _allowed then return true end

    ctld.discardTransportCargo(_heli)
    local _text = "ВНИМАНИЕ. Выброска невозможна. Вертолёт получил несовместимые повреждения."
    ctld.displayMessageToGroup(_heli, _text, 16, false, true)
    local _groupId = ctld.getGroupId(_heli)
    if _groupId then trigger.action.outSoundForGroup(_groupId, "no_conditions.ogg") end
    return false
end

function ctld.deployTroops(_heli, _troops)

    local _onboard = ctld.inTransitTroops[_heli:getName()]

    -- высадить войска.
    if _troops then
        if not ctld.requireTransportReadyForUnload(_heli) then return false end
        if _onboard.troops ~= nil and #_onboard.troops.units > 0 then
            if ctld.inAir(_heli) == false or ctld.safeToFastRope(_heli) then

                _onboard.troops.deployerGroupId = ctld.getGroupId(_heli)
                local _droppedTroops = ctld.spawnDroppedGroup(_heli:getPoint(), _onboard.troops, false)
                    ctld.logTrace(string.format("_onboard.troops=%s", ctld.p(_onboard.troops)))
                    if _onboard.troops.jtac or _droppedTroops:getName():lower():find("jtac") then
                        local _code = ctld.getJTACLaserCode(_heli:getCoalition())
                        ctld.logTrace(string.format("_code=%s", ctld.p(_code)))
                        ctld.logTrace(string.format("_droppedTroops:getName()=%s", ctld.p(_droppedTroops:getName())))
                        if _onboard.troops.jtac then
                            ctld.jtacInfantryGroups[_droppedTroops:getName()] = true
                        end
                        if _onboard.troops.jtac then
                            timer.scheduleFunction(ctld.activateJTACAfterDelay, {
                                groupName = _droppedTroops:getName(),
                                side = _heli:getCoalition(),
                                laserCode = _code,
                            }, timer.getTime() + 10)
                        end
                    end

                    if _heli:getCoalition() == 1 then

                        table.insert(ctld.droppedTroopsRED, _droppedTroops:getName())
                    else

                        table.insert(ctld.droppedTroopsBLUE, _droppedTroops:getName())
                    end

                    ctld.inTransitTroops[_heli:getName()].troops = nil
                    ctld.adaptWeightToCargo(_heli:getName())

                    if ctld.inAir(_heli) then
                        trigger.action.outTextForCoalition(_heli:getCoalition(), ctld.getPlayerNameOrType(_heli) .. " высадил десант " .. _heli:getTypeName() .. " работаем", 10)
                    else
                        trigger.action.outTextForCoalition(_heli:getCoalition(), ctld.getPlayerNameOrType(_heli) .. " высадил десант " .. _heli:getTypeName() .. " работаем", 10)
                    end
                    local _groupId = ctld.getGroupId(_heli)
                    if _groupId then trigger.action.outSoundForGroup(_groupId, "landing_work.ogg") end

                ctld.processCallback({unit = _heli, unloaded = _droppedTroops, action = "dropped_troops"})
            else
                ctld.displayMessageToGroup(_heli, "Слишком большая высота или скорость для десантирования! Зависните на высоте не выше " .. ctld.metersToFeet(ctld.fastRopeMaximumHeight) .. " метров или выполните посадку.", 10)
            end
        end

    end
end

function ctld.insertIntoTroopsArray(_troopType,_count,_troopArray,_troopName)

    for _i = 1, _count do
        local _unitId = ctld.getNextUnitId()
        table.insert(_troopArray, { type = _troopType, unitId = _unitId, name = string.format("Dropped %s #%i", _troopName or _troopType, _unitId) })
    end

    return _troopArray

end


function ctld.generateTroopTypes(_side, _countOrTemplate, _country)
    local _troops = {}
    local _weight = 0
    local _hasJTAC = false

    local function getSoldiersWeight(count, additionalWeight)
        local _weight = 0
        for i = 1, count do
            local _soldierWeight = math.random(90, 120) * ctld.SOLDIER_WEIGHT / 100
            ctld.logTrace(string.format("_soldierWeight=%s", ctld.p(_soldierWeight)))
            _weight = _weight + _soldierWeight + ctld.KIT_WEIGHT + additionalWeight
        end
        return _weight
    end

    if type(_countOrTemplate) == "table" then

        if _countOrTemplate.aa then
            ctld.logTrace(string.format("_countOrTemplate.aa=%s", ctld.p(_countOrTemplate.aa)))
            if _side == 2 then
                _troops = ctld.insertIntoTroopsArray("Soldier stinger",_countOrTemplate.aa,_troops)
            else
                _troops = ctld.insertIntoTroopsArray("SA-18 Igla manpad",_countOrTemplate.aa,_troops)
            end
            _weight = _weight + getSoldiersWeight(_countOrTemplate.aa, ctld.MANPAD_WEIGHT)
            ctld.logTrace(string.format("_weight=%s", ctld.p(_weight)))
        end

        if _countOrTemplate.inf then
            ctld.logTrace(string.format("_countOrTemplate.inf=%s", ctld.p(_countOrTemplate.inf)))
            if _side == 2 then
                _troops = ctld.insertIntoTroopsArray("Soldier M4",_countOrTemplate.inf,_troops)
            else
                _troops = ctld.insertIntoTroopsArray("Soldier AK",_countOrTemplate.inf,_troops)
            end
            _weight = _weight + getSoldiersWeight(_countOrTemplate.inf, ctld.RIFLE_WEIGHT)
            ctld.logTrace(string.format("_weight=%s", ctld.p(_weight)))
        end

        if _countOrTemplate.mg then
            ctld.logTrace(string.format("_countOrTemplate.mg=%s", ctld.p(_countOrTemplate.mg)))
            if _side == 2 then
                _troops = ctld.insertIntoTroopsArray("Soldier M249",_countOrTemplate.mg,_troops)
            else
                _troops = ctld.insertIntoTroopsArray("Paratrooper AKS-74",_countOrTemplate.mg,_troops)
            end
            _weight = _weight + getSoldiersWeight(_countOrTemplate.mg, ctld.MG_WEIGHT)
            ctld.logTrace(string.format("_weight=%s", ctld.p(_weight)))
        end

        if _countOrTemplate.at then
            ctld.logTrace(string.format("_countOrTemplate.at=%s", ctld.p(_countOrTemplate.at)))
            _troops = ctld.insertIntoTroopsArray("Paratrooper RPG-16",_countOrTemplate.at,_troops)
            _weight = _weight + getSoldiersWeight(_countOrTemplate.at, ctld.RPG_WEIGHT)
            ctld.logTrace(string.format("_weight=%s", ctld.p(_weight)))
        end

        if _countOrTemplate.mortar then
            ctld.logTrace(string.format("_countOrTemplate.mortar=%s", ctld.p(_countOrTemplate.mortar)))
            _troops = ctld.insertIntoTroopsArray("2B11 mortar",_countOrTemplate.mortar,_troops)
            _weight = _weight + getSoldiersWeight(_countOrTemplate.mortar, ctld.MORTAR_WEIGHT)
            ctld.logTrace(string.format("_weight=%s", ctld.p(_weight)))
        end

        if _countOrTemplate.jtac then
            ctld.logTrace(string.format("_countOrTemplate.jtac=%s", ctld.p(_countOrTemplate.jtac)))
            if _side == 2 then
                _troops = ctld.insertIntoTroopsArray("Soldier M4",_countOrTemplate.jtac,_troops, "JTAC")
            else
                _troops = ctld.insertIntoTroopsArray("Soldier AK",_countOrTemplate.jtac,_troops, "JTAC")
            end
            _hasJTAC = true
            _weight = _weight + getSoldiersWeight(_countOrTemplate.jtac, ctld.JTAC_WEIGHT + ctld.RIFLE_WEIGHT)
            ctld.logTrace(string.format("_weight=%s", ctld.p(_weight)))
        end

    else
        for _i = 1, _countOrTemplate do

            local _unitType = "Soldier AK"

            if _side == 2 then
                if _i <=2 then
                    _unitType = "Soldier M249"
                    _weight = _weight + getSoldiersWeight(1, ctld.MG_WEIGHT)
                    ctld.logTrace(string.format("_unitType=%s, _weight=%s", ctld.p(_unitType), ctld.p(_weight)))
                elseif ctld.spawnRPGWithCoalition and _i > 2 and _i <= 4 then
                    _unitType = "Paratrooper RPG-16"
                    _weight = _weight + getSoldiersWeight(1, ctld.RPG_WEIGHT)
                    ctld.logTrace(string.format("_unitType=%s, _weight=%s", ctld.p(_unitType), ctld.p(_weight)))
                elseif ctld.spawnStinger and _i > 4 and _i <= 5 then
                    _unitType = "Soldier stinger"
                    _weight = _weight + getSoldiersWeight(1, ctld.MANPAD_WEIGHT)
                    ctld.logTrace(string.format("_unitType=%s, _weight=%s", ctld.p(_unitType), ctld.p(_weight)))
                else
                    _unitType = "Soldier M4"
                    _weight = _weight + getSoldiersWeight(1, ctld.RIFLE_WEIGHT)
                    ctld.logTrace(string.format("_unitType=%s, _weight=%s", ctld.p(_unitType), ctld.p(_weight)))
                end
            else
                if _i <=2 then
                    _unitType = "Paratrooper AKS-74"
                    _weight = _weight + getSoldiersWeight(1, ctld.MG_WEIGHT)
                    ctld.logTrace(string.format("_unitType=%s, _weight=%s", ctld.p(_unitType), ctld.p(_weight)))
                elseif ctld.spawnRPGWithCoalition and _i > 2 and _i <= 4 then
                    _unitType = "Paratrooper RPG-16"
                    _weight = _weight + getSoldiersWeight(1, ctld.RPG_WEIGHT)
                    ctld.logTrace(string.format("_unitType=%s, _weight=%s", ctld.p(_unitType), ctld.p(_weight)))
                elseif ctld.spawnStinger and _i > 4 and _i <= 5 then
                    _unitType = "SA-18 Igla manpad"
                    _weight = _weight + getSoldiersWeight(1, ctld.MANPAD_WEIGHT)
                    ctld.logTrace(string.format("_unitType=%s, _weight=%s", ctld.p(_unitType), ctld.p(_weight)))
                else
                    _unitType = "Infantry AK"
                    _weight = _weight + getSoldiersWeight(1, ctld.RIFLE_WEIGHT)
                    ctld.logTrace(string.format("_unitType=%s, _weight=%s", ctld.p(_unitType), ctld.p(_weight)))
                end
            end

            local _unitId = ctld.getNextUnitId()

            _troops[_i] = { type = _unitType, unitId = _unitId, name = string.format("Десант %s #%i", _unitType, _unitId) }
        end
    end

    local _groupId = ctld.getNextGroupId()
    local _groupName = "Десантная группа"
    if _hasJTAC then
        _groupName = "Наводчик"
    end
    local _autoRole = nil
    if type(_countOrTemplate) == "table" then
        if _countOrTemplate.name == "Штурмовой взвод"
            or _countOrTemplate.name == "Противотанковый расчет" then
            _autoRole = "attack"
        elseif _countOrTemplate.name == "Минометная батарея" then
            _autoRole = "mortar"
        elseif _countOrTemplate.name == "ПАН разведчик" or _countOrTemplate.name == "Разведчик JTAC" then
            _autoRole = "ПАН разведчик"
        end
    end
    local _details = { units = _troops, groupId = _groupId, groupName = string.format("%s %i", _groupName, _groupId), side = _side, country = _country, weight = _weight, jtac = _hasJTAC, autoRole = _autoRole, taskName = type(_countOrTemplate) == "table" and _countOrTemplate.name or nil }
    ctld.logTrace(string.format("total  weight=%s", ctld.p(_weight)))

    return _details
end

-- Специальная функция F10 для работы игроков с пехотой.
function ctld.unloadExtractTroops(_args)

    local _heli = ctld.getTransportUnit(_args[1])

    if _heli == nil then
        return false
    end


    local _extract = nil
    if not ctld.inAir(_heli) then
        if _heli:getCoalition() == 1 then
            _extract = ctld.findNearestGroup(_heli, ctld.droppedTroopsRED)
        else
            _extract = ctld.findNearestGroup(_heli, ctld.droppedTroopsBLUE)
        end

    end

    if _extract ~= nil and not ctld.troopsOnboard(_heli, true) then
        -- поиск ближайших войск для погрузки.
        return ctld.extractTroops({_heli:getName(), true})
    else
        return ctld.unloadTroops({_heli:getName(),true,true})
    end


end

-- Загрузить пехоту в вертолёт.
function ctld.loadTroops(_heli, _troops, _numberOrTemplate)

    local _onboard = ctld.inTransitTroops[_heli:getName()]

    if _numberOrTemplate == nil  or (type(_numberOrTemplate) ~= "table" and type(_numberOrTemplate) ~= "number")  then
        _numberOrTemplate = ctld.numberOfTroops
    end

    if _onboard == nil then
        _onboard = { troops = {} }
    end

    ctld.logTrace(string.format("_troops=%s", ctld.p(_troops)))
    if _troops then
        if type(_numberOrTemplate) == "table" and _numberOrTemplate.jtac
            and not ctld.canRequestJTAC(_heli:getCoalition()) then
            ctld.notifyJTACLimitToGroup(_heli)
            return false
        end
        _onboard.troops = ctld.generateTroopTypes(_heli:getCoalition(), _numberOrTemplate, _heli:getCountry())
        ctld.logTrace(string.format("_onboard.troops=%s", ctld.p(_onboard.troops)))
        trigger.action.outTextForCoalition(_heli:getCoalition(), ctld.getPlayerNameOrType(_heli) .. " погрузил десант в " .. _heli:getTypeName(), 10)
        local _groupId = ctld.getGroupId(_heli)
        if _groupId then trigger.action.outSoundForGroup(_groupId, "Landing_on_board.ogg") end

        ctld.processCallback({unit = _heli, onboard = _onboard.troops, action = "load_troops"})
    end

    ctld.inTransitTroops[_heli:getName()] = _onboard
    ctld.logTrace(string.format("ctld.inTransitTroops=%s", ctld.p(ctld.inTransitTroops[_heli:getName()])))
    ctld.adaptWeightToCargo(_heli:getName())
    return true
end

function ctld.loadTroopsFromZone(_args)

    local _heli = ctld.getTransportUnit(_args[1])
    local _troops = _args[2]
    local _groupTemplate = _args[3] or ""
    local _allowExtract = _args[4]

    if _heli == nil then
        return false
    end

    local _zone = ctld.inPickupZone(_heli)

    if ctld.troopsOnboard(_heli, _troops) then

        ctld.displayMessageToGroup(_heli, "У вас уже есть войска на борту.", 10)

        return false
    end

    local _extract

    if _allowExtract then
        -- сначала проверить доступные для эвакуации войска независимо от нахождения в зоне.
        if _troops then
            if _heli:getCoalition() == 1 then
                _extract = ctld.findNearestGroup(_heli, ctld.droppedTroopsRED)
            else
                _extract = ctld.findNearestGroup(_heli, ctld.droppedTroopsBLUE)
            end
        end
    end

    if _extract ~= nil then
        -- поиск ближайших войск для погрузки.
        return ctld.extractTroops({_heli:getName(), _troops})
    elseif _zone.inZone == true then

        if _zone.limit - 1 >= 0 then
            local _loaded = ctld.loadTroops(_heli, _troops, _groupTemplate)
            if _loaded then
                -- уменьшить счётчик зоны только после успешной загрузки.
                ctld.updateZoneCounter(_zone.index, -1)
                return true
            end
            return false
        else
            ctld.displayMessageToGroup(_heli, "В этом районе больше нет подкреплений для погрузки!", 20)

            return false
        end

    else
        if _allowExtract then
            ctld.displayMessageToGroup(_heli, "Вы находитесь не в зоне погрузки", 10)
        else
            ctld.displayMessageToGroup(_heli, "Вы находитесь не в зоне погрузки", 10)
        end

        return false
    end
end



function ctld.unloadTroops(_args)

    local _heli = ctld.getTransportUnit(_args[1])
    local _troops = _args[2]

    if _heli == nil then
        return false
    end

    local _zone = ctld.inPickupZone(_heli)
    if not ctld.troopsOnboard(_heli, _troops)  then

        ctld.displayMessageToGroup(_heli, "Войск на борту нет, направляйтесь в зону погрузки", 10)

        return false
    else

        -- чтобы попасть сюда, войска должны находиться на борту.
        if not ctld.requireTransportReadyForUnload(_heli) then return false end
        if _zone.inZone == true then

            ctld.displayMessageToGroup(_heli, "Выгруженные бойцы вернулись на базу", 20)

            ctld.processCallback({unit = _heli, unloaded = ctld.inTransitTroops[_heli:getName()].troops, action = "unload_troops_zone"})

            ctld.inTransitTroops[_heli:getName()].troops = nil

            ctld.adaptWeightToCargo(_heli:getName())

            -- увеличить счётчик зоны на 1.
            ctld.updateZoneCounter(_zone.index, 1)

            return true

        elseif ctld.troopsOnboard(_heli, _troops)  then

            return ctld.deployTroops(_heli, _troops)
        end
    end

end

function ctld.extractTroops(_args)

    local _heli = ctld.getTransportUnit(_args[1])
    local _troops = _args[2]

    if _heli == nil then
        return false
    end

    if ctld.inAir(_heli) then
        return false
    end

    if  ctld.troopsOnboard(_heli, _troops)  then
        if _troops then
            ctld.displayMessageToGroup(_heli, "У вас уже есть войска на борту.", 10)
        else
            ctld.displayMessageToGroup(_heli, "У вас уже есть техника на борту.", 10)
        end

        return false
    end

    local _onboard = ctld.inTransitTroops[_heli:getName()]

    if _onboard == nil then
        _onboard = { troops = nil, vehicles = nil }
    end

    local _extracted = false

    if _troops then

        local _extractTroops

        if _heli:getCoalition() == 1 then
            _extractTroops = ctld.findNearestGroup(_heli, ctld.droppedTroopsRED)
        else
            _extractTroops = ctld.findNearestGroup(_heli, ctld.droppedTroopsBLUE)
        end


        if _extractTroops ~= nil then

            local _limit = ctld.getTransportLimit(_heli:getTypeName())

            local _size =  #_extractTroops.group:getUnits()

            if _limit < #_extractTroops.group:getUnits() then

                ctld.displayMessageToGroup(_heli, "Sorry - The group of ".._size.." is too large to fit. \n\nLimit is ".._limit.." for ".._heli:getTypeName(), 20)

                return
            end

            _onboard.troops = _extractTroops.details
            _onboard.troops.weight = #_extractTroops.group:getUnits() * 130 -- default to 130kg per soldier

            if _extractTroops.group:getName():lower():find("jtac")
                or ctld.jtacInfantryGroups[_extractTroops.group:getName()] then
                _onboard.troops.jtac = true
            end

            trigger.action.outTextForCoalition(_heli:getCoalition(), ctld.getPlayerNameOrType(_heli) .. " загрузил десант в " .. _heli:getTypeName() .. " ", 10)

            if _heli:getCoalition() == 1 then
                ctld.droppedTroopsRED[_extractTroops.group:getName()] = nil
            else
                ctld.droppedTroopsBLUE[_extractTroops.group:getName()] = nil
            end

            ctld.processCallback({unit = _heli, extracted = _extractTroops, action = "extract_troops"})

            -- удалить.
            ctld.suppressGeneratedCombatLoss(_extractTroops.group:getName())
            _extractTroops.group:destroy()

            _extracted = true
        else
            _onboard.troops = nil
            ctld.displayMessageToGroup(_heli, "No extractable troops nearby!", 20)
        end

    end

    ctld.inTransitTroops[_heli:getName()] = _onboard
    ctld.adaptWeightToCargo(_heli:getName())

    return _extracted
end


function ctld.checkTroopStatus(_args)
    local _unitName = _args[1]
    -- вывести список войск и ящиков на борту.
    local _heli = ctld.getTransportUnit(_unitName)

    if _heli == nil then
        return
    end

    local _, _message = ctld.getWeightOfCargo(_unitName, _heli:getCoalition())
    ctld.logTrace(string.format("_message=%s", ctld.p(_message)))
    if _message and _message ~= "" then
        local _emptyMessage = ctld.coalitionText(_heli:getCoalition(), "Войск на борту нет, направляйтесь на площадку " .. (_heli:getCoalition() == coalition.side.BLUE and "CSS" or "МТО"))
        ctld.displayMessageToGroup(_heli, _message, 10, false, _message == _emptyMessage)
        if _message == _emptyMessage then
            local _groupId = ctld.getGroupId(_heli)
            if _groupId then trigger.action.outSoundForGroup(_groupId, "no_conditions.ogg") end
        end
    end
end

function ctld.adaptWeightToCargo(unitName)
    local _weight = ctld.getWeightOfCargo(unitName)
    trigger.action.setUnitInternalCargo(unitName, _weight)
end

-- Синхронизирует внутренний груз DCS с грузом именно этого объекта транспорта.
-- При повторном входе в слот DCS может создать новый Unit с прежним именем;
-- в таком случае нельзя переносить запись груза от предыдущего объекта.
function ctld.syncTransportCargo(_unit)
    if not _unit or not _unit:isExist() then return end

    local _unitName = _unit:getName()
    local _unitId = _unit:getID()
    local _previousId = ctld.transportCargoUnitIds[_unitName]
    if _previousId ~= _unitId then
        if _previousId ~= nil then
            ctld.inTransitTroops[_unitName] = nil
            ctld.inTransitSlingLoadCrates[_unitName] = nil
            ctld.hoverStatus[_unitName] = nil
        end
        ctld.transportCargoUnitIds[_unitName] = _unitId
        ctld.adaptWeightToCargo(_unitName)
    end
end

function ctld.getWeightOfCargo(unitName, _side)
    ctld.logDebug(string.format("ctld.getWeightOfCargo(%s)", ctld.p(unitName)))

    local _weight = 0
    local _description = ""

    -- добавить вес войск.
    if ctld.inTransitTroops[unitName] then
        ctld.logTrace("ctld.inTransitTroops = true")
        local _inTransit = ctld.inTransitTroops[unitName]
        if _inTransit then
            ctld.logTrace(string.format("_inTransit=%s", ctld.p(_inTransit)))
            local _troops = _inTransit.troops
            if _troops and _troops.units then
                ctld.logTrace(string.format("_troops.weight=%s", ctld.p(_troops.weight)))
                _description = _description .. string.format("%s бойцов на борту (%s kg)\n", #_troops.units, _troops.weight)
                _weight = _weight + _troops.weight
            end
        end
    end
    ctld.logTrace(string.format("with troops : weight = %s", tostring(_weight)))

    -- добавить вес ящика на имитируемой внешней подвеске.
    local _crate = ctld.inTransitSlingLoadCrates[unitName]
    if _crate then
        ctld.logTrace(string.format("_crate=%s", ctld.p(_crate)))
        if _crate.simulatedSlingload then
            ctld.logTrace(string.format("_crate.weight=%s", ctld.p(_crate.weight)))
            _weight = _weight + _crate.weight
            _description = _description .. string.format("1 %s crate onboard (%s kg)\n", _crate.desc, _crate.weight)
        end
    end
    ctld.logTrace(string.format("with simulated slingload crates : weight = %s", tostring(_weight)))
    if _description ~= "" then
        _description = _description .. string.format("Общий вес груза: %s kg\n", _weight)
    else
        _description = ctld.coalitionText(_side, "Войск на борту нет, направляйтесь на площадку " .. (_side == coalition.side.BLUE and "CSS" or "МТО"))
    end
    ctld.logTrace(string.format("_description = %s", tostring(_description)))

    return _weight, _description
end

function ctld.checkHoverStatus()
    --ctld.logDebug(string.format("ctld.checkHoverStatus()"))
    timer.scheduleFunction(ctld.checkHoverStatus, nil, timer.getTime() + 1.0)

    local _status, _result = pcall(function()

        for _, _name in ipairs(ctld.transportPilotNames) do

            local _reset = true
            local _transUnit = ctld.getTransportUnit(_name)

            if _transUnit ~= nil and ctld.inTransitSlingLoadCrates[_name] == nil and ctld.inAir(_transUnit) then

                --ctld.logTrace(string.format("%s - capable of slingloading", ctld.p(_name)))

                local _crates = ctld.getCratesAndDistance(_transUnit)
                --ctld.logTrace(string.format("_crates = %s", ctld.p(_crates)))

                for _, _crate in pairs(_crates) do
                    --ctld.logTrace(string.format("_crate = %s", ctld.p(_crate)))
                    if _crate.dist < ctld.maxDistanceFromCrate then

                        -- проверить высоту.
                        local _height = _transUnit:getPoint().y - _crate.crateUnit:getPoint().y
                        --env.info("HEIGHT " .. _name .. " " .. _height .. " " .. _transUnit:getPoint().y .. " " .. _crate.crateUnit:getPoint().y)
                        --  ctld.heightDiff(_transUnit)
                        --env.info("HEIGHT ABOVE GROUD ".._name.." ".._height.." ".._transUnit:getPoint().y.." ".._crate.crateUnit:getPoint().y)
                        --ctld.logTrace(string.format("_height = %s", ctld.p(_height)))

                        if _height > ctld.minimumHoverHeight and _height <= ctld.maximumHoverHeight then

                            local _time = ctld.hoverStatus[_transUnit:getName()]
                            --ctld.logTrace(string.format("_time = %s", ctld.p(_time)))

                            if _time == nil then
                                ctld.hoverStatus[_transUnit:getName()] = ctld.hoverTime
                                _time = ctld.hoverTime
                            else
                                _time = ctld.hoverStatus[_transUnit:getName()] - 1
                                ctld.hoverStatus[_transUnit:getName()] = _time
                            end

                            if _time > 0 then
                                -- Звук нужен только в начале отсчёта: «5 секунд».
                                ctld.displayMessageToGroup(_transUnit, "Зависните над ящиком " .. _crate.details.desc .. " crate. \n\nУдерживайте вертолёт над ящиком " .. _time .. " секунд! \n\nДержи, держи Ёшкин кот!", 10, true, _time ~= ctld.hoverTime)
                            else
                                ctld.hoverStatus[_transUnit:getName()] = nil
                                ctld.displayMessageToGroup(_transUnit, "Загружен  " .. _crate.details.desc .. " ящик!", 10,true)

                                -- ящик был перемещён хотя бы один раз.
                                ctld.crateMove[_crate.crateUnit:getName()] = nil

                                if _transUnit:getCoalition() == 1 then
                                    ctld.spawnedCratesRED[_crate.crateUnit:getName()] = nil
                                else
                                    ctld.spawnedCratesBLUE[_crate.crateUnit:getName()] = nil
                                end

                                _crate.crateUnit:destroy()

                                local _copiedCrate = mist.utils.deepCopy(_crate.details)
                                _copiedCrate.simulatedSlingload = true
                                _copiedCrate.side = _transUnit:getCoalition()
                                --ctld.logTrace(string.format("_copiedCrate = %s", ctld.p(_copiedCrate)))
                                ctld.inTransitSlingLoadCrates[_name] = _copiedCrate
                                ctld.adaptWeightToCargo(_name)
                                local _groupId = ctld.getGroupId(_transUnit)
                                if _groupId then trigger.action.outSoundForGroup(_groupId, "Cargo_on_Board.ogg") end
                            end

                            _reset = false

                            break
                        elseif _height <= ctld.minimumHoverHeight then
                            ctld.displayMessageToGroup(_transUnit, "Слишком низко, чтобы зацепить " .. _crate.details.desc .. " груз.\n\nУдерживайте вертолёт над грузом " .. ctld.hoverTime .. " секунд", 5,true)
                            break
                        else
                            ctld.displayMessageToGroup(_transUnit, "Слишком высоко, чтобы зацепить " .. _crate.details.desc .. " груз.\n\nУдерживайте вертолёт над грузом " .. ctld.hoverTime .. " секунд", 5, true)
                            break
                        end
                    end
                end
            end

            if _reset then
                ctld.hoverStatus[_name] = nil
            end
        end
    end)

    if (not _status) then
        env.error(string.format("CTLD ERROR: %s", _result))
    end
end

function ctld.loadNearbyCrate(_name)
    local _transUnit = ctld.getTransportUnit(_name)

    if _transUnit ~= nil  then

        if ctld.inAir(_transUnit) then
            ctld.displayMessageToGroup(_transUnit, "You must land before you can load a crate!", 10,true)
            return
        end

        if ctld.inTransitSlingLoadCrates[_name] == nil then
            local _crates = ctld.getCratesAndDistance(_transUnit)

            for _, _crate in pairs(_crates) do

                if _crate.dist < 50.0 then
                    ctld.displayMessageToGroup(_transUnit, "Loaded  " .. _crate.details.desc .. " crate!", 10,true)

                    if _transUnit:getCoalition() == 1 then
                        ctld.spawnedCratesRED[_crate.crateUnit:getName()] = nil
                    else
                        ctld.spawnedCratesBLUE[_crate.crateUnit:getName()] = nil
                    end

                    ctld.crateMove[_crate.crateUnit:getName()] = nil

                    _crate.crateUnit:destroy()

                    local _copiedCrate = mist.utils.deepCopy(_crate.details)
                    _copiedCrate.simulatedSlingload = true
                    _copiedCrate.side = _transUnit:getCoalition()
                    ctld.inTransitSlingLoadCrates[_name] = _copiedCrate
                    ctld.adaptWeightToCargo(_name)
                    local _groupId = ctld.getGroupId(_transUnit)
                    if _groupId then trigger.action.outSoundForGroup(_groupId, "Cargo_on_Board.ogg") end
                    return
                end
            end

            ctld.displayMessageToGroup(_transUnit, "No Crates within 50m to load!", 10,true)

        else
            -- ящик на борту.
            ctld.displayMessageToGroup(_transUnit, "You already have a "..ctld.inTransitSlingLoadCrates[_name].desc.." crate onboard!", 10,true)
        end
    end


end

function ctld.getClockDirection(_heli, _crate)

    -- Источник: скрипт вертолёта.

    local _position = _crate:getPosition().p -- get position of crate
    local _playerPosition = _heli:getPosition().p -- get position of helicopter
    local _relativePosition = mist.vec.sub(_position, _playerPosition)

    local _playerHeading = mist.getHeading(_heli) -- the rest of the code determines the 'o'clock' bearing of the missile relative to the helicopter

    local _headingVector = { x = math.cos(_playerHeading), y = 0, z = math.sin(_playerHeading) }

    local _headingVectorPerpendicular = { x = math.cos(_playerHeading + math.pi / 2), y = 0, z = math.sin(_playerHeading + math.pi / 2) }

    local _forwardDistance = mist.vec.dp(_relativePosition, _headingVector)

    local _rightDistance = mist.vec.dp(_relativePosition, _headingVectorPerpendicular)

    local _angle = math.atan2(_rightDistance, _forwardDistance) * 180 / math.pi

    if _angle < 0 then
        _angle = 360 + _angle
    end
    _angle = math.floor(_angle * 12 / 360 + 0.5)
    if _angle == 0 then
        _angle = 12
    end

    return _angle
end


function ctld.getCompassBearing(_ref, _unitPos)

    _ref = mist.utils.makeVec3(_ref, 0) -- turn it into Vec3 if it is not already.
    _unitPos = mist.utils.makeVec3(_unitPos, 0) -- turn it into Vec3 if it is not already.

    local _vec = { x = _unitPos.x - _ref.x, y = _unitPos.y - _ref.y, z = _unitPos.z - _ref.z }

    local _dir = mist.utils.getDir(_vec, _ref)

    local _bearing = mist.utils.round(mist.utils.toDegree(_dir), 0)

    return _bearing
end

function ctld.listNearbyCrates(_args)

    local _message = ""

    local _heli = ctld.getTransportUnit(_args[1])

    if _heli == nil then

        return -- no heli!
    end

    local _crates = ctld.getCratesAndDistance(_heli)

    -- сортировка.
    local _sort = function( a,b ) return a.dist < b.dist end
    table.sort(_crates,_sort)

    for _, _crate in pairs(_crates) do

        if _crate.dist < 1000 then
            _message = string.format("%s\n%s контейнер - кг %i - %i м - на %d часов", _message, _crate.details.desc, _crate.details.weight, _crate.dist, ctld.getClockDirection(_heli, _crate.crateUnit))
        end
    end

    if _message ~= "" then
        ctld.displayMessageToGroup(_heli, "Ближайшие грузы:\n" .. _message, 20)

    else
        -- поблизости нет ящиков.

        local _txt = "Рядом нет контейнера, направляйтесь в зону погрузки"

        ctld.displayMessageToGroup(_heli, _txt, 20, false, true)
        local _groupId = ctld.getGroupId(_heli)
        if _groupId then trigger.action.outSoundForGroup(_groupId, "no_conditions.ogg") end
    end
end


function ctld.displayMessageToGroup(_unit, _text, _time,_clear,_noSwitch)

    local _groupId = ctld.getGroupId(_unit)
    if _groupId then
        if _clear == true then
            trigger.action.outTextForGroup(_groupId, _text, _time,_clear)
        else
            trigger.action.outTextForGroup(_groupId, _text, _time)
        end
        if not _noSwitch then
            trigger.action.outSoundForGroup(_groupId, "switch.wav")
        end
    end
end

function ctld.heightDiff(_unit)

    local _point = _unit:getPoint()

    -- env.info("heightunit " .. _point.y)
    --env.info("heightland " .. land.getHeight({ x = _point.x, y = _point.z }))

    return _point.y - land.getHeight({ x = _point.x, y = _point.z })
end

function ctld.getCratesAndDistance(_heli)

    local _crates = {}
    local _heliPoint = _heli:getPoint()

    local _allCrates
    if _heli:getCoalition() == 1 then
        _allCrates = ctld.spawnedCratesRED
    else
        _allCrates = ctld.spawnedCratesBLUE
    end

    for _crateName, _details in pairs(_allCrates) do

        -- получить ящик.
        local _crate = ctld.getCrateObject(_crateName)

        -- работа с ящиками в воздухе нестабильна, поэтому проверяется высота над землёй и скорость.
        if _crate ~= nil and _crate:getLife() > 0
                and (ctld.inAir(_crate) == false) then

            local _dist = ctld.getDistance(_crate:getPoint(), _heliPoint)

            local _crateDetails = { crateUnit = _crate, dist = _dist, details = _details }

            table.insert(_crates, _crateDetails)
        end
    end

    return _crates
end


function ctld.getClosestCrate(_heli, _crates, _type)

    local _closetCrate = nil
    local _shortestDistance = -1
    local _distance = 0

    for _, _crate in pairs(_crates) do

        if (_crate.details.unit == _type or _type == nil) then
            _distance = _crate.dist

            if _distance ~= nil and (_shortestDistance == -1 or _distance < _shortestDistance) then
                _shortestDistance = _distance
                _closetCrate = _crate
            end
        end
    end

    return _closetCrate
end

function ctld.findNearestAASystem(_heli,_aaSystem)

    local _closestHawkGroup = nil
    local _shortestDistance = -1
    local _distance = 0

    local _heliPoint = _heli:getPoint()

    for _groupName, _hawkDetails in pairs(ctld.completeAASystems) do

        local _hawkGroup = Group.getByName(_groupName)

        --  env.info(_groupName..": "..mist.utils.tableShow(_hawkDetails))
        if _hawkGroup ~= nil and _hawkGroup:getCoalition() == _heli:getCoalition() and _hawkDetails[1].system.name == _aaSystem.name then

            local _units = _hawkGroup:getUnits()

            for _, _leader in pairs(_units) do

                if _leader ~= nil and _leader:getLife() > 0 then

                    _distance = ctld.getDistance(_leader:getPoint(), _heliPoint)

                    if _distance ~= nil and (_shortestDistance == -1 or _distance < _shortestDistance) then
                        _shortestDistance = _distance
                        _closestHawkGroup = _hawkGroup
                    end

                    break
                end
            end
        end
    end

    if _closestHawkGroup ~= nil then

        return { group = _closestHawkGroup, dist = _shortestDistance }
    end
    return nil
end

function ctld.getCrateObject(_name)
    local _crate

    if ctld.staticBugWorkaround then
        _crate  = Unit.getByName(_name)
    else
        _crate = StaticObject.getByName(_name)
    end
    return _crate
end



-- Проверяет, достаточно ли ящиков одного вида рядом с выгруженным ящиком.
-- Ящики одного комплекта может доставить любой вертолёт, но они должны
-- находиться не дальше 300 м друг от друга.
function ctld.hasCompleteCrateSet(_side, _crateName)
    local _crates = _side == 1 and ctld.spawnedCratesRED or ctld.spawnedCratesBLUE
    local _details = _crates[_crateName]
    local _crateUnit = ctld.getCrateObject(_crateName)
    if _details == nil or _crateUnit == nil or _crateUnit:getLife() <= 0 then return false end
    if _details.cratesRequired == nil or _details.cratesRequired <= 1 then return true end

    local _count = 1
    for _otherName, _otherDetails in pairs(_crates) do
        if _otherName ~= _crateName and _otherDetails.unit == _details.unit then
            local _otherUnit = ctld.getCrateObject(_otherName)
            if _otherUnit and _otherUnit:getLife() > 0
                and ctld.getDistance(_crateUnit:getPoint(), _otherUnit:getPoint()) <= 300 then
                _count = _count + 1
                if _count >= _details.cratesRequired then return true end
            end
        end
    end
    return false
end

-- Возвращает полный комплект КУБ/БУК возле указанного ящика. В DCS РЛС и
-- пусковые этих ЗРК работают вместе только тогда, когда созданы одной группой.
function ctld.getAutoAASystemCrateSet(_side, _crateName)
    local _crates = _side == 1 and ctld.spawnedCratesRED or ctld.spawnedCratesBLUE
    local _details = _crates[_crateName]
    local _crateUnit = ctld.getCrateObject(_crateName)
    if not _details or not _crateUnit or _crateUnit:getLife() <= 0 then return nil, nil, false end

    for _, _system in pairs(ctld.AASystemTemplate) do
        -- Комплекты собираются автоматически спустя стандартные 30 секунд,
        -- если на площадке уже доставлены все необходимые компоненты.
        if _system.name == "KUB AA System" or _system.name == "BUK AA System"
            or _system.name == "Patriot AA System" or _system.name == "IRIS-T SLM NATO System"
            or _system.name == "HQ-7 NATO System" or _system.name == "Roland NATO System" then
            local _isPart = false
            for _, _part in pairs(_system.parts) do
                if _part.name == _details.unit then _isPart = true break end
            end

            if _isPart then
                local _set = {}
                local _complete = true
                for _, _part in pairs(_system.parts) do
                    local _found = nil
                    for _otherName, _otherDetails in pairs(_crates) do
                        if _otherDetails.unit == _part.name then
                            local _otherUnit = ctld.getCrateObject(_otherName)
                            if _otherUnit and _otherUnit:getLife() > 0
                                and ctld.getDistance(_crateUnit:getPoint(), _otherUnit:getPoint()) <= 500 then
                                _found = { crateUnit = _otherUnit, details = _otherDetails, dist = 0 }
                                break
                            end
                        end
                    end
                    if _found then
                        table.insert(_set, _found)
                    else
                        _complete = false
                    end
                end
                return _system, _set, _complete
            end
        end
    end
    return nil, nil, false
end

function ctld.getAASystemDisplayName(_aaSystem)
    if not _aaSystem then return "ЗРК" end
    local _names = {
        ["KUB AA System"] = "КУБ",
        ["BUK AA System"] = "БУК",
        ["Patriot AA System"] = "Patriot",
        ["IRIS-T SLM NATO System"] = "IRIS",
        ["HQ-7 NATO System"] = "HQ-7",
        ["Roland NATO System"] = "Roland",
    }
    return _names[_aaSystem.name] or _aaSystem.name
end

-- Автоматически разворачивает именно выгруженный ящик, поэтому вертолёту
-- не нужно оставаться рядом с ним в течение отсчёта.
function ctld.autoUnpackDroppedCrate(_args)
    local _heli = ctld.getTransportUnit(_args.heliName)
    local _side = _args.side or (_heli and _heli:getCoalition())
    if _side == nil then return nil end

    local _crates = _side == 1 and ctld.spawnedCratesRED or ctld.spawnedCratesBLUE
    local _details = _crates[_args.crateName]
    local _crateUnit = ctld.getCrateObject(_args.crateName)
    if _details == nil or _crateUnit == nil or _crateUnit:getLife() <= 0 then return nil end

    local _aaSystem, _aaCrates, _aaComplete = ctld.getAutoAASystemCrateSet(_side, _args.crateName)
    if _aaSystem then
        if not _aaComplete then
            if not _args.silentIfIncomplete and _args.deployerGroupId then
                trigger.action.outTextForGroup(_args.deployerGroupId,
                    ctld.coalitionText(_side, "Не полный комплект для развёртывания " .. ctld.getAASystemDisplayName(_aaSystem) .. ". Жду груз."), 10)
                trigger.action.outSoundForGroup(_args.deployerGroupId, "switch.wav")
            end
            return nil
        end

        local _positions, _types = {}, {}
        for _, _aaCrate in pairs(_aaCrates) do
            table.insert(_positions, _aaCrate.crateUnit:getPoint())
            table.insert(_types, _aaCrate.details.unit)
            _crates[_aaCrate.crateUnit:getName()] = nil
            _aaCrate.crateUnit:destroy()
        end

        local _spawnedGroup = ctld.spawnCrateGroup(_heli, _positions, _types,
            _side, _args.country, _args.deployerGroupId)
        if _spawnedGroup then
            ctld.completeAASystems[_spawnedGroup:getName()] = ctld.getAASystemDetails(_spawnedGroup, _aaSystem)
            ctld.processCallback({unit = _heli, crate = { crateUnit = _crateUnit, details = _details, dist = 0 }, spawnedGroup = _spawnedGroup, action = "unpack"})
        end

        local _groupId = _args.deployerGroupId or (_heli and ctld.getGroupId(_heli))
        if _groupId then
            trigger.action.outSoundForGroup(_groupId, "Ready_to_work.ogg")
            trigger.action.outTextForGroup(_groupId, ctld.coalitionText(_side, "Развёртывание груза прошло успешно."), 10)
        elseif _heli then
            ctld.displayMessageToGroup(_heli, ctld.coalitionText(_side, "Развёртывание груза прошло успешно."), 10, false, true)
        end
        return nil
    end

    local _crate = { crateUnit = _crateUnit, details = _details, dist = 0 }
    local _unpackCrates = { _crate }

    if _details.cratesRequired and _details.cratesRequired > 1 then
        for _crateName, _otherDetails in pairs(_crates) do
            if _crateName ~= _args.crateName and _otherDetails.unit == _details.unit then
                local _otherUnit = ctld.getCrateObject(_crateName)
                if _otherUnit and _otherUnit:getLife() > 0
                    and ctld.getDistance(_crateUnit:getPoint(), _otherUnit:getPoint()) <= 300 then
                    table.insert(_unpackCrates, { crateUnit = _otherUnit, details = _otherDetails, dist = 0 })
                    if #_unpackCrates == _details.cratesRequired then break end
                end
            end
        end
        if #_unpackCrates < _details.cratesRequired then
            if _args.silentIfIncomplete then
                return nil
            elseif _args.deployerGroupId then
                trigger.action.outTextForGroup(_args.deployerGroupId, ctld.coalitionText(_side, "Ждём на точке второй комплект груза."), 10)
                trigger.action.outSoundForGroup(_args.deployerGroupId, "switch.wav")
            elseif _heli then
                ctld.displayMessageToGroup(_heli, ctld.coalitionText(_side, "Ждём на точке второй комплект груза."), 10)
            end
            return nil
        end
    end

    local _point = _crateUnit:getPoint()
    for _, _unpackCrate in pairs(_unpackCrates) do
        _crates[_unpackCrate.crateUnit:getName()] = nil
        _unpackCrate.crateUnit:destroy()
    end

    local _spawnedGroup = ctld.spawnCrateGroup(_heli, { _point }, { _details.unit },
        _side, _args.country, _args.deployerGroupId)
    ctld.processCallback({unit = _heli, crate = _crate, spawnedGroup = _spawnedGroup, action = "unpack"})

    if ctld.isJTACUnitType(_details.unit) and ctld.JTAC_dropEnabled then
        local _code = ctld.getJTACLaserCode(_side)
        local _coalition = _heli and _heli:getCoalition() or _side
        timer.scheduleFunction(ctld.activateJTACAfterDelay, {
            groupName = _spawnedGroup:getName(),
            side = _coalition,
            laserCode = _code,
        }, timer.getTime() + 10)
    end

    local _groupId = _args.deployerGroupId or (_heli and ctld.getGroupId(_heli))
    if _groupId then trigger.action.outSoundForGroup(_groupId, "Ready_to_work.ogg") end
    if _groupId then
        trigger.action.outTextForGroup(_groupId, ctld.coalitionText(_side, "Развёртывание груза прошло успешно."), 10)
    elseif _heli then
        ctld.displayMessageToGroup(_heli, ctld.coalitionText(_side, "Развёртывание груза прошло успешно."), 10, false, true)
    end
    return nil
end

-- Выгружает ящик с внешней подвески, когда вертолёт на земле или на высоте 4,5–10 м.
function ctld.dropSlingCrate(_args)
    local _heli = ctld.getTransportUnit(_args[1])

    if _heli == nil then
        return -- no heli!
    end

    local _currentCrate = ctld.inTransitSlingLoadCrates[_heli:getName()]

    if _currentCrate == nil then
        ctld.displayMessageToGroup(_heli, "На борту контейнер не погружен.", 10, false, true)
        local _groupId = ctld.getGroupId(_heli)
        if _groupId then trigger.action.outSoundForGroup(_groupId, "no_conditions.ogg") end
    else

        if not ctld.requireTransportReadyForUnload(_heli) then return end
        local _heli = ctld.getTransportUnit(_args[1])

        local _point = _heli:getPoint()

        local _unitId = ctld.getNextUnitId()

        local _side = _heli:getCoalition()

        local _name = string.format("%s #%i", _currentCrate.desc, _unitId)


        local _heightDiff = ctld.heightDiff(_heli)

        if ctld.inAir(_heli) == false or _heightDiff <= 7.5 then
            ctld.displayMessageToGroup(_heli, _currentCrate.desc .. " контейнер был успешно отсоединен и находится перед вами", 10)
            _point = ctld.getPointAt12Oclock(_heli, 30)
            --        elseif _heightDiff > 40.0 then
            --            ctld.inTransitSlingLoadCrates[_heli:getName()] = nil
            --            ctld.displayMessageToGroup(_heli, "Ты был слишком высоко, ящик уничтожен", 10)
            --            return
        elseif _heightDiff > 7.5 and _heightDiff <= 40.0 then
            ctld.displayMessageToGroup(_heli, _currentCrate.desc .. " контейнер благополучно сброшен под вами", 10)
        else -- _heightDiff > 40.0
            ctld.inTransitSlingLoadCrates[_heli:getName()] = nil
            ctld.adaptWeightToCargo(_heli:getName())
            ctld.displayMessageToGroup(_heli, "Ты был слишком высоко, контейнер уничтожен", 10)
            return
        end


        -- убрать ящик из груза.
        ctld.inTransitSlingLoadCrates[_heli:getName()] = nil
        ctld.adaptWeightToCargo(_heli:getName())
        local _spawnedCrate = ctld.spawnCrateStatic(_heli:getCountry(), _unitId, _point, _name, _currentCrate.weight,_side)

        -- Звук и отсчёт выдаются только группе, выгрузившей конкретный ящик.
        local _groupId = ctld.getGroupId(_heli)
        local _completeSet = ctld.hasCompleteCrateSet(_side, _name)
        local _aaSystem, _, _aaComplete = ctld.getAutoAASystemCrateSet(_side, _name)
        if _aaSystem then _completeSet = _aaComplete end
        if _groupId then
            if _currentCrate.cratesRequired and _currentCrate.cratesRequired > 1 and not _completeSet then
                trigger.action.outSoundForGroup(_groupId, "second_required.ogg")
            else
                trigger.action.outSoundForGroup(_groupId, "cargo_has_been.ogg")
            end
        end
        if _completeSet then
            ctld.displayMessageToGroup(_heli, ctld.coalitionText(_side, "Развёртывание груза ~ 30 секунд."), 10, false, true)
        elseif _aaSystem then
            local _systemName = ctld.getAASystemDisplayName(_aaSystem)
            ctld.displayMessageToGroup(_heli, ctld.coalitionText(_side, "Не полный комплект для развёртывания " .. _systemName .. ". Жду груз."), 10, false, true)
        else
            ctld.displayMessageToGroup(_heli, ctld.coalitionText(_side, "Ждём на точке второй комплект груза."), 10, false, true)
        end
        -- Проверка всегда откладывается на 30 секунд: DCS может создать
        -- статичный ящик с небольшой задержкой, а второй ящик может быть
        -- доставлен другим вертолётом.
        timer.scheduleFunction(ctld.autoUnpackDroppedCrate,
            {
                heliName = _heli:getName(),
                crateName = _name,
                side = _side,
                country = _heli:getCountry(),
                deployerGroupId = _groupId,
                silentIfIncomplete = true,
            }, timer.getTime() + ctld.autoUnpackDelay)
    end
end

function ctld.getAATemplate(_unitName)

    for _,_system in pairs(ctld.AASystemTemplate) do

        if _system.repair == _unitName then
            return _system
        end

        for _,_part in pairs(_system.parts) do

            if _unitName == _part.name  then
                return _system
            end
        end
    end

    return nil

end

function ctld.getLauncherUnitFromAATemplate(_aaTemplate)
    for _,_part in pairs(_aaTemplate.parts) do

        if _part.launcher then
            return _part.name
        end
    end

    return nil
end

function ctld.rearmAASystem(_heli, _nearestCrate, _nearbyCrates, _aaSystemTemplate)

    -- добавляется ли часть к существующей системе ПВО?
    -- проверить, является ли ящик пусковой установкой.
    if ctld.getLauncherUnitFromAATemplate(_aaSystemTemplate) == _nearestCrate.details.unit then

        -- найти ближайшую ПОЛНОСТЬЮ СОБРАННУЮ систему ПВО.
        local _nearestSystem = ctld.findNearestAASystem(_heli, _aaSystemTemplate)

        if _nearestSystem ~= nil and _nearestSystem.dist < 300 then

            local _uniqueTypes = {} -- stores each unique part of system
            local _types = {}
            local _points = {}

            local _units = _nearestSystem.group:getUnits()

            if _units ~= nil and #_units > 0 then

                for x = 1, #_units do
                    if _units[x]:getLife() > 0 then

                        -- позволяет учитывать каждый тип только один раз.
                        _uniqueTypes[_units[x]:getTypeName()] = _units[x]:getTypeName()

                        table.insert(_points, _units[x]:getPoint())
                        table.insert(_types, _units[x]:getTypeName())
                    end
                end
            end

            -- есть ли нужное число уникальных частей и точек для всех частей.
            if ctld.countTableEntries(_uniqueTypes) == _aaSystemTemplate.count and #_points >= _aaSystemTemplate.count then

                -- перезарядить систему ПВО.
                -- уничтожить старую группу.
                ctld.completeAASystems[_nearestSystem.group:getName()] = nil
                ctld.suppressGeneratedCombatLoss(_nearestSystem.group:getName())
                _nearestSystem.group:destroy()

                local _spawnedGroup = ctld.spawnCrateGroup(_heli, _points, _types)

                ctld.completeAASystems[_spawnedGroup:getName()] = ctld.getAASystemDetails(_spawnedGroup, _aaSystemTemplate)

                ctld.processCallback({unit = _heli, crate =  _nearestCrate , spawnedGroup = _spawnedGroup, action = "rearm"})

                trigger.action.outTextForCoalition(_heli:getCoalition(), ctld.getPlayerNameOrType(_heli) .. " успешно полностью перезарядил ".._aaSystemTemplate.name.." in the field", 10)

                if _heli:getCoalition() == 1 then
                    ctld.spawnedCratesRED[_nearestCrate.crateUnit:getName()] = nil
                else
                    ctld.spawnedCratesBLUE[_nearestCrate.crateUnit:getName()] = nil
                end

                -- удалить ящик.
           --     if ctld.slingLoad == false then
                    _nearestCrate.crateUnit:destroy()
              --  end

                return true -- all done so quit
            end
        end
    end

    return false
end

function ctld.getAASystemDetails(_hawkGroup,_aaSystemTemplate)

    local _units = _hawkGroup:getUnits()

    local _hawkDetails = {}

    for _, _unit in pairs(_units) do
        table.insert(_hawkDetails, { point = _unit:getPoint(), unit = _unit:getTypeName(), name = _unit:getName(), system =_aaSystemTemplate})
    end

    return _hawkDetails
end

function ctld.countTableEntries(_table)

    if _table == nil then
        return 0
    end


    local _count = 0

    for _key, _value in pairs(_table) do

        _count = _count + 1
    end

    return _count
end

function ctld.unpackAASystem(_heli, _nearestCrate, _nearbyCrates,_aaSystemTemplate)

    if ctld.rearmAASystem(_heli, _nearestCrate, _nearbyCrates,_aaSystemTemplate) then
        -- перезаряженный HAWK.
        return
    end

    -- все ли части расположены достаточно близко друг к другу.
    local _systemParts = {}

    -- инициализировать список частей.
    for _,_part in pairs(_aaSystemTemplate.parts) do
        _systemParts[_part.name] = {name = _part.name,desc = _part.desc,found = false}
    end

    -- найти ближайшие ящики и добавить их в список, если они относятся к системе ПВО.
    for _, _nearbyCrate in pairs(_nearbyCrates) do

        if _nearbyCrate.dist < 500 then

            if _systemParts[_nearbyCrate.details.unit] ~= nil and _systemParts[_nearbyCrate.details.unit].found == false  then
                local _foundPart = _systemParts[_nearbyCrate.details.unit]

                _foundPart.found = true
                _foundPart.crate = _nearbyCrate

                _systemParts[_nearbyCrate.details.unit] = _foundPart
            end
        end
    end

    local _count = 0
    local _txt = ""

    local _posArray = {}
    local _typeArray = {}
    for _name, _systemPart in pairs(_systemParts) do

        if _systemPart.found == false then
            _txt = _txt.."Missing ".._systemPart.desc.."\n"
        else

            local _launcherPart = ctld.getLauncherUnitFromAATemplate(_aaSystemTemplate)

            -- обработать несколько пусковых установок из одного ящика.
            if (_name == "Hawk ln" and ctld.hawkLaunchers > 1)
                    or (_launcherPart == _name and ctld.aaLaunchers  > 1) then

                -- добавить несколько пусковых установок.
                local _launchers = ctld.aaLaunchers

                if _name == "Hawk ln" then
                    _launchers = ctld.hawkLaunchers
                end

                for _i = 1, _launchers do

                    -- создать по кругу вокруг ящика.
                    local _angle = math.pi * 2 * (_i - 1) / _launchers
                    local _xOffset = math.cos(_angle) * 12
                    local _yOffset = math.sin(_angle) * 12

                    local _point = _systemPart.crate.crateUnit:getPoint()

                    _point = { x = _point.x + _xOffset, y = _point.y, z = _point.z + _yOffset }

                    table.insert(_posArray, _point)
                    table.insert(_typeArray, _name)
                end
            else
                table.insert(_posArray, _systemPart.crate.crateUnit:getPoint())
                table.insert(_typeArray, _name)
            end
        end
    end

    local _activeLaunchers = ctld.countCompleteAASystems(_heli)

    local _allowed = ctld.getAllowedAASystems(_heli)

    env.info("Active: ".._activeLaunchers.." Allowed: ".._allowed)

    if _activeLaunchers + 1 > _allowed then
        trigger.action.outTextForCoalition(_heli:getCoalition(), "Нет частей для ЗРК. Ограниечние ".._allowed.." \n", 10)
        return
    end

    if _txt ~= ""  then
        ctld.displayMessageToGroup(_heli, "Невозможно построить ".._aaSystemTemplate.name.."\n" .. _txt .. "\n\nИли грузы расположены недостаточно близко друг к другу", 20)
        return
    else

        -- уничтожить ящики.
        for _name, _systemPart in pairs(_systemParts) do

            if _heli:getCoalition() == 1 then
                ctld.spawnedCratesRED[_systemPart.crate.crateUnit:getName()] = nil
            else
                ctld.spawnedCratesBLUE[_systemPart.crate.crateUnit:getName()] = nil
            end

            -- уничтожить.
           -- if ctld.slingLoad == false then
                _systemPart.crate.crateUnit:destroy()
            --end
        end

        -- HAWK / БУК ГОТОВЫ!
        local _spawnedGroup = ctld.spawnCrateGroup(_heli, _posArray, _typeArray)

        ctld.completeAASystems[_spawnedGroup:getName()] = ctld.getAASystemDetails(_spawnedGroup,_aaSystemTemplate)

        ctld.processCallback({unit = _heli, crate = _nearestCrate , spawnedGroup = _spawnedGroup, action = "unpack"})

        trigger.action.outTextForCoalition(_heli:getCoalition(), ctld.getPlayerNameOrType(_heli) .. " успешно полностью развернул ЗРК ".._aaSystemTemplate.name.." to the field. \n\nAA Active System limit is: ".._allowed.."\nActive: "..(_activeLaunchers+1), 10)

    end
end

-- Подсчитывает количество захваченных городов и задаёт число разрешённых систем ПВО.
function ctld.getAllowedAASystems(_heli)

    if _heli:getCoalition() == 1 then
        return ctld.AASystemLimitBLUE
    else
        return ctld.AASystemLimitRED
    end


end


function ctld.countCompleteAASystems(_heli)

    local _count = 0

    for _groupName, _hawkDetails in pairs(ctld.completeAASystems) do

        local _hawkGroup = Group.getByName(_groupName)

        --  env.info(_groupName..": "..mist.utils.tableShow(_hawkDetails))
        if _hawkGroup ~= nil and _hawkGroup:getCoalition() == _heli:getCoalition() then

            local _units = _hawkGroup:getUnits()

            if _units ~=nil and #_units > 0 then
                -- получить шаблон системы.
                local _aaSystemTemplate = _hawkDetails[1].system

                local _uniqueTypes = {} -- stores each unique part of system
                local _types = {}
                local _points = {}

                if _units ~= nil and #_units > 0 then

                    for x = 1, #_units do
                        if _units[x]:getLife() > 0 then

                            -- позволяет учитывать каждый тип только один раз.
                            _uniqueTypes[_units[x]:getTypeName()] = _units[x]:getTypeName()

                            table.insert(_points, _units[x]:getPoint())
                            table.insert(_types, _units[x]:getTypeName())
                        end
                    end
                end

                -- есть ли нужное число уникальных частей и точек для всех частей.
                if ctld.countTableEntries(_uniqueTypes) == _aaSystemTemplate.count and #_points >= _aaSystemTemplate.count then
                    _count = _count +1
                end
            end
        end
    end

    return _count
end


function ctld.repairAASystem(_heli, _nearestCrate,_aaSystem)

    -- найти ближайшую ПОЛНОСТЬЮ СОБРАННУЮ систему ПВО.
    local _nearestHawk = ctld.findNearestAASystem(_heli,_aaSystem)



    if _nearestHawk ~= nil and _nearestHawk.dist < 300 then

        local _oldHawk = ctld.completeAASystems[_nearestHawk.group:getName()]

        -- создать новую.

        local _types = {}
        local _points = {}

        for _, _part in pairs(_oldHawk) do
            table.insert(_points, _part.point)
            table.insert(_types, _part.unit)
        end

        -- удалить старую систему.
        ctld.completeAASystems[_nearestHawk.group:getName()] = nil
        ctld.suppressGeneratedCombatLoss(_nearestHawk.group:getName())
        _nearestHawk.group:destroy()

        local _spawnedGroup = ctld.spawnCrateGroup(_heli, _points, _types)

        ctld.completeAASystems[_spawnedGroup:getName()] = ctld.getAASystemDetails(_spawnedGroup,_aaSystem)

        ctld.processCallback({unit = _heli, crate = _nearestCrate , spawnedGroup = _spawnedGroup, action = "repair"})

        trigger.action.outTextForCoalition(_heli:getCoalition(), ctld.getPlayerNameOrType(_heli) .. " успешно произвел ремонт ЗРК ".._aaSystem.name..".", 10)

        if _heli:getCoalition() == 1 then
            ctld.spawnedCratesRED[_nearestCrate.crateUnit:getName()] = nil
        else
            ctld.spawnedCratesBLUE[_nearestCrate.crateUnit:getName()] = nil
        end

        -- удалить ящик.
       -- if ctld.slingLoad == false then
            _nearestCrate.crateUnit:destroy()
       -- end

    else
        ctld.displayMessageToGroup(_heli, "Невозможно отремонтировать  ".._aaSystem.name..". Нет поврежденных частей ЗРК ".._aaSystem.name.." в радиусе 300 метров", 10)
    end
end

function ctld.unpackMultiCrate(_heli, _nearestCrate, _nearbyCrates)

    -- развернуть комплект из нескольких ящиков.
    local _nearbyMultiCrates = {}

    for _, _nearbyCrate in pairs(_nearbyCrates) do

        if _nearbyCrate.dist < 300 then

            if _nearbyCrate.details.unit == _nearestCrate.details.unit then

                table.insert(_nearbyMultiCrates, _nearbyCrate)

                if #_nearbyMultiCrates == _nearestCrate.details.cratesRequired then
                    break
                end
            end
        end
    end

    --- проверить количество ящиков.
    if #_nearbyMultiCrates == _nearestCrate.details.cratesRequired then

        local _point = _nearestCrate.crateUnit:getPoint()

        -- уничтожить ящики.
        for _, _crate in pairs(_nearbyMultiCrates) do

            if _point == nil then
                _point = _crate.crateUnit:getPoint()
            end

            if _heli:getCoalition() == 1 then
                ctld.spawnedCratesRED[_crate.crateUnit:getName()] = nil
            else
                ctld.spawnedCratesBLUE[_crate.crateUnit:getName()] = nil
            end

            -- уничтожить.
         --   if ctld.slingLoad == false then
                _crate.crateUnit:destroy()
         --   end
        end


        local _spawnedGroup = ctld.spawnCrateGroup(_heli, { _point }, { _nearestCrate.details.unit })

        ctld.processCallback({unit = _heli, crate =  _nearestCrate , spawnedGroup = _spawnedGroup, action = "unpack"})

        local _txt = string.format("%s успешно распаковал %s ,используя %d контейнеров", ctld.getPlayerNameOrType(_heli), _nearestCrate.details.desc, #_nearbyMultiCrates)

        trigger.action.outTextForCoalition(_heli:getCoalition(), _txt, 10)

    else

        local _txt = string.format("Невозможно построить %s!\n\nТребуется %d контейнеров и уже есть %d \n\nИли нет контейнеров в радиусе 300 м. друг от друга", _nearestCrate.details.desc, _nearestCrate.details.cratesRequired, #_nearbyMultiCrates)
        
	ctld.displayMessageToGroup(_heli, _txt, 20)
    end
end


function ctld.registerGeneratedCombatGroup(_group, _kind)
    if not _group or not _group:isExist() then return end
    ctld.generatedCombatGroups[_group:getName()] = {
        coalition = _group:getCoalition(),
        kind = _kind or "combat",
    }
end

function ctld.suppressGeneratedCombatLoss(_groupName)
    ctld.suppressedCombatLossGroups[_groupName] = true
end

function ctld.notifyGeneratedCombatContact(_group, _unit)
    if not _group or not _unit then return end
    local _details = ctld.generatedCombatGroups[_group:getName()]
    if not _details or _details.contactNotified or _details.contactQueued then return end

    local _unitType = _unit:getTypeName()
    local _label = ctld.combatContactUnitNames[_unitType]
    if not _label then
        if _details.kind == "air_defense" or ctld.airDefenseContactUnitTypes[_unitType] then
            _label = "ПВО"
        elseif _details.kind == "assault" then
            _label = "Пехота в бою"
        else
            return
        end
    end

    _details.contactQueued = true
    timer.scheduleFunction(function(_args)
        local _currentDetails = ctld.generatedCombatGroups[_args.groupName]
        local _currentGroup = Group.getByName(_args.groupName)
        if not _currentDetails or not _currentGroup or not _currentGroup:isExist()
                or _currentDetails.contactNotified then
            return nil
        end
        _currentDetails.contactQueued = nil
        _currentDetails.contactNotified = true
        ctld.notifySwitchCoalition(_currentDetails.coalition,
            ctld.coalitionText(_currentDetails.coalition, _args.label .. " - огневой контакт!"), 16)
        return nil
    end, { groupName = _group:getName(), label = _label }, timer.getTime() + 4)
end

function ctld.generatedCombatEventHandler:onEvent(_event)
    if not _event or not _event.initiator then return end
    local _group = _event.initiator:getGroup()
    if not _group then return end
    local _groupName = _group:getName()
    local _details = ctld.generatedCombatGroups[_groupName]
    if not _details then return end

    if _event.id == world.event.S_EVENT_SHOT then
        ctld.notifyGeneratedCombatContact(_group, _event.initiator)
        return
    end
    if _event.id ~= world.event.S_EVENT_DEAD then return end

    timer.scheduleFunction(function(_args)
        if not ctld.generatedCombatGroups[_args.groupName] then return nil end
        local _current = Group.getByName(_args.groupName)
        if _current and _current:isExist() then
            for _, _unit in ipairs(_current:getUnits() or {}) do
                if _unit and _unit:isExist() and _unit:getLife() > 0 then return nil end
            end
        end

        ctld.generatedCombatGroups[_args.groupName] = nil
        if ctld.suppressedCombatLossGroups[_args.groupName] then
            ctld.suppressedCombatLossGroups[_args.groupName] = nil
            return nil
        end
        -- У этих групп есть собственные сообщения с указанием роли.
        if _args.kind == "assault" or _args.kind == "mortar" or _args.kind == "spotter" then return nil end

        local _message = _args.kind == "bunker"
            and "Огневая позиция уничтожена противником. Задача сорвана."
            or "Боевая единица уничтожена противником. Задача сорвана."
        ctld.notifySwitchCoalition(_args.coalition,
            ctld.coalitionText(_args.coalition, _message), 12)
        return nil
    end, { groupName = _groupName, coalition = _details.coalition, kind = _details.kind }, timer.getTime() + 0.5)
end

function ctld.spawnCrateGroup(_heli, _positions, _types, _side, _country, _deployerGroupId)

    local _id = ctld.getNextGroupId()

    local _groupName = _types[1] .. "  #" .. _id

    _side = _side or (_heli and _heli:getCoalition())
    _country = _country or (_heli and _heli:getCountry())
    if _side == nil or _country == nil then return nil end

    local _group = {
        ["visible"] = false,
       -- ["groupId"] = _id,
        ["hidden"] = false,
        ["units"] = {},
        --        ["y"] = _positions[1].z,
        --        ["x"] = _positions[1].x,
        ["name"] = _groupName,
        ["task"] = {},
    }

    if #_positions == 1 then

        local _unitId = ctld.getNextUnitId()
        local _details = { type = _types[1], unitId = _unitId, name = string.format("Unpacked %s #%i", _types[1], _unitId) }

        _group.units[1] = ctld.createUnit(_positions[1].x + 5, _positions[1].z + 5, 120, _details)

    else

        for _i, _pos in ipairs(_positions) do

            local _unitId = ctld.getNextUnitId()
            local _details = { type = _types[_i], unitId = _unitId, name = string.format("Unpacked %s #%i", _types[_i], _unitId) }

            _group.units[_i] = ctld.createUnit(_pos.x + 5, _pos.z + 5, 120, _details)
        end
    end

    -- функция MiST.
    _group.category = Group.Category.GROUND
    _group.country = _country

    local _spawnedGroup = Group.getByName(mist.dynAdd(_group).name)

    ctld.registerGeneratedCombatGroup(_spawnedGroup, _types[1] == "Bunker" and "bunker" or "combat")

    if ctld.registerAutoGroundGroup then
        ctld.registerAutoGroundGroup(_spawnedGroup, _types[1], _deployerGroupId or (_heli and ctld.getGroupId(_heli)))
    end
    return _spawnedGroup
end

-- Создать обычную группу.
function ctld.spawnDroppedGroup(_point, _details, _spawnBehind, _maxSearch)

    local _groupName = _details.groupName

    local _group = {
        ["visible"] = false,
      --  ["groupId"] = _details.groupId,
        ["hidden"] = false,
        ["units"] = {},
        --        ["y"] = _positions[1].z,
        --        ["x"] = _positions[1].x,
        ["name"] = _groupName,
        ["task"] = {},
    }


    if _spawnBehind == false then

        -- создать по кругу вокруг вертолёта.

        local _pos = _point

        for _i, _detail in ipairs(_details.units) do

            local _angle = math.pi * 2 * (_i - 1) / #_details.units
            local _xOffset = math.cos(_angle) * 30
            local _yOffset = math.sin(_angle) * 30

            _group.units[_i] = ctld.createUnit(_pos.x + _xOffset, _pos.z + _yOffset, _angle, _detail)
        end

    else

        local _pos = _point

        -- попытаться создать в положении «на 6 часов» от нас.
        local _angle = math.atan2(_pos.z, _pos.x)
        local _xOffset = math.cos(_angle) * -30
        local _yOffset = math.sin(_angle) * -30


        for _i, _detail in ipairs(_details.units) do
            _group.units[_i] = ctld.createUnit(_pos.x + (_xOffset + 10 * _i), _pos.z + (_yOffset + 10 * _i), _angle, _detail)
        end
    end

    -- переключить на MiST.
    _group.category = Group.Category.GROUND;
    _group.country = _details.country;

    local _spawnedGroup = Group.getByName(mist.dynAdd(_group).name)

    local _combatKind = "combat"
    if _details.taskName == "Штурмовой взвод" or _details.taskName == "Противотанковый расчет" then
        _combatKind = "assault"
    elseif _details.taskName == "Взвод ПЗРК" then
        _combatKind = "air_defense"
    elseif _details.taskName == "Минометная батарея" then
        _combatKind = "mortar"
    elseif _details.taskName == "ПАН разведчик" or _details.taskName == "Разведчик JTAC" then
        _combatKind = "spotter"
    end
    ctld.registerGeneratedCombatGroup(_spawnedGroup, _combatKind)

    --local _spawnedGroup = coalition.addGroup(_details.country, Group.Category.GROUND, _group)

    -- Любая выгруженная пехота остаётся активной, даже если у неё нет
    -- отдельного алгоритма поиска цели.
    local _controller = _spawnedGroup and _spawnedGroup:getController()
    if _controller then
        pcall(function() _controller:setOnOff(true) end)
        pcall(function()
            Controller.setOption(_controller, AI.Option.Ground.id.ALARM_STATE, AI.Option.Ground.val.ALARM_STATE.AUTO)
            Controller.setOption(_controller, AI.Option.Ground.id.ROE, AI.Option.Ground.val.ROE.OPEN_FIRE)
        end)
    end


    -- Только назначенные ниже группы получают автоматический поиск целей.
    -- Остальные сохраняют штатное поведение CTLD.
    if _details.autoRole then
        ctld.registerAutoGroundGroup(_spawnedGroup, _details.autoRole, _details.deployerGroupId, _details.taskName, _details.country)
    else
        if _maxSearch == nil then _maxSearch = ctld.maximumSearchDistance end
        local _enemyPos = ctld.findNearestEnemy(_details.side, _point, _maxSearch)
        ctld.orderGroupToMoveToPoint(_spawnedGroup:getUnit(1), _enemyPos, ctld.infantryMarchSpeed)
    end

    return _spawnedGroup
end

function ctld.findNearestEnemy(_side, _point, _searchDistance)

    local _closestEnemy = nil

    local _groups

    local _closestEnemyDist = _searchDistance

    local _heliPoint = _point

    if _side == 2 then
        _groups = coalition.getGroups(1, Group.Category.GROUND)
    else
        _groups = coalition.getGroups(2, Group.Category.GROUND)
    end

    for _, _group in pairs(_groups) do

        if _group ~= nil then
            local _units = _group:getUnits()

            if _units ~= nil and #_units > 0 then

                local _leader = nil

                -- найти живого ведущего юнита.
                for x = 1, #_units do
                    if _units[x]:getLife() > 0 then
                        _leader = _units[x]
                        break
                    end
                end

                if _leader ~= nil then
                    local _leaderPos = _leader:getPoint()
                    local _dist = ctld.getDistance(_heliPoint, _leaderPos)
                    if _dist < _closestEnemyDist then
                        _closestEnemyDist = _dist
                        _closestEnemy = _leaderPos
                    end
                end
            end
        end
    end


    -- противника нет — двигаться к случайной точке.
    if _closestEnemy ~= nil then

        -- env.info("противник найден")
        return _closestEnemy
    else

        local _x = _heliPoint.x + math.random(0, ctld.maximumMoveDistance) - math.random(0, ctld.maximumMoveDistance)
        local _z = _heliPoint.z + math.random(0, ctld.maximumMoveDistance) - math.random(0, ctld.maximumMoveDistance)
        local _y = _heliPoint.y + math.random(0, ctld.maximumMoveDistance) - math.random(0, ctld.maximumMoveDistance)

        return { x = _x, z = _z,y=_y }
    end
end

-- Простой одноразовый поиск для выгруженных CTLD-групп: только наземные цели.
-- Поиск запускается через 10 секунд после появления, без постоянного сканирования карты.
function ctld.registerAutoGroundGroup(_group, _unitTypeOrRole, _deployerGroupId, _taskName, _country)
    if not _group or not _group:isExist() then return end
    -- Вся распакованная техника остаётся активной. Исключение составляют
    -- только РЗО, которые удаляются своим отдельным алгоритмом после залпа.
    local _controller = _group:getController()
    if _unitTypeOrRole ~= "CHAP_TOS1A" and _unitTypeOrRole ~= "Grad-URAL" and _controller then
        pcall(function() _controller:setOnOff(true) end)
        pcall(function()
            Controller.setOption(_controller, AI.Option.Ground.id.ALARM_STATE, AI.Option.Ground.val.ALARM_STATE.AUTO)
            Controller.setOption(_controller, AI.Option.Ground.id.ROE, AI.Option.Ground.val.ROE.OPEN_FIRE)
        end)
    end
    if ctld.standardActiveUnitTypes[_unitTypeOrRole] then
        if _controller then
            pcall(function() _controller:setOnOff(true) end)
            pcall(function()
                Controller.setOption(_controller, AI.Option.Ground.id.ALARM_STATE, AI.Option.Ground.val.ALARM_STATE.AUTO)
            end)
            pcall(function()
                Controller.setOption(_controller, AI.Option.Ground.id.ROE, AI.Option.Ground.val.ROE.OPEN_FIRE)
            end)
        end
        return
    end
    local _role = _unitTypeOrRole
    if ctld.autoAttackUnitTypes[_unitTypeOrRole] then _role = "attack" end
    if ctld.autoReconUnitTypes[_unitTypeOrRole] then _role = "recon" end
    if ctld.autoSupportUnitTypes[_unitTypeOrRole] then _role = "support" end
    if ctld.autoArtilleryUnitTypes[_unitTypeOrRole] then _role = "artillery" end
    local _isMortar = _unitTypeOrRole == "mortar" or _unitTypeOrRole == "2B11 mortar"
    if _isMortar then _role = "artillery" end
    if _role ~= "attack" and _role ~= "artillery" and _role ~= "recon" and _role ~= "support" then return end
    local _profile = ctld.autoGroundAttackProfiles[_unitTypeOrRole]
        or ctld.autoGroundAttackProfiles[_role]
    local _args = {
        groupName = _group:getName(),
        unitType = _unitTypeOrRole,
        role = _role,
        profile = _profile,
        deployerGroupId = _deployerGroupId,
        stationary = _isMortar,
        jtacInfantry = _unitTypeOrRole == "ПАН разведчик",
        infantryAssault = _unitTypeOrRole == "attack"
            and (_taskName == "Штурмовой взвод" or _taskName == "Противотанковый расчет"),
        taskName = _taskName,
        country = _country or (_group and _group:getUnit(1) and _group:getUnit(1):getCountry()),
        coalition = _group:getCoalition(),
        failureNotified = false,
        searchRange = _unitTypeOrRole == "ПАН разведчик" and ctld.jtacReconSearchRange
            or (_isMortar and ctld.autoMortarSearchRange or nil),
    }
    if _role == "recon" then
        local _controller = _group:getController()
        if _controller then pcall(function() _controller:setOnOff(true) end) end
        timer.scheduleFunction(ctld.updateReconGroundGroup, _args, timer.getTime() + ctld.autoGroundSearchDelay)
    elseif _role == "support" then
        timer.scheduleFunction(ctld.updateSupportGroundGroup, _args, timer.getTime() + ctld.autoSupportCheckDelay)
    elseif _role == "artillery" then
        timer.scheduleFunction(ctld.updateArtilleryGroundGroup, _args, timer.getTime() + ctld.autoGroundSearchDelay)
    elseif _role == "attack" and _args.infantryAssault then
        timer.scheduleFunction(ctld.updateInfantryAssaultGroup, _args, timer.getTime() + ctld.autoGroundSearchDelay)
    else
        if _role == "attack" then
            timer.scheduleFunction(ctld.captureInitialGroundTarget, _args, timer.getTime() + 0.1)
        end
        timer.scheduleFunction(ctld.acquireAutoGroundTarget, _args, timer.getTime() + ctld.autoGroundSearchDelay)
    end
end

local function ctldSetGroundCombatReady(_group)
    if not _group or not _group:isExist() then return end
    local _controller = _group:getController()
    if _controller then
        pcall(function() _controller:setOnOff(true) end)
        pcall(function()
            Controller.setOption(_controller, AI.Option.Ground.id.ALARM_STATE, AI.Option.Ground.val.ALARM_STATE.AUTO)
            Controller.setOption(_controller, AI.Option.Ground.id.ROE, AI.Option.Ground.val.ROE.OPEN_FIRE)
        end)
    end
end

-- Останавливает РЗО и выдаёт ей задачу полного огня по району позиции цели.
local function ctldSetGroundAttackTarget(_group, _targetUnit, _deployerGroupId, _unitType)
    if not _group or not _group:isExist() or not _targetUnit or not _targetUnit:isExist() then return end
    local _controller = _group:getController()
    if not _controller then return end

    local _targetPoint = _targetUnit:getPoint()
    pcall(function()
        _controller:setOnOff(true)
        Controller.setOption(_controller, AI.Option.Ground.id.ALARM_STATE, AI.Option.Ground.val.ALARM_STATE.AUTO)
        Controller.setOption(_controller, AI.Option.Ground.id.ROE, AI.Option.Ground.val.ROE.OPEN_FIRE)
    end)

    -- DCS надёжнее принимает FireAtPoint как добавленную боевую задачу после
    -- завершения текущего маршрута, а не как немедленную основную задачу.
    timer.scheduleFunction(function(_args)
        local _attackGroup = Group.getByName(_args.groupName)
        if not _attackGroup or not _attackGroup:isExist() then return nil end
        local _attackController = _attackGroup:getController()
        if not _attackController then return nil end
        local _fireTask = {
            id = "FireAtPoint",
            params = {
                point = { x = _args.point.x, y = _args.point.z },
                radius = 300,
                expendQty = 999,
                expendQtyEnabled = true,
            },
        }
        local _ok, _err = pcall(function() _attackController:pushTask(_fireTask) end)
        if _ok then
            env.info("CTLD - FireAtPoint назначена " .. _args.groupName)
            if _args.deployerGroupId and (_args.unitType == "CHAP_TOS1A" or _args.unitType == "Grad-URAL"
                or _args.unitType == "M-109") then
                trigger.action.outTextForGroup(_args.deployerGroupId,
                    ctld.coalitionText(_attackGroup:getCoalition(), "РЗО задачу выполнило. Возвращается на базу."), 12)
            end

            if _args.unitType == "MLRS" then
                timer.scheduleFunction(ctld.monitorM270Ammo, {
                    groupName = _args.groupName,
                    deployerGroupId = _args.deployerGroupId,
                }, timer.getTime() + ctld.m270AmmoCheckInterval)
            -- После выполнения огневой задачи убрать временно развёрнутую РЗО.
            elseif _args.unitType == "CHAP_TOS1A" or _args.unitType == "Grad-URAL"
                or _args.unitType == "M-109" then
                timer.scheduleFunction(function(_removeArgs)
                    local _removeGroup = Group.getByName(_removeArgs.groupName)
                    if _removeGroup and _removeGroup:isExist() then
                        ctld.suppressGeneratedCombatLoss(_removeArgs.groupName)
                        _removeGroup:destroy()
                    end
                    return nil
                end, { groupName = _args.groupName }, timer.getTime() + 120)
            end
        else
            env.info("CTLD - не удалось назначить FireAtPoint: " .. tostring(_err))
        end
        return nil
    end, {
        groupName = _group:getName(),
        point = { x = _targetPoint.x, y = _targetPoint.y, z = _targetPoint.z },
        deployerGroupId = _deployerGroupId,
        unitType = _unitType,
    }, timer.getTime() + 1)
end

-- M270 деактивируется только после полного расхода боекомплекта.
function ctld.monitorM270Ammo(_args)
    local _group = Group.getByName(_args.groupName)
    if not _group or not _group:isExist() then return nil end
    local _unit = _group:getUnit(1)
    if not _unit or not _unit:isExist() or _unit:getLife() <= 0 then return nil end

    local _ammoRemaining = 0
    for _, _ammo in ipairs(_unit:getAmmo() or {}) do
        _ammoRemaining = _ammoRemaining + (_ammo.count or 0)
    end
    if _ammoRemaining > 0 then
        return timer.getTime() + ctld.m270AmmoCheckInterval
    end

    local _controller = _group:getController()
    if _controller then pcall(function() _controller:setOnOff(false) end) end
    trigger.action.setGroupAIOff(_group)
    env.info("CTLD - M270 израсходовал БК и деактивирован: " .. _args.groupName)
    if _args.deployerGroupId then
        trigger.action.outTextForGroup(_args.deployerGroupId,
            ctld.coalitionText(_group:getCoalition(), "M270 израсходовал боекомплект. Деактивация."), 12)
    end
    timer.scheduleFunction(function(_groupName)
        local _removeGroup = Group.getByName(_groupName)
        if _removeGroup and _removeGroup:isExist() then
            ctld.suppressGeneratedCombatLoss(_groupName)
            _removeGroup:destroy()
        end
        return nil
    end, _args.groupName, timer.getTime() + ctld.m270PostAmmoDeleteDelay)
    return nil
end

local function ctldPointAtRangeFromTarget(_ownPoint, _targetPoint, _range)
    local _dx, _dz = _ownPoint.x - _targetPoint.x, _ownPoint.z - _targetPoint.z
    local _distance = math.sqrt(_dx * _dx + _dz * _dz)
    if _distance < 1 then _dx, _dz, _distance = _range, 0, _range end
    return {
        x = _targetPoint.x + _dx / _distance * _range,
        y = _targetPoint.y,
        z = _targetPoint.z + _dz / _distance * _range,
    }
end

local function ctldSetM270Route(_leader, _points, _speed)
    local _group = _leader and _leader:getGroup()
    if not _group or not _group:isExist() then return false end

    local _path = {}
    for _, _point in ipairs(_points) do
        table.insert(_path, mist.ground.buildWP(_point.point, _point.action, _speed))
    end
    local _controller = _group:getController()
    if _controller then pcall(function() _controller:setOnOff(true) end) end
    local _ok, _routed = pcall(mist.goRoute, _group, _path)
    return _ok and _routed
end

local function ctldNotifyHelicopterGroups(_coalition, _message, _sound)
    for _, _helicopterGroup in pairs(coalition.getGroups(_coalition, Group.Category.HELICOPTER) or {}) do
        if _helicopterGroup and _helicopterGroup:isExist() then
            local _groupId = _helicopterGroup:getID()
            trigger.action.outTextForGroup(_groupId, _message, 12)
            if _sound then trigger.action.outSoundForGroup(_groupId, _sound) end
        end
    end
end

-- Выбирает дорожную точку на рубеже огня, связанную дорогами с M270.
local function ctldFindM270RoadDestination(_start, _targetPoint, _range)
    local _startX, _startY = land.getClosestPointOnRoads("roads", _start.x, _start.z)
    if not _startX then return nil end
    local _dx, _dz = _start.x - _targetPoint.x, _start.z - _targetPoint.z
    local _distance = math.sqrt(_dx * _dx + _dz * _dz)
    if _distance < 1 then _dx, _dz, _distance = _range, 0, _range end
    local _baseX, _baseZ = _dx / _distance, _dz / _distance
    local _angles = { 0, 15, -15, 30, -30, 45, -45, 60, -60, 75, -75, 90, -90, 105, -105, 120, -120, 135, -135, 150, -150, 165, -165, 180 }
    for _, _angle in ipairs(_angles) do
        local _radians = math.rad(_angle)
        local _cos, _sin = math.cos(_radians), math.sin(_radians)
        local _candidateX = _targetPoint.x + (_baseX * _cos - _baseZ * _sin) * _range
        local _candidateZ = _targetPoint.z + (_baseX * _sin + _baseZ * _cos) * _range
        local _endX, _endY = land.getClosestPointOnRoads("roads", _candidateX, _candidateZ)
        if _endX then
            local _roadPath = land.findPathOnRoads("roads", _startX, _startY, _endX, _endY)
            if _roadPath and #_roadPath >= 2 then
                return { x = _endX, z = _endY }
            end
        end
    end
    return nil
end

-- Возвращает первого живого юнита группы.
-- Объявлена до алгоритма снабжения, чтобы была доступна его таймеру.
local function ctldAutoAliveLeader(_group)
    if not _group or not _group:isExist() then return nil end
    for _, _unit in ipairs(_group:getUnits() or {}) do
        if _unit and _unit:isExist() and _unit:getLife() > 0 then return _unit end
    end
    return nil
end

-- Одноразовая проверка дружественной наземной группы для машин снабжения.
local function ctldAutoFriendlyTarget(_group)
    local _leader = ctldAutoAliveLeader(_group)
    if not _leader then return nil end

    local _nearestUnit, _nearestDistance = nil, ctld.autoSupportSearchRange + 0.001
    local _origin = _leader:getPoint()
    for _, _friendlyGroup in pairs(coalition.getGroups(_group:getCoalition(), Group.Category.GROUND) or {}) do
        if _friendlyGroup:getName() ~= _group:getName() then
            for _, _friendlyUnit in pairs(_friendlyGroup:getUnits() or {}) do
                if _friendlyUnit and _friendlyUnit:isExist() and _friendlyUnit:getLife() > 0 then
                    local _distance = ctld.getDistance(_origin, _friendlyUnit:getPoint())
                    if _distance <= _nearestDistance then
                        _nearestUnit, _nearestDistance = _friendlyUnit, _distance
                    end
                end
            end
        end
    end
    return _nearestUnit, _nearestDistance
end

function ctld.updateSupportGroundGroup(_args)
    local _group = Group.getByName(_args.groupName)
    local _leader = ctldAutoAliveLeader(_group)
    if not _leader then return nil end

    local _friendlyUnit, _distance = ctldAutoFriendlyTarget(_group)
    if _friendlyUnit then
        if _distance > ctld.autoSupportStandOffRange then
            ctld.orderGroupToMoveToPoint(_leader,
                ctldPointAtRangeFromTarget(_leader:getPoint(), _friendlyUnit:getPoint(), ctld.autoSupportStandOffRange))
        else
            ctldSetGroundCombatReady(_group)
        end
        if _args.deployerGroupId then
            trigger.action.outTextForGroup(_args.deployerGroupId,
                ctld.coalitionText(_group:getCoalition(), "Техника снабжения движется к союзнику."), 12)
            trigger.action.outSoundForGroup(_args.deployerGroupId, "switch.wav")
        end
    else
        ctldSetGroundCombatReady(_group)
        if _args.deployerGroupId then
            trigger.action.outTextForGroup(_args.deployerGroupId,
                ctld.coalitionText(_group:getCoalition(), "Техника снабжения остаётся на позиции, работаю штатно."), 12)
            trigger.action.outSoundForGroup(_args.deployerGroupId, "switch.wav")
        end
    end
    return nil
end

local function ctldAutoTarget(_group, _role, _searchRange, _minimumRange)
    local _leader = ctldAutoAliveLeader(_group)
    if not _leader then return nil end
    local _enemySide = _group:getCoalition() == coalition.side.RED and coalition.side.BLUE or coalition.side.RED
    local _nearest, _nearestUnit, _nearestDistance = nil, nil, _searchRange or ctld.autoGroundSearchRange
    _minimumRange = _minimumRange or 0
    local _origin = _leader:getPoint()

    for _, _enemyGroup in pairs(coalition.getGroups(_enemySide, Group.Category.GROUND) or {}) do
        local _enemyLeader = ctldAutoAliveLeader(_enemyGroup)
        if _enemyLeader then
            local _enemyPoint = _enemyLeader:getPoint()
            local _distance = ctld.getDistance(_origin, _enemyPoint)
            local _visible = true
            if _role == "recon" or _role == "artillery" then
                local _ok, _result = pcall(land.isVisible, _origin, _enemyPoint)
                _visible = _ok and _result
            end
            if _visible and _distance >= _minimumRange and _distance < _nearestDistance then
                _nearest, _nearestUnit, _nearestDistance = _enemyGroup, _enemyLeader, _distance
            end
        end
    end
    return _nearest, _nearestUnit
end

-- Однократно запоминает исходную позицию цели для техники, чтобы после её
-- уничтожения ИИ всё равно мог занять точку в 50 м от последней позиции.
function ctld.captureInitialGroundTarget(_args)
    local _group = Group.getByName(_args.groupName)
    local _, _targetUnit = ctldAutoTarget(_group, "attack")
    if _targetUnit then
        local _point = _targetUnit:getPoint()
        _args.initialTargetPoint = { x = _point.x, y = _point.y, z = _point.z }
    elseif (_args.initialCaptureAttempts or 0) < 2 then
        _args.initialCaptureAttempts = (_args.initialCaptureAttempts or 0) + 1
        return timer.getTime() + 1
    end
    return nil
end

-- Артиллерия движется к цели, пока не увидит её визуально. При визуальном
-- контакте маршрут сбрасывается, и ИИ начинает штатную атаку по противнику.
function ctld.updateArtilleryGroundGroup(_args)
    local _group = Group.getByName(_args.groupName)
    local _leader = ctldAutoAliveLeader(_group)
    if not _leader then
        if _args.stationary and not _args.failureNotified then
            _args.failureNotified = true
            ctld.notifyInfantryTaskFailed(_args.coalition, "Минометная батарея")
        end
        return nil
    end

    local _profile = ctld.autoArtilleryProfiles[_args.unitType] or {}
    local _fireRange = _profile.fireRange or ctld.autoArtilleryMinimumRange
    local _minimumFireRange = _profile.minimumFireRange or 0
    local _searchRange = _profile.searchRange or _args.searchRange or ctld.autoArtillerySearchRange

    local _targetGroup = _args.targetGroupName and Group.getByName(_args.targetGroupName) or nil
    local _targetUnit = ctldAutoAliveLeader(_targetGroup)
    if not _targetUnit then
        local _targetRole = _profile.requiresVisual == false and "attack" or "artillery"
        _targetGroup, _targetUnit = ctldAutoTarget(_group, _targetRole, _searchRange)
        _args.targetGroupName = _targetGroup and _targetGroup:getName() or nil
    end

    if not _targetUnit then
        ctldSetGroundCombatReady(_group)
        if _args.deployerGroupId then
            trigger.action.outTextForGroup(_args.deployerGroupId,
                ctld.coalitionText(_group:getCoalition(), "Противник не обнаружен, остаюсь на позиции."), 12)
            trigger.action.outSoundForGroup(_args.deployerGroupId, "switch.wav")
        end
        return nil
    end

    local _ownPoint, _targetPoint = _leader:getPoint(), _targetUnit:getPoint()
    local _distance = ctld.getDistance(_ownPoint, _targetPoint)

    -- M270 работает своим штатным алгоритмом: короткими ППМ отходит
    -- на огневой рубеж, а FireAtPoint получает только после прибытия.
    if _args.unitType == "MLRS" then
        local _arrivedAtRoadEnd = _args.mlrsRoadRouteIssued and _args.mlrsRoadEnd
            and ctld.getDistance(_ownPoint, _args.mlrsRoadEnd) < 100
        if _arrivedAtRoadEnd and _distance < 10100 then
            ctldNotifyHelicopterGroups(_group:getCoalition(),
                ctld.coalitionText(_group:getCoalition(), "M270 Нет условий пуска — задача сорвана."), "switch.wav")
            env.info("CTLD - M270: задача сорвана, дальность " .. math.floor(_distance) .. " м")
            timer.scheduleFunction(function(_groupName)
                local _removeGroup = Group.getByName(_groupName)
                if _removeGroup and _removeGroup:isExist() then
                    ctld.suppressGeneratedCombatLoss(_groupName)
                    _removeGroup:destroy()
                end
                return nil
            end, _group:getName(), timer.getTime() + 30)
            return nil
        end
        if _distance >= _minimumFireRange and _distance <= _fireRange then
            ctldSetGroundAttackTarget(_group, _targetUnit, _args.deployerGroupId, _args.unitType)
            return nil
        end
        local _desiredRange = _distance < _minimumFireRange and _minimumFireRange or _fireRange
        if not _args.mlrsRoadEnd then
            _args.mlrsRoadEnd = ctldFindM270RoadDestination(_ownPoint, _targetPoint, _desiredRange)
            if not _args.mlrsRoadEnd then
                env.info("CTLD - M270: не удалось построить дорожный маршрут")
                return nil
            end
        end

        local _now = timer.getTime()
        if not _args.mlrsRoadJoined then
            if not _args.mlrsRoadEntry then
                local _roadX, _roadY = land.getClosestPointOnRoads("roads", _ownPoint.x, _ownPoint.z)
                if not _roadX then return nil end
                _args.mlrsRoadEntry = { x = _roadX, z = _roadY }
            end
            if ctld.getDistance(_ownPoint, _args.mlrsRoadEntry) < 10 then
                _args.mlrsRoadJoined = true
                _args.mlrsRoadStep = nil
                _args.mlrsStepDeadline = nil
            elseif not _args.mlrsStepDeadline or _now >= _args.mlrsStepDeadline then
                ctldSetM270Route(_leader, {
                    { point = _ownPoint, action = "Off Road" },
                    { point = _args.mlrsRoadEntry, action = "Off Road" },
                }, _profile.moveSpeed)
                _args.mlrsStepDeadline = _now + (ctld.getDistance(_ownPoint, _args.mlrsRoadEntry) / _profile.moveSpeed) + 15
            end
            return timer.getTime() + ctld.autoArtilleryCheckInterval
        end

        if not _args.mlrsRoadRouteIssued then
            local _currentRoadX, _currentRoadY = land.getClosestPointOnRoads("roads", _ownPoint.x, _ownPoint.z)
            if not _currentRoadX then return nil end
            ctldSetM270Route(_leader, {
                { point = { x = _currentRoadX, z = _currentRoadY }, action = "On Road" },
                { point = _args.mlrsRoadEnd, action = "On Road" },
            }, _profile.moveSpeed)
            _args.mlrsRoadRouteIssued = true
        end
        return timer.getTime() + ctld.autoArtilleryCheckInterval
    end

    -- Солнцепёк и Град идут к цели без проверки видимости и на рубеже 3000 м
    -- накрывают район её текущего расположения. У M270 есть собственная
    -- минимальная дальность, поэтому запуск разрешён только внутри её зоны огня.
    if _distance >= _minimumFireRange and _distance <= _fireRange then
        ctldSetGroundAttackTarget(_group, _targetUnit, _args.deployerGroupId, _args.unitType)
        return nil
    end

    -- Миномётная батарея работает с точки развёртывания и не выдвигается к цели.
    if _args.stationary then
        ctldSetGroundCombatReady(_group)
        return nil
    end

    if _distance < _minimumFireRange then
        local _destination = ctldPointAtRangeFromTarget(_ownPoint, _targetPoint, _minimumFireRange)
        ctld.orderGroupToMoveToPoint(_leader, _destination, _profile.moveSpeed)
        return timer.getTime() + ctld.autoArtilleryCheckInterval
    end

    if _distance > _fireRange then
        local _destination = ctldPointAtRangeFromTarget(_ownPoint, _targetPoint, _fireRange)
        ctld.orderGroupToMoveToPoint(_leader, _destination, _profile.moveSpeed)
        return timer.getTime() + ctld.autoArtilleryCheckInterval
    end
end

local function ctldSpawnInfantryDefenseBunker(_args, _point)
    local _unitId = ctld.getNextUnitId()
    local _groupId = ctld.getNextGroupId()
    local _group = {
        visible = false,
        hidden = false,
        name = "Огневая позиция #" .. _groupId,
        task = {},
        units = {
            ctld.createUnit(_point.x, _point.z, 0, {
                type = "Bunker",
                unitId = _unitId,
                name = "Bunker #" .. _unitId,
            }),
        },
        category = Group.Category.GROUND,
        country = _args.country,
    }
    local _spawned = Group.getByName(mist.dynAdd(_group).name)
    if not _spawned then return nil end
    ctld.registerGeneratedCombatGroup(_spawned, "bunker")
    ctldSetGroundCombatReady(_spawned)
    return _spawned
end

function ctld.updateInfantryAssaultGroup(_args)
    local _group = Group.getByName(_args.groupName)
    if not _group or not _group:isExist() then
        if not _args.completed then
            ctld.notifyInfantryTaskFailed(_args.coalition, _args.taskName)
        end
        return nil
    end

    local _leader = ctldAutoAliveLeader(_group)
    if not _leader then
        if not _args.completed then
            ctld.notifyInfantryTaskFailed(_group:getCoalition(), _args.taskName)
        end
        return nil
    end

    -- Штурмовая и противотанковая группы получают только одну задачу.
    -- Координаты первой обнаруженной цели и конечная ППМ больше не меняются,
    -- даже если цель уничтожена в пути.
    if not _args.assaultDestination then
        local _targetGroup, _targetUnit = ctldAutoTarget(_group, "attack", ctld.infantryAssaultSearchRange)
        if not _targetUnit then
            return timer.getTime() + ctld.autoReconCheckInterval
        end
        local _ownPoint, _targetPoint = _leader:getPoint(), _targetUnit:getPoint()
        _args.assaultTargetPoint = { x = _targetPoint.x, y = _targetPoint.y, z = _targetPoint.z }
        _args.assaultDestination = ctldPointAtRangeFromTarget(
            _ownPoint, _args.assaultTargetPoint, ctld.infantryAssaultStandOffRange)
    end

    local _destination = _args.assaultDestination
    local _arrived = false
    for _, _unit in ipairs(_group:getUnits() or {}) do
        if _unit and _unit:isExist() and _unit:getLife() > 0
                and ctld.getDistance(_unit:getPoint(), _destination) <= 75 then
            _arrived = true
            break
        end
    end
    if _arrived then
        _args.completed = true
        local _coalition = _group:getCoalition()
        local _country = _args.country or _leader:getCountry()
        local _position = { x = _destination.x, y = _destination.y, z = _destination.z }
        pcall(function() _group:getController():setOnOff(false) end)
        ctld.suppressGeneratedCombatLoss(_group:getName())
        _group:destroy()
        local _bunker = ctldSpawnInfantryDefenseBunker({ country = _country }, _position)
        if _bunker then
            ctld.notifySwitchCoalition(_coalition,
                ctld.coalitionText(_coalition, "Пехота заняла оборону. Огневая позиция развёрнута."), 12)
        else
            ctld.notifyInfantryTaskFailed(_coalition, _args.taskName)
        end
        return nil
    end

    if not _args.moving then
        ctld.orderGroupToMoveToPoint(_leader, _destination, ctld.infantryMarchSpeed)
        _args.moving = true
    end
    return timer.getTime() + ctld.autoReconCheckInterval
end

function ctld.acquireAutoGroundTarget(_args)
    local _group = Group.getByName(_args.groupName)
    local _leader = ctldAutoAliveLeader(_group)
    if not _leader then return nil end
    local _, _targetUnit = ctldAutoTarget(_group, _args.role)
    local _targetPoint = _targetUnit and _targetUnit:getPoint() or _args.initialTargetPoint
    if _targetPoint then
        local _ownPoint = _leader:getPoint()
        local _distance = ctld.getDistance(_ownPoint, _targetPoint)
        local _profile = _args.profile
        if _profile and _profile.engagementRange then
            if _distance > _profile.engagementRange then
                ctld.orderGroupToMoveToPoint(_leader,
                    ctldPointAtRangeFromTarget(_ownPoint, _targetPoint, _profile.moveRange or _profile.engagementRange))
            else
                ctldSetGroundCombatReady(_group)
            end
        else
            ctld.orderGroupToMoveToPoint(_leader, ctldPointAtRangeFromTarget(_ownPoint, _targetPoint, 50))
        end
        if _args.deployerGroupId then
            trigger.action.outTextForGroup(_args.deployerGroupId, ctld.coalitionText(_group:getCoalition(), "Начинаю поиск противника."), 12)
            trigger.action.outSoundForGroup(_args.deployerGroupId, "switch.wav")
        end
    else
        ctldSetGroundCombatReady(_group)
        if _args.deployerGroupId then
            trigger.action.outTextForGroup(_args.deployerGroupId,
                ctld.coalitionText(_group:getCoalition(), "Противник не обнаружен, остаюсь на позиции."), 12)
            trigger.action.outSoundForGroup(_args.deployerGroupId, "switch.wav")
        end
    end
    return nil
end

-- Для ПАН/JTAC и "Тайфуна": одна цель отслеживается до её уничтожения.
-- Новый поиск по карте происходит только после уничтожения текущей цели.
function ctld.updateReconGroundGroup(_args)
    local _group = Group.getByName(_args.groupName)
    local _leader = ctldAutoAliveLeader(_group)
    if not _leader then return nil end

    -- Пеший ПАН сначала получает координаты цели, затем сближается до
    -- визуального контакта. Подсветка и передача координат остаются за
    -- штатным JTACAutoLase.
    if _args.jtacInfantry then
        local _lasedTarget = ctld.jtacCurrentTargets[_args.groupName]
        if _lasedTarget then
            local _lasedUnit = Unit.getByName(_lasedTarget.name)
            if _lasedUnit and _lasedUnit:isExist() and _lasedUnit:isActive() and _lasedUnit:getLife() > 0 then
                trigger.action.groupStopMoving(_group)
                return timer.getTime() + ctld.autoReconCheckInterval
            end
        end

        local _targetGroup = _args.targetGroupName and Group.getByName(_args.targetGroupName) or nil
        local _targetUnit = ctldAutoAliveLeader(_targetGroup)
        if not _targetUnit then
            _targetGroup, _targetUnit = ctldAutoTarget(_group, "attack", _args.searchRange)
            _args.targetGroupName = _targetGroup and _targetGroup:getName() or nil
            _args.targetPoint, _args.moveDestination = nil, nil
        end
        if not _targetUnit then
            ctldSetGroundCombatReady(_group)
            return timer.getTime() + ctld.autoReconCheckInterval
        end

        local _ownPoint, _targetPoint = _leader:getPoint(), _targetUnit:getPoint()
        local _visible = false
        local _ok, _result = pcall(land.isVisible,
            { x = _ownPoint.x, y = _ownPoint.y + 2, z = _ownPoint.z },
            { x = _targetPoint.x, y = _targetPoint.y + 2, z = _targetPoint.z })
        _visible = _ok and _result
        if _visible then
            trigger.action.groupStopMoving(_group)
            return timer.getTime() + ctld.autoReconCheckInterval
        end

        local _distance = ctld.getDistance(_ownPoint, _targetPoint)
        local _desiredRange = _distance > ctld.jtacReconStandOffRange
            and ctld.jtacReconStandOffRange or math.max(50, _distance - 500)
        local _destination = ctldPointAtRangeFromTarget(_ownPoint, _targetPoint, _desiredRange)
        local _needsRoute = not _args.moveDestination
            or ctld.getDistance(_args.moveDestination, _destination) > 100
            or ctld.getDistance(_ownPoint, _args.moveDestination) < 75
        if _needsRoute then
            ctld.orderGroupToMoveToPoint(_leader, _destination, ctld.infantryMarchSpeed)
            _args.moveDestination = _destination
        end
        return timer.getTime() + ctld.autoReconCheckInterval
    end

    -- Пока штатный JTAC подсвечивает активную цель, ПАН остаётся на месте.
    -- Без этой проверки общий алгоритм разведки мог повторно выдать маршрут.
    local _lasedTarget = ctld.jtacCurrentTargets[_args.groupName]
    if _lasedTarget then
        local _lasedUnit = Unit.getByName(_lasedTarget.name)
        if _lasedUnit and _lasedUnit:isExist() and _lasedUnit:isActive() and _lasedUnit:getLife() > 0 then
            -- JTAC уже выдаёт координаты/подсветку: останавливаем именно
            -- маршрут группы. Простого setOnOff(true) недостаточно — он
            -- оставляет ранее выданную ППМ активной, и машина едет дальше.
            pcall(function() trigger.action.groupStopMoving(_group) end)
            return timer.getTime() + ctld.autoReconCheckInterval
        end
    end

    local _targetGroup = _args.targetGroupName and Group.getByName(_args.targetGroupName) or nil
    local _targetUnit = ctldAutoAliveLeader(_targetGroup)
    if not _targetUnit then
        _targetGroup, _targetUnit = ctldAutoTarget(_group, "attack")
        _args.targetGroupName = _targetGroup and _targetGroup:getName() or nil
        _args.reported, _args.moving, _args.targetPoint = false, false, nil
        if not _targetUnit then
            ctldSetGroundCombatReady(_group)
            if _args.deployerGroupId then
                local _message = ctld.coalitionText(_group:getCoalition(), "Противник не обнаружен, остаюсь на позиции.")
                if _args.unitType == "CHAP_Titan" then
                    _message = ctld.coalitionText(_group:getCoalition(), "Титан: остаюсь на позиции, ПАН в штатной работе.")
                elseif _args.unitType == "ПАН разведчик" then
                    _message = ctld.coalitionText(_group:getCoalition(), "Наводчик: остаюсь на позиции, работаю штатно.")
                end
                trigger.action.outTextForGroup(_args.deployerGroupId, _message, 10)
                trigger.action.outSoundForGroup(_args.deployerGroupId, "switch.wav")
            end
            return nil
        end
    end

    local _ownPoint, _targetPoint = _leader:getPoint(), _targetUnit:getPoint()
    local _visible = false
    local _ok, _result = pcall(land.isVisible, _ownPoint, _targetPoint)
    _visible = _ok and _result

    if _visible then
        if not _args.reported then
            local _controller = _group:getController()
            if _controller then pcall(function() _controller:setOnOff(true) end) end
            ctld.notifyCoalition("ПАН: цель обнаружена." .. ctld.getPositionString(_targetUnit),
                15, _group:getCoalition())
            _args.reported, _args.moving = true, false
        end
    else
        local _targetMoved = not _args.targetPoint or ctld.getDistance(_args.targetPoint, _targetPoint) > 150
        if not _args.moving or _targetMoved then
            local _dx, _dz = _ownPoint.x - _targetPoint.x, _ownPoint.z - _targetPoint.z
            local _distance = math.sqrt(_dx * _dx + _dz * _dz)
            if _distance < 1 then _dx, _dz, _distance = 50, 0, 50 end
            ctld.orderGroupToMoveToPoint(_leader, {
                x = _targetPoint.x + _dx / _distance * 50,
                y = _targetPoint.y,
                z = _targetPoint.z + _dz / _distance * 50,
            })
            _args.moving, _args.targetPoint = true, _targetPoint
        end
    end
    return timer.getTime() + ctld.autoReconCheckInterval
end

function ctld.findNearestGroup(_heli, _groups)

    local _closestGroupDetails = {}
    local _closestGroup = nil

    local _closestGroupDist = ctld.maxExtractDistance

    local _heliPoint = _heli:getPoint()

    for _, _groupName in pairs(_groups) do

        local _group = Group.getByName(_groupName)

        if _group ~= nil then
            local _units = _group:getUnits()

            if _units ~= nil and #_units > 0 then

                local _leader = nil

                local _groupDetails = { groupId = _group:getID(), groupName = _group:getName(), side = _group:getCoalition(), units = {} }

                -- найти живого ведущего юнита.
                for x = 1, #_units do
                    if _units[x]:getLife() > 0 then

                        if _leader == nil then
                            _leader = _units[x]
                            -- установить страну по ведущему юниту.
                            _groupDetails.country = _leader:getCountry()
                        end

                        local _unitDetails = { type = _units[x]:getTypeName(), unitId = _units[x]:getID(), name = _units[x]:getName() }

                        table.insert(_groupDetails.units, _unitDetails)
                    end
                end

                if _leader ~= nil then
                    local _leaderPos = _leader:getPoint()
                    local _dist = ctld.getDistance(_heliPoint, _leaderPos)
                    if _dist < _closestGroupDist then
                        _closestGroupDist = _dist
                        _closestGroupDetails = _groupDetails
                        _closestGroup = _group
                    end
                end
            end
        end
    end


    if _closestGroup ~= nil then

        return { group = _closestGroup, details = _closestGroupDetails }
    else

        return nil
    end
end


function ctld.createUnit(_x, _y, _angle, _details)

    local _newUnit = {
        ["y"] = _y,
        ["type"] = _details.type,
        ["name"] = _details.name,
      --  ["unitId"] = _details.unitId,
        ["heading"] = _angle,
        ["playerCanDrive"] = true,
        ["skill"] = "Excellent",
        ["x"] = _x,
    }

    return _newUnit
end

function ctld.orderGroupToMoveToPoint(_leader, _destination, _speed)

    local _group = _leader:getGroup()
    _speed = _speed or 20
    local _isInfantry = ctld.isInfantry(_leader)
    if _isInfantry then
        _speed = ctld.infantryMarchSpeed
    end

    local _path = {}
    local _startWP = mist.ground.buildWP(_leader:getPoint(), 'Off Road', _speed)
    local _destinationWP = mist.ground.buildWP(_destination, 'Off Road', _speed)
    if _isInfantry then
        -- Без фиксации DCS пересчитывает скорость по ETA и снижает её до
        -- штатной скорости строя. Для пехоты нужен беговой темп 14 км/ч.
        _startWP.speed_locked = true
        _destinationWP.speed_locked = true
        _startWP.ETA_locked = false
        _destinationWP.ETA_locked = false
    end
    table.insert(_path, _startWP)
    table.insert(_path, _destinationWP)

    local _mission = {
        id = 'Mission',
        params = {
            route = {
                points =_path
            },
        },
    }


    -- задержка 2 секунды для обхода ошибки.
    timer.scheduleFunction(function(_arg)
        local _grp = ctld.getAliveGroup(_arg[1])

        if _grp ~= nil then
            local _controller = _grp:getController();
            pcall(function() _controller:setOnOff(true) end)
            pcall(function()
                Controller.setOption(_controller, AI.Option.Ground.id.ALARM_STATE, AI.Option.Ground.val.ALARM_STATE.AUTO)
            end)
            pcall(function()
                Controller.setOption(_controller, AI.Option.Ground.id.ROE, AI.Option.Ground.val.ROE.OPEN_FIRE)
            end)
            pcall(function() _controller:setTask(_arg[2]) end)
        end
    end
        , {_group:getName(), _mission}, timer.getTime() + 2)

end

-- Находимся ли мы в зоне погрузки.
function ctld.inPickupZone(_heli)
    ctld.logDebug(string.format("ctld.inPickupZone(_heli=%s)", ctld.p(_heli)))

    if ctld.inAir(_heli) then
        return { inZone = false, limit = -1, index = -1 }
    end

    local _heliPoint = _heli:getPoint()

    for _i, _zoneDetails in pairs(ctld.pickupZones) do
        ctld.logTrace(string.format("_zoneDetails=%s", ctld.p(_zoneDetails)))

        local _triggerZone = trigger.misc.getZone(_zoneDetails[1])

        if _triggerZone == nil then
            local _ship = ctld.getTransportUnit(_zoneDetails[1])

            if _ship then
                local _point = _ship:getPoint()
                _triggerZone = {}
                _triggerZone.point = _point
                _triggerZone.radius = 200 -- should be big enough for ship
            end

        end

        if _triggerZone ~= nil then

            -- получить дистанцию до центра.

            local _dist = ctld.getDistance(_heliPoint, _triggerZone.point)
            ctld.logTrace(string.format("_dist=%s", ctld.p(_dist)))
            if _dist <= _triggerZone.radius then
                local _heliCoalition = _heli:getCoalition()
                if _zoneDetails[4] == 1 and (_zoneDetails[5] == _heliCoalition or _zoneDetails[5] == 0) then
                    return { inZone = true, limit = _zoneDetails[3], index = _i }
                end
            end
        end
    end

    -- Парная логистическая точка является резервной областью погрузки.
    -- logisticBLUE1 соответствует pickzoneBLUE1, logisticRED1 -- pickzoneRED1.
    local _sidePrefix = _heli:getCoalition() == coalition.side.BLUE and "BLUE" or "RED"
    for _i, _zoneDetails in pairs(ctld.pickupZones) do
        local _expectedZone = "pickzone" .. _sidePrefix
        if string.sub(_zoneDetails[1], 1, string.len(_expectedZone)) == _expectedZone
            and _zoneDetails[4] == 1 and _zoneDetails[5] == _heli:getCoalition() then
            local _suffix = string.sub(_zoneDetails[1], string.len(_expectedZone) + 1)
            local _logistic = StaticObject.getByName("logistic" .. _sidePrefix .. _suffix)
            if _logistic and _logistic:getCoalition() == _heli:getCoalition()
                and ctld.getDistance(_heliPoint, _logistic:getPoint()) <= ctld.maximumDistanceLogistic then
                return { inZone = true, limit = _zoneDetails[3], index = _i }
            end
        end
    end

    return { inZone = false, limit = -1, index = -1 };
end

-- Находимся ли мы рядом с дружественной зоной логистики.
function ctld.inLogisticsZone(_heli)

    if ctld.inAir(_heli) then
        return false
    end

    local _heliPoint = _heli:getPoint()

    for _, _name in pairs(ctld.logisticUnits) do

        local _logistic = StaticObject.getByName(_name)

        if _logistic ~= nil and _logistic:getCoalition() == _heli:getCoalition() then

            -- получить дистанцию.
            local _dist = ctld.getDistance(_heliPoint, _logistic:getPoint())

            if _dist <= ctld.maximumDistanceLogistic then
                return true
            end
        end
    end

    return false
end


-- Находимся ли мы достаточно далеко от дружественной зоны логистики.
function ctld.farEnoughFromLogisticZone(_heli)

    if ctld.inAir(_heli) then
        return false
    end

    local _heliPoint = _heli:getPoint()

    local _farEnough = true

    for _, _name in pairs(ctld.logisticUnits) do

        local _logistic = StaticObject.getByName(_name)

        if _logistic ~= nil and _logistic:getCoalition() == _heli:getCoalition() then

            -- получить дистанцию.
            local _dist = ctld.getDistance(_heliPoint, _logistic:getPoint())
            -- env.info("DIST ".._dist)
            if _dist <= ctld.minimumDeployDistance then
                -- env.info("TOO CLOSE ".._dist)
                _farEnough = false
            end
        end
    end

    return _farEnough
end

function ctld.refreshSmoke()

    if ctld.disableAllSmoke == true then
        return
    end

    for _, _zoneGroup in pairs({ ctld.pickupZones }) do

        for _, _zoneDetails in pairs(_zoneGroup) do

            local _triggerZone = trigger.misc.getZone(_zoneDetails[1])

            if _triggerZone == nil then
                local _ship = ctld.getTransportUnit(_triggerZone)

                if _ship then
                    local _point = _ship:getPoint()
                    _triggerZone = {}
                    _triggerZone.point = _point
                end

            end


            -- срабатывать, только если дым включён И зона активна.
            if _triggerZone ~= nil and _zoneDetails[2] >= 0 and _zoneDetails[4] == 1 then

                -- включить дымовые маркеры.

                local _pos2 = { x = _triggerZone.point.x, y = _triggerZone.point.z }
                local _alt = land.getHeight(_pos2)
                local _pos3 = { x = _pos2.x, y = _alt, z = _pos2.y }

                trigger.action.smoke(_pos3, _zoneDetails[2])
            end
        end
    end

    -- обновить через 5 минут.
    timer.scheduleFunction(ctld.refreshSmoke, nil, timer.getTime() + 300)
end

function ctld.isJTACUnitType(_type)

    _type = string.lower(_type)

    for _, _name in ipairs(ctld.jtacUnitTypes) do
        local _nameLower = string.lower(_name)
        if string.match(_type, _nameLower) then
            return true
        end
    end

    return false
end

function ctld.getJTACCommittedCount(_side)
    local _count = 0
    for _groupName, _details in pairs(ctld.jtacUnits or {}) do
        if _details.side == _side then
            local _unit = Unit.getByName(_details.name)
            if _unit and _unit:isExist() and _unit:isActive() and _unit:getLife() > 0 then
                _count = _count + 1
            end
        end
    end
    local _crates = _side == coalition.side.RED and ctld.spawnedCratesRED or ctld.spawnedCratesBLUE
    for _, _details in pairs(_crates or {}) do
        if _details.unit and ctld.isJTACUnitType(_details.unit) then _count = _count + 1 end
    end
    for _, _cargo in pairs(ctld.inTransitSlingLoadCrates or {}) do
        if _cargo and _cargo.side == _side and _cargo.unit and ctld.isJTACUnitType(_cargo.unit) then
            _count = _count + 1
        end
    end
    for _, _transit in pairs(ctld.inTransitTroops or {}) do
        if _transit and _transit.troops and _transit.troops.side == _side and _transit.troops.jtac then
            _count = _count + 1
        end
    end
    return _count
end

function ctld.canRequestJTAC(_side)
    return ctld.getJTACCommittedCount(_side) < ctld.JTAC_MAX_ACTIVE_PER_COALITION
end

function ctld.notifyJTACLimitToGroup(_heli)
    local _side = _heli:getCoalition()
    local _message = _side == coalition.side.BLUE
        and ctld.coalitionText(_side, "В операции задействовано максимальное количество JTAC!")
        or ctld.coalitionText(_side, "В операции задействовано максимальное количество ПАН!")
    ctld.displayMessageToGroup(_heli, _message, 12, false, true)
    local _groupId = ctld.getGroupId(_heli)
    if _groupId then trigger.action.outSoundForGroup(_groupId, "no_conditions.ogg") end
end

function ctld.getJTACLaserCode(_side)
    local _codes = _side == coalition.side.RED
        and { 1511, 1522, 1533, 1544, 1555, 1566 }
        or { 1611, 1622, 1633, 1644, 1655, 1666 }
    local _used = {}
    for _groupName, _details in pairs(ctld.jtacUnits or {}) do
        if _details.side == _side and ctld.jtacLaserPointCodes[_groupName] then
            _used[ctld.jtacLaserPointCodes[_groupName]] = true
        end
    end
    local _available = {}
    for _, _code in ipairs(_codes) do
        if not _used[_code] then table.insert(_available, _code) end
    end
    if #_available == 0 then return nil end
    return _available[math.random(#_available)]
end

function ctld.updateZoneCounter(_index, _diff)

    if ctld.pickupZones[_index] ~= nil then

        ctld.pickupZones[_index][3] = ctld.pickupZones[_index][3] + _diff

        if ctld.pickupZones[_index][3] < 0 then
            ctld.pickupZones[_index][3] = 0
        end

        if ctld.pickupZones[_index][6] ~= nil then
            trigger.action.setUserFlag(ctld.pickupZones[_index][6], ctld.pickupZones[_index][3])
        end
        --  env.info(ctld.pickupZones[_index][1].." = " ..ctld.pickupZones[_index][3])
    end
end

function ctld.processCallback(_callbackArgs)

    for _, _callback in pairs(ctld.callbacks) do

        local _status, _result = pcall(function()

            _callback(_callbackArgs)

        end)

        if (not _status) then
            env.error(string.format("CTLD Callback Error: %s", _result))
        end
    end
end


function ctld.getTransportLimit(_unitType)

    if ctld.unitLoadLimits[_unitType] then

        return ctld.unitLoadLimits[_unitType]
    end

    return ctld.numberOfTroops

end

function ctld.getUnitActions(_unitType)

    if ctld.unitActions[_unitType] then
        return ctld.unitActions[_unitType]
    end

    return {crates=true,troops=true}

end

-- Добавляет пункт меню всем активным вертолётным юнитам.
function ctld.addF10MenuOptions()
    -- пройти по всем вертолётным юнитам.

    timer.scheduleFunction(ctld.addF10MenuOptions, nil, timer.getTime() + 10)
    ctld.refreshPlayerTransportNames()
    ctld.cleanupRuntimeState()

    for _, _unitName in pairs(ctld.transportPilotNames) do

        local status, error = pcall(function()

            local _unit = ctld.getTransportUnit(_unitName)

            if _unit ~= nil then
                -- Проверка ID лёгкая; масса DCS меняется только для нового объекта.
                ctld.syncTransportCargo(_unit)

                local _groupId = ctld.getGroupId(_unit)

                -- Корневое CTLD-меню CSS-NATO/MTO-RF создаётся только обычным
                -- вертолётам. Самолёты, Ка-50 и Ка-50 III получают лишь JTAC.
                if _groupId and ctld.isHelicopterUnit(_unit)
                        and not ctld.jtacOnlyAircraftTypes[_unit:getTypeName()] then

                    if ctld.addedTo[tostring(_groupId)] ~= _unitName then
                        local _rootMenuName = _unit:getCoalition() == coalition.side.BLUE and "CSS-NATO" or "MTO-RF"
                        -- F10 пересоздаётся при смене слота/группы. Удаляем оставшиеся
                        -- пустые корни до добавления нового, чтобы меню обеих коалиций не дублировалось.
                        missionCommands.removeItemForGroup(_groupId, { "CTLD-NATO" })
                        missionCommands.removeItemForGroup(_groupId, { "CTLD-RF" })
                        missionCommands.removeItemForGroup(_groupId, { "CSS-NATO" })
                        missionCommands.removeItemForGroup(_groupId, { "MTO-RF" })
                        missionCommands.removeItemForGroup(_groupId, { "МТО - CTLD" })
                        ctld.f10MenuRoots[tostring(_groupId)] = _rootMenuName
                        local _rootPath = missionCommands.addSubMenuForGroup(_groupId, _rootMenuName)

                        local _unitActions = ctld.getUnitActions(_unit:getTypeName())
                        ctld.logTrace(string.format("_unitActions=%s", ctld.p(_unitActions)))

                        missionCommands.addCommandForGroup(_groupId, "Проверить наличие грузов на борту", _rootPath, ctld.checkTroopStatus, { _unitName })

                        if _unitActions.troops then

                            local _troopCommandsPath = missionCommands.addSubMenuForGroup(_groupId, "Пехота", _rootPath)

                            missionCommands.addCommandForGroup(_groupId, "Выгрузить Десант", _troopCommandsPath, ctld.unloadExtractTroops, { _unitName })


                            -- local _loadPath = missionCommands.addSubMenuForGroup(_groupId, "Загрузить из зоны", _troopCommandsPath)
                            local _transportLimit = ctld.getTransportLimit(_unit:getTypeName())
                            ctld.logTrace(string.format("_transportLimit=%s", ctld.p(_transportLimit)))
                            for _,_loadGroup in pairs(ctld.loadableGroups) do
                                ctld.logTrace(string.format("_loadGroup=%s", ctld.p(_loadGroup)))
                                if not _loadGroup.side or _loadGroup.side == _unit:getCoalition() then

                                    -- проверить размер группы и тип юнита.
                                    if _transportLimit >= _loadGroup.total then
                                        local _loadMenuName = _loadGroup.name
                                        if _unit:getCoalition() == coalition.side.BLUE and _loadGroup.name == "ПАН разведчик" then
                                            _loadMenuName = "Разведчик JTAC"
                                        end
                                        missionCommands.addCommandForGroup(_groupId, "Взять:".._loadMenuName, _troopCommandsPath, ctld.loadTroopsFromZone, { _unitName, true,_loadGroup,false })
                                    end
                                end
                            end

                        end


                        if ctld.enableCrates and _unitActions.crates then

                            -- Порядок F10 фиксирован. Синие и красные не видят ящики другой коалиции.
                            local _crateMenuOrder = _unit:getCoalition() == coalition.side.BLUE
                                and ctld.crateMenuOrderBLUE or ctld.crateMenuOrderRED
                            for _, _subMenuName in ipairs(_crateMenuOrder) do
                                local _crates = ctld.spawnableCrates[_subMenuName]

                                local _cratePath = missionCommands.addSubMenuForGroup(_groupId, _subMenuName, _rootPath)
                                -- ipairs сохраняет заданный порядок F1…F8. pairs() в Lua
                                -- может переставлять элементы, из-за чего подпись и тип
                                -- вызванного контейнера не совпадали.
                                for _, _crate in ipairs(_crates) do

                                    if ctld.isJTACUnitType(_crate.unit) == false
                                            or (ctld.isJTACUnitType(_crate.unit) == true and ctld.JTAC_dropEnabled) then
                                        if _crate.side == nil or (_crate.side == _unit:getCoalition()) then

                                            local _crateRadioMsg = _crate.desc

                                            -- добавить количество ящиков, требуемых для создания объекта.
                                            if _crate.cratesRequired ~= nil and _crate.cratesRequired > 1 then
                                                _crateRadioMsg = _crateRadioMsg.." [".._crate.cratesRequired.."]"
                                            end

                                            missionCommands.addCommandForGroup(_groupId,_crateRadioMsg, _cratePath, ctld.spawnCrate, { _unitName, _crate.weight })
                                        end
                                    end
                                end
                            end
                        end

                        -- «Меню команд» доступно всем обычным вертолётам.
                        -- У машин без контейнеров в нём остаются только JTAC-команды.
                        do
                            local _crateCommands = missionCommands.addSubMenuForGroup(_groupId, "Меню команд", _rootPath)
                            if ctld.enableCrates and _unitActions.crates then
                                -- Полный комплект распаковывается автоматически через 30 секунд,
                                -- поэтому пилоту нужна только команда выгрузки контейнера.
                                missionCommands.addCommandForGroup(_groupId, "Выгрузить груз", _crateCommands,
                                    ctld.dropSlingCrate, { _unitName })
                                missionCommands.addCommandForGroup(_groupId, "Контейнер рядом", _crateCommands,
                                    ctld.listNearbyCrates, { _unitName })
                            end

                            -- Команды JTAC идут после грузовых команд:
                            -- F1 выгрузка, F2 контейнер рядом, F3 статус, F4 отметка.
                            if ctld.JTAC_jtacStatusF10 then
                                missionCommands.addCommandForGroup(_groupId, "Статус наводчика", _crateCommands,
                                    ctld.getJTACStatus, { _unitName })
                                missionCommands.addCommandForGroup(_groupId, "Обозначить цель", _crateCommands,
                                    ctld.markJTACTargets, { _unitName })
                            end

                        end

                        -- Флаг ставится только после создания всех пунктов. Если DCS не
                        -- добавил один из них, следующий цикл удалит неполное меню и соберёт его заново.
                        ctld.addedTo[tostring(_groupId)] = _unitName
                    end
                end
            else
                -- env.info(string.format("unit nil %s",_unitName))
            end
        end)

        if (not status) then
            env.error(string.format("Error adding f10 to transport: %s", error), false)
        end
    end

    local status, error = pcall(function()

        if ctld.JTAC_jtacStatusF10 then
            -- получить всех игроков синей коалиции.
            ctld.addJTACRadioCommand(2)

            -- получить всех игроков красной коалиции.
            ctld.addJTACRadioCommand(1)
        end

    end)

    if (not status) then
        env.error(string.format("Error adding f10 to other players: %s", error), false)
    end


end

function ctld.addJTACRadioCommand(_side)

    local _players = coalition.getPlayers(_side)

    if _players ~= nil then

        for _, _playerUnit in pairs(_players) do

            local _groupId = ctld.getGroupId(_playerUnit)

            if _groupId then
                local _key = tostring(_groupId)
                local _playerName = _playerUnit:getName()
                local _menuState = ctld.jtacRadioAdded[_key]

                -- У самолётов JTAC-команды являются корневыми пунктами F10:
                -- без CSS-NATO/MTO-RF. У вертолётов они находятся в «Меню команд».
                local _jtacOnlyAircraft = ctld.isPlaneUnit(_playerUnit)
                    or ctld.jtacOnlyAircraftTypes[_playerUnit:getTypeName()]
                if _jtacOnlyAircraft then
                    missionCommands.removeItemForGroup(_groupId, { "CTLD-NATO" })
                    missionCommands.removeItemForGroup(_groupId, { "CTLD-RF" })
                    missionCommands.removeItemForGroup(_groupId, { "CSS-NATO" })
                    missionCommands.removeItemForGroup(_groupId, { "MTO-RF" })
                    missionCommands.removeItemForGroup(_groupId, { "МТО - CTLD" })
                end
                if type(_menuState) ~= "table" or _menuState.unitName ~= _playerName
                        or _menuState.markAvailable ~= nil then
                    missionCommands.removeItemForGroup(_groupId, { "Статус наводчика." })
                    missionCommands.removeItemForGroup(_groupId, { "Обозначить цель." })
                    missionCommands.removeItemForGroup(_groupId, { "Статус наводчика" })
                    missionCommands.removeItemForGroup(_groupId, { "Обозначить цель" })
                    if _jtacOnlyAircraft then
                        missionCommands.removeItemForGroup(_groupId, { "Команды наводчику" })
                        local _jtacCommands = missionCommands.addSubMenuForGroup(_groupId, "Команды наводчику")
                        missionCommands.addCommandForGroup(_groupId, "Запросить координаты", _jtacCommands,
                            ctld.getJTACStatus, { _playerName })
                        missionCommands.addCommandForGroup(_groupId, "Обозначить цель", _jtacCommands,
                            ctld.markJTACTargets, { _playerName })
                    end
                    ctld.jtacRadioAdded[_key] = {
                        unitName = _playerName,
                    }
                end
            end


        end
    end
end

-- Возвращает true, если ПАН этой коалиции удерживает действующую цель лазером.
function ctld.hasActiveJTACTarget(_side)
    for _groupName, _details in pairs(ctld.jtacUnits) do
        if _details.side == _side then
            local _target = ctld.jtacCurrentTargets[_groupName]
            local _unit = _target and Unit.getByName(_target.name)
            if _unit and _unit:isExist() and _unit:isActive() and _unit:getLife() > 0 then
                return true
            end
        end
    end
    return false
end

-- По запросу игрока отмечает дымом все цели, которые сейчас подсвечивают ПАН.
-- Красные используют синий дым, синие -- красный.
function ctld.markJTACTargets(_args)
    local _playerUnit = ctld.getTransportUnit(_args[1])
    if not _playerUnit then return end

    local _side = _playerUnit:getCoalition()
    local _smokeColour = _side == coalition.side.RED and trigger.smokeColor.Blue or trigger.smokeColor.Red
    local _markedTargets = {}
    local _markedCount = 0

    for _groupName, _details in pairs(ctld.jtacUnits) do
        if _details.side == _side then
            local _target = ctld.jtacCurrentTargets[_groupName]
            local _unit = _target and Unit.getByName(_target.name)
            if _unit and _unit:isExist() and _unit:isActive() and _unit:getLife() > 0
                    and not _markedTargets[_unit:getName()] then
                local _point = _unit:getPoint()
                trigger.action.smoke({ x = _point.x, y = _point.y + 2, z = _point.z }, _smokeColour)
                _markedTargets[_unit:getName()] = true
                _markedCount = _markedCount + 1
            end
        end
    end

    local _groupId = ctld.getGroupId(_playerUnit)
    if _groupId then
        local _text = _markedCount > 0 and "Цель обозначена дымом."
            or "Активная цель для наводчика отсутствует."
        trigger.action.outTextForGroup(_groupId, _text, 10)
        trigger.action.outSoundForGroup(_groupId, "switch.wav")
    end
end

function ctld.getGroupId(_unit)

    if not _unit then return nil end
    local _unitDB = mist.DBs.unitsById[tonumber(_unit:getID())]
    if _unitDB ~= nil and _unitDB.groupId then
        return _unitDB.groupId
    end

    -- Динамические слоты могут не попасть в базу MIST. API DCS знает
    -- фактическую группу игрока и работает для обычных и динамических слотов.
    local _group = _unit:getGroup()
    if _group and _group:isExist() then
        return _group:getID()
    end

    return nil
end

-- Получить расстояние в метрах, предполагая плоскую поверхность.
function ctld.getDistance(_point1, _point2)

    local xUnit = _point1.x
    local yUnit = _point1.z
    local xZone = _point2.x
    local yZone = _point2.z

    local xDiff = xUnit - xZone
    local yDiff = yUnit - yZone

    return math.sqrt(xDiff * xDiff + yDiff * yDiff)
end


------------ JTAC -----------


ctld.jtacLaserPoints = {}
ctld.jtacIRPoints = {}
ctld.jtacSmokeMarks = {}
ctld.jtacUnits = {} -- list of JTAC units for f10 command
ctld.jtacStop = {} -- jtacs to tell to stop lasing
ctld.jtacCurrentTargets = {}
ctld.jtacInfantryGroups = {}
ctld.jtacRadioAdded = {} --keeps track of who's had the radio command added
ctld.jtacGeneratedLaserCodes = {} -- keeps track of generated codes, cycles when they run out
ctld.jtacLaserPointCodes = {}
ctld.jtacRadioData = {}

function ctld.JTACAutoLase(_jtacGroupName, _laserCode, _smoke, _lock, _colour, _radio)
    ctld.logDebug(string.format("ctld.JTACAutoLase(_jtacGroupName=%s, _laserCode=%s", ctld.p(_jtacGroupName), ctld.p(_laserCode)))

    -- Автоматическое дымовое обозначение отключено. Дым ставится игроком
    -- только через F10-команду «Обозначить цель.»
    _smoke = false

    local _radio = _radio
    if not _radio then
        _radio = {}
        if _laserCode then
            local _laserCode = tonumber(_laserCode)
            if _laserCode and _laserCode >= 1111 and _laserCode <= 1688 then
                local _laserB = math.floor((_laserCode - 1000)/100)
                local _laserCD = _laserCode - 1000 - _laserB*100
                local _frequency = tostring(30+_laserB+_laserCD*0.05)
                ctld.logTrace(string.format("_laserB=%s", ctld.p(_laserB)))
                ctld.logTrace(string.format("_laserCD=%s", ctld.p(_laserCD)))
                ctld.logTrace(string.format("_frequency=%s", ctld.p(_frequency)))
                _radio.freq = _frequency
                _radio.mod = "fm"
            end        
        end
    end

    if _radio and not _radio.name then
        _radio.name = _jtacGroupName
    end

    if ctld.jtacStop[_jtacGroupName] == true then
        ctld.jtacStop[_jtacGroupName] = nil -- allow it to be started again
        ctld.cleanupJTAC(_jtacGroupName)
        return
    end

    if _lock == nil then

        _lock = ctld.JTAC_lock
    end


    ctld.jtacLaserPointCodes[_jtacGroupName] = _laserCode
    ctld.jtacRadioData[_jtacGroupName] = _radio

    local _jtacGroup = ctld.getGroup(_jtacGroupName)
    local _jtacUnit

    if _jtacGroup == nil or #_jtacGroup == 0 then

        -- проверить, что юнит не находится в вертолёте.
        if ctld.inTransitTroops then
            for _, _onboard in pairs(ctld.inTransitTroops) do
                if _onboard ~= nil then
                    if _onboard.troops ~= nil and _onboard.troops.groupName ~= nil and _onboard.troops.groupName == _jtacGroupName then

                        -- солдат JTAC перевозится вертолётом.
                        ctld.cleanupJTAC(_jtacGroupName)

                        env.info(_jtacGroupName .. ' in Transport - Waiting 10 seconds')
                        timer.scheduleFunction(ctld.timerJTACAutoLase, { _jtacGroupName, _laserCode, _smoke, _lock, _colour, _radio }, timer.getTime() + 10)
                        return
                    end

                    if _onboard.vehicles ~= nil and _onboard.vehicles.groupName ~= nil and _onboard.vehicles.groupName == _jtacGroupName then
                        -- машина JTAC перевозится вертолётом.
                        ctld.cleanupJTAC(_jtacGroupName)

                        env.info(_jtacGroupName .. ' in Transport - Waiting 10 seconds')
                        timer.scheduleFunction(ctld.timerJTACAutoLase, { _jtacGroupName, _laserCode, _smoke, _lock, _colour, _radio }, timer.getTime() + 10)
                        return
                    end
                end
            end
        end


        if ctld.jtacUnits[_jtacGroupName] ~= nil and not ctld.jtacInfantryGroups[_jtacGroupName] then
            ctld.notifyCoalition("ПАН " .. _jtacGroupName .. " уничтожен!", 10, ctld.jtacUnits[_jtacGroupName].side, _radio)
        end

        if ctld.jtacInfantryGroups[_jtacGroupName] then
            local _side = ctld.jtacUnits[_jtacGroupName] and ctld.jtacUnits[_jtacGroupName].side
            if _side then
                ctld.notifyInfantryTaskFailed(_side, "ПАН разведчик")
            end
            ctld.jtacInfantryGroups[_jtacGroupName] = nil
        end

        -- удалить из списка.
        ctld.jtacUnits[_jtacGroupName] = nil

        ctld.cleanupJTAC(_jtacGroupName)

        return
    else

        _jtacUnit = _jtacGroup[1]
        -- добавить в список.
        ctld.jtacUnits[_jtacGroupName] = { name = _jtacUnit:getName(), side = _jtacUnit:getCoalition(), radio = _radio }

        -- определить цвет дыма.
        if _colour == nil then

            if _jtacUnit:getCoalition() == 1 then
                _colour = ctld.JTAC_smokeColour_RED
            else
                _colour = ctld.JTAC_smokeColour_BLUE
            end
        end


        if _smoke == nil then

            if _jtacUnit:getCoalition() == 1 then
                _smoke = ctld.JTAC_smokeOn_RED
            else
                _smoke = ctld.JTAC_smokeOn_BLUE
            end
        end
    end


    -- поиск текущего юнита.

    if _jtacUnit:isActive() == false then

        ctld.cleanupJTAC(_jtacGroupName)

        env.info(_jtacGroupName .. ' Not Active - Waiting 30 seconds')
        timer.scheduleFunction(ctld.timerJTACAutoLase, { _jtacGroupName, _laserCode, _smoke, _lock, _colour, _radio }, timer.getTime() + 30)

        return
    end

    local _enemyUnit = ctld.getCurrentUnit(_jtacUnit, _jtacGroupName)
    local targetDestroyed = false
    local targetLost = false

    if _enemyUnit == nil and ctld.jtacCurrentTargets[_jtacGroupName] ~= nil then

        local _tempUnitInfo = ctld.jtacCurrentTargets[_jtacGroupName]

        --      env.info("TEMP UNIT INFO: " .. tempUnitInfo.name .. " " .. tempUnitInfo.unitType)

        local _tempUnit = Unit.getByName(_tempUnitInfo.name)

        if _tempUnit ~= nil and _tempUnit:getLife() > 0 and _tempUnit:isActive() == true then
            targetLost = true
        else
            targetDestroyed = true
        end

        -- удалить из списка дыма.
        ctld.jtacSmokeMarks[_tempUnitInfo.name] = nil

	    -- Юнит JTAC: цель уничтожена/потеряна — продолжить маршрут поиска.
        local _jtacGroundGroup = Group.getByName(_jtacGroupName)
        if _jtacGroundGroup and _jtacGroundGroup:isExist() then
            pcall(function() trigger.action.groupContinueMoving(_jtacGroundGroup) end)
        end

        -- удалить из списка целей.
        ctld.jtacCurrentTargets[_jtacGroupName] = nil

        -- прекратить подсветку лазером.
        ctld.cancelLase(_jtacGroupName)

        if ctld.jtacInfantryGroups[_jtacGroupName] then
            local _prefix = _jtacUnit:getCoalition() == coalition.side.BLUE and "CSS" or "МТО"
            ctld.notifySwitchCoalition(_jtacUnit:getCoalition(),
                _prefix .. ": Разведчик - цели не наблюдаю. Начал поиск.")
        end
    end


    if _enemyUnit == nil then
        _enemyUnit = ctld.findNearestVisibleEnemy(_jtacUnit, _lock)

        if _enemyUnit ~= nil then

            -- сохранить текущую цель для быстрого поиска.
            ctld.jtacCurrentTargets[_jtacGroupName] = { name = _enemyUnit:getName(), unitType = _enemyUnit:getTypeName(), unitId = _enemyUnit:getID() }

            local _frequency = "не задана"
            local _modulation = "FM"
            if _radio then
                _frequency = tostring(_radio.freq or "не задана")
                _modulation = tostring(_radio.mod or "FM")
            end

            local _position = ctld.getPositionString(_enemyUnit)
            if _position == "" then _position = "недоступны" end
            _position = string.gsub(_position, "^%s*@%s*", "")

            local _statusMessage = table.concat({
                "Статус наводчика:",
                "Вижу визуально: " .. _enemyUnit:getTypeName(),
                "Частота: " .. _frequency .. " " .. _modulation .. ",",
                "Код лазера: " .. tostring(_laserCode),
                "Координаты: " .. _position,
                "------------------",
            }, "\n")
            ctld.notifySwitchCoalition(_jtacUnit:getCoalition(),
                ctld.coalitionText(_jtacUnit:getCoalition(), _statusMessage), 20)

            -- Наземный JTAC обязан остановиться сразу после обнаружения
            -- цели. Повторное удержание ниже не даёт другому циклу ИИ
            -- снова запустить маршрут до уничтожения цели.
            local _jtacGroundGroup = Group.getByName(_jtacGroupName)
            if _jtacGroundGroup and _jtacGroundGroup:isExist() then
                pcall(function() trigger.action.groupStopMoving(_jtacGroundGroup) end)
            end
            
            -- создать дым.
            if _smoke == true then

                -- создать первый дымовой маркер.
                ctld.createSmokeMarker(_enemyUnit, _colour)
            end
        end
    end

    if _enemyUnit ~= nil then

        ctld.laseUnit(_enemyUnit, _jtacUnit, _jtacGroupName, _laserCode)

        --   env.info('Timer timerSparkleLase '..jtacGroupName.." "..laserCode.." "..enemyUnit:getName())
        timer.scheduleFunction(ctld.timerJTACAutoLase, { _jtacGroupName, _laserCode, _smoke, _lock, _colour, _radio }, timer.getTime() + 15)


        if _smoke == true then
            local _nextSmokeTime = ctld.jtacSmokeMarks[_enemyUnit:getName()]

            -- создать дымовой маркер заново через 5 минут.
            if _nextSmokeTime ~= nil and _nextSmokeTime < timer.getTime() then

                ctld.createSmokeMarker(_enemyUnit, _colour)
            end
        end

    else
        -- env.info('LASE: No Enemies Nearby')

        -- прекратить лазерную подсветку прежней точки.
        ctld.cancelLase(_jtacGroupName)
        --  env.info('Timer Slow timerSparkleLase '..jtacGroupName.." "..laserCode.." "..enemyUnit:getName())

        timer.scheduleFunction(ctld.timerJTACAutoLase, { _jtacGroupName, _laserCode, _smoke, _lock, _colour, _radio }, timer.getTime() + 5)
    end

    if targetLost then
        ctld.notifyCoalition(_jtacGroupName .. ", Цель потерял!", 10, _jtacUnit:getCoalition(), _radio)
    elseif targetDestroyed then
        ctld.notifyCoalition(_jtacGroupName .. ", Цель уничтожена!", 10, _jtacUnit:getCoalition(), _radio)
    end
end

function ctld.JTACAutoLaseStop(_jtacGroupName)
    ctld.jtacStop[_jtacGroupName] = true
end

-- Используется функцией таймера.
function ctld.timerJTACAutoLase(_args)

    ctld.JTACAutoLase(_args[1], _args[2], _args[3], _args[4], _args[5], _args[6])
end

function ctld.cleanupJTAC(_jtacGroupName)
    -- очистить лазер на всякий случай.
    ctld.cancelLase(_jtacGroupName)

    -- очистка.
    ctld.jtacUnits[_jtacGroupName] = nil

    ctld.jtacCurrentTargets[_jtacGroupName] = nil

    ctld.jtacLaserPointCodes[_jtacGroupName] = nil

    ctld.jtacRadioData[_jtacGroupName] = nil
end


--- Отправляет сообщение коалиции.
--- Если задан _radio, сообщение будет озвучено через SRS.
function ctld.coalitionText(_side, _message)
    local _prefix = _side == coalition.side.BLUE and "CSS" or "МТО"
    return _prefix .. ": " .. _message
end

function ctld.notifySwitchCoalition(_side, _message, _duration)
    trigger.action.outTextForCoalition(_side, _message, _duration or 10)
    trigger.action.outSoundForCoalition(_side, "switch.wav")
end

function ctld.notifyInfantryTaskFailed(_side, _taskName)
    if not _side then return end
    local _text = "Пехота задачу не выполнила. Задача сорвана."
    if _taskName == "Минометная батарея" then
        _text = "Минометная батарея уничтожена. Задача сорвана."
    elseif _taskName == "ПАН разведчик" or _taskName == "Разведчик JTAC" then
        _text = "Разведчик уничтожен. Задача сорвана."
    end
    ctld.notifySwitchCoalition(_side, ctld.coalitionText(_side, _text), 12)
end

function ctld.notifySpotterWorkCoalition(_side, _message)
    trigger.action.outTextForCoalition(_side, _message, 10)
    trigger.action.outSoundForCoalition(_side, "spotter_ work.ogg")
end

-- Запускает ПАН после появления группы. Задержка нужна, чтобы DCS успел
-- зарегистрировать высаженную пехоту или распакованную JTAC-технику.
function ctld.activateJTACAfterDelay(_args)
    if not _args or not _args.groupName then return nil end

    local _group = Group.getByName(_args.groupName)
    if not _group or not _group:isExist() then return nil end

    ctld.JTACAutoLase(_args.groupName, _args.laserCode)
    ctld.notifySpotterWorkCoalition(_args.side,
        ctld.coalitionText(_args.side, "Разведчик в работе. Выхожу на цель."))
    return nil
end

function ctld.notifyCoalition(_message, _displayFor, _side, _radio, _shortMessage)
    ctld.logDebug(string.format("ctld.notifyCoalition(_message=%s)", ctld.p(_message)))
    ctld.logTrace(string.format("_radio=%s", ctld.p(_radio)))

    local _shortMessage = _shortMessage
    if _shortMessage == nil then 
        _shortMessage = _message
    end
    
    if STTS and STTS.TextToSpeech and _radio and _radio.freq then
        local _freq = _radio.freq
        local _modulation = _radio.mod or "FM"
        local _volume = _radio.volume or "1.0"
        local _name = _radio.name or "JTAC"
        local _gender = _radio.gender or "male"
        local _culture = _radio.culture or "en-US"
        local _voice = _radio.voice
        local _googleTTS = _radio.googleTTS or false
        ctld.logTrace(string.format("calling STTS.TextToSpeech(%s)", ctld.p(_shortMessage)))
        ctld.logTrace(string.format("_freq=%s", ctld.p(_freq)))
        ctld.logTrace(string.format("_modulation=%s", ctld.p(_modulation)))
        ctld.logTrace(string.format("_volume=%s", ctld.p(_volume)))
        ctld.logTrace(string.format("_name=%s", ctld.p(_name)))
        ctld.logTrace(string.format("_gender=%s", ctld.p(_gender)))
        ctld.logTrace(string.format("_culture=%s", ctld.p(_culture)))
        ctld.logTrace(string.format("_voice=%s", ctld.p(_voice)))
        ctld.logTrace(string.format("_googleTTS=%s", ctld.p(_googleTTS)))
        STTS.TextToSpeech(_shortMessage, _freq, _modulation, _volume, _name, _side, nil, 1, _gender, _culture, _voice, _googleTTS)
    end

    trigger.action.outTextForCoalition(_side, _message, _displayFor)
    trigger.action.outSoundForCoalition(_side, "radiobeep.ogg")
end

function ctld.createSmokeMarker(_enemyUnit, _colour)

    -- создать заново через 5 минут.
    ctld.jtacSmokeMarks[_enemyUnit:getName()] = timer.getTime() + 300.0

    -- разместить дым на 2 м выше цели для удобства.
    local _enemyPoint = _enemyUnit:getPoint()
    trigger.action.smoke({ x = _enemyPoint.x, y = _enemyPoint.y + 2.0, z = _enemyPoint.z }, _colour)
end

function ctld.cancelLase(_jtacGroupName)

    --local index = "JTAC_"..jtacUnit:getID()

    local _tempLase = ctld.jtacLaserPoints[_jtacGroupName]

    if _tempLase ~= nil then
        Spot.destroy(_tempLase)
        ctld.jtacLaserPoints[_jtacGroupName] = nil

        --      env.info('Destroy laze  '..index)

        _tempLase = nil
    end

    local _tempIR = ctld.jtacIRPoints[_jtacGroupName]

    if _tempIR ~= nil then
        Spot.destroy(_tempIR)
        ctld.jtacIRPoints[_jtacGroupName] = nil

        --  env.info('Destroy laze  '..index)

        _tempIR = nil
    end
end

function ctld.laseUnit(_enemyUnit, _jtacUnit, _jtacGroupName, _laserCode)

    --cancelLase(jtacGroupName)

    local _spots = {}

    local _enemyVector = _enemyUnit:getPoint()
    local _enemyVectorUpdated = { x = _enemyVector.x, y = _enemyVector.y + 2.0, z = _enemyVector.z }

    local _oldLase = ctld.jtacLaserPoints[_jtacGroupName]
    local _oldIR = ctld.jtacIRPoints[_jtacGroupName]

    if _oldLase == nil or _oldIR == nil then

        -- создать лазерную подсветку.

        local _status, _result = pcall(function()
            _spots['irPoint'] = Spot.createInfraRed(_jtacUnit, { x = 0, y = 2.0, z = 0 }, _enemyVectorUpdated)
            _spots['laserPoint'] = Spot.createLaser(_jtacUnit, { x = 0, y = 2.0, z = 0 }, _enemyVectorUpdated, _laserCode)
            return _spots
        end)

        if not _status then
            env.error('ERROR: ' .. _result, false)
        else
            if _result.irPoint then

                --    env.info(jtacUnit:getName() .. ' placed IR Pointer on '..enemyUnit:getName())

                ctld.jtacIRPoints[_jtacGroupName] = _result.irPoint --store so we can remove after
            end
            if _result.laserPoint then

                --  env.info(jtacUnit:getName() .. ' is Lasing '..enemyUnit:getName()..'. CODE:'..laserCode)

                ctld.jtacLaserPoints[_jtacGroupName] = _result.laserPoint
            end
        end

    else

        -- обновить лазерную подсветку.

        if _oldLase ~= nil then
            _oldLase:setPoint(_enemyVectorUpdated)
        end

        if _oldIR ~= nil then
            _oldIR:setPoint(_enemyVectorUpdated)
        end
    end
end

-- Получить текущий выбранный юнит и проверить, остаётся ли он в радиусе действия.
function ctld.getCurrentUnit(_jtacUnit, _jtacGroupName)


    local _unit = nil

    if ctld.jtacCurrentTargets[_jtacGroupName] ~= nil then
        _unit = Unit.getByName(ctld.jtacCurrentTargets[_jtacGroupName].name)
    end

    local _tempPoint = nil
    local _tempDist = nil
    local _tempPosition = nil

    local _jtacPosition = _jtacUnit:getPosition()
    local _jtacPoint = _jtacUnit:getPoint()

    if _unit ~= nil and _unit:getLife() > 0 and _unit:isActive() == true then

        -- вычислить расстояние.
        _tempPoint = _unit:getPoint()
        --   tempPosition = unit:getPosition()

        _tempDist = ctld.getDistance(_unit:getPoint(), _jtacUnit:getPoint())
        if _tempDist < ctld.JTAC_maxDistance then
            -- проверить видимость.

            -- проверять немного выше цели: ошибки округления и высота юнита могут влиять на результат.
            local _offsetEnemyPos = { x = _tempPoint.x, y = _tempPoint.y + 2.0, z = _tempPoint.z }
            local _offsetJTACPos = { x = _jtacPoint.x, y = _jtacPoint.y + 2.0, z = _jtacPoint.z }

            if land.isVisible(_offsetEnemyPos, _offsetJTACPos) then
                return _unit
            end
        end
    end
    return nil
end


-- Найти ближайшего к JTAC противника, не закрытого рельефом.
function ctld.findNearestVisibleEnemy(_jtacUnit, _targetType,_distance)

    --local startTime = os.clock()

    local _maxDistance = _distance or ctld.JTAC_maxDistance

    local _nearestDistance = _maxDistance

    local _jtacPoint = _jtacUnit:getPoint()
    local _coa =    _jtacUnit:getCoalition()

    local _offsetJTACPos = { x = _jtacPoint.x, y = _jtacPoint.y + 2.0, z = _jtacPoint.z }

    local _volume = {
        id = world.VolumeType.SPHERE,
        params = {
            point = _offsetJTACPos,
            radius = _maxDistance
        }
    }

    local _unitList = {}


    local _search = function(_unit, _coa)
        pcall(function()

            if _unit ~= nil
                    and _unit:getLife() > 0
                    and _unit:isActive()
                    and _unit:getCoalition() ~= _coa
                    and not _unit:inAir()
                    and not ctld.alreadyTarget(_jtacUnit,_unit) then

                local _tempPoint = _unit:getPoint()
                local _offsetEnemyPos = { x = _tempPoint.x, y = _tempPoint.y + 2.0, z = _tempPoint.z }

                if land.isVisible(_offsetJTACPos,_offsetEnemyPos ) then

                    local _dist = ctld.getDistance(_offsetJTACPos, _offsetEnemyPos)

                    if _dist < _maxDistance then
                        table.insert(_unitList,{unit=_unit, dist=_dist})

                    end
                end
            end
        end)

        return true
    end

    world.searchObjects(Object.Category.UNIT, _volume, _search, _coa)

    --log.info(string.format("JTAC Search elapsed time: %.4f\n", os.clock() - startTime))

    -- сформировать список по дальности и видимости.

    -- первая проверка.
    -- высокий приоритет.
    -- приоритет.
    -- техника.
    -- юнит.

    local _sort = function( a,b ) return a.dist < b.dist end
    table.sort(_unitList,_sort)
    -- отсортировать список.

    -- проверить высокий приоритет.
    for _, _enemyUnit in ipairs(_unitList) do
        local _enemyName = _enemyUnit.unit:getName()

        if string.match(_enemyName, "hpriority") then
            return _enemyUnit.unit
        end
    end

    for _, _enemyUnit in ipairs(_unitList) do
        local _enemyName = _enemyUnit.unit:getName()

        if string.match(_enemyName, "priority") then
            return _enemyUnit.unit
        end
    end

    local result = nil
    for _, _enemyUnit in ipairs(_unitList) do
        local _enemyName = _enemyUnit.unit:getName()
        --log.info(string.format("CTLD - checking _enemyName=%s", _enemyName))

        -- проверить средства ПВО.
        --log.info(string.format("CTLD - _enemyUnit.unit:getDesc()[attributes]=%s", ctld.p(_enemyUnit.unit:getDesc()["attributes"])))
        local airdefense = (_enemyUnit.unit:getDesc()["attributes"]["Air Defence"] ~= nil)
        --log.info(string.format("CTLD - airdefense=%s", tostring(airdefense)))

        if (_targetType == "vehicle" and ctld.isVehicle(_enemyUnit.unit)) or _targetType == "all" then
            if airdefense then
                return _enemyUnit.unit
            else
                result = _enemyUnit.unit
            end

        elseif (_targetType == "troop" and ctld.isInfantry(_enemyUnit.unit)) or _targetType == "all" then
            if airdefense then
                return _enemyUnit.unit
            else
                result = _enemyUnit.unit
            end
        end
    end

    return result

end


function ctld.listNearbyEnemies(_jtacUnit)

    local _maxDistance =  ctld.JTAC_maxDistance

    local _jtacPoint = _jtacUnit:getPoint()
    local _coa =    _jtacUnit:getCoalition()

    local _offsetJTACPos = { x = _jtacPoint.x, y = _jtacPoint.y + 2.0, z = _jtacPoint.z }

    local _volume = {
        id = world.VolumeType.SPHERE,
        params = {
            point = _offsetJTACPos,
            radius = _maxDistance
        }
    }
    local _enemies = nil

    local _search = function(_unit, _coa)
        pcall(function()

            if _unit ~= nil
                    and _unit:getLife() > 0
                    and _unit:isActive()
                    and _unit:getCoalition() ~= _coa
                    and not _unit:inAir() then

                local _tempPoint = _unit:getPoint()
                local _offsetEnemyPos = { x = _tempPoint.x, y = _tempPoint.y + 2.0, z = _tempPoint.z }

                if land.isVisible(_offsetJTACPos,_offsetEnemyPos ) then

                    if not _enemies then
                        _enemies = {}
                    end

                    _enemies[_unit:getTypeName()] = _unit:getTypeName()

                end
            end
        end)

        return true
    end

    world.searchObjects(Object.Category.UNIT, _volume, _search, _coa)

    return _enemies
end

-- Проверяет, является ли юнит целью другого JTAC.
function ctld.alreadyTarget(_jtacUnit, _enemyUnit)

    for _, _jtacTarget in pairs(ctld.jtacCurrentTargets) do

        if _jtacTarget.unitId == _enemyUnit:getID() then
            -- env.info("ALREADY TARGET")
            return true
        end
    end

    return false
end


-- Возвращает только живые юниты группы, однако сама группа / юнит может быть неактивна.

function ctld.getGroup(groupName)

    local _groupUnits = Group.getByName(groupName)

    local _filteredUnits = {} --contains alive units
    local _x = 1

    if _groupUnits ~= nil and _groupUnits:isExist() then

        _groupUnits = _groupUnits:getUnits()

        if _groupUnits ~= nil and #_groupUnits > 0 then
            for _x = 1, #_groupUnits do
                if _groupUnits[_x]:getLife() > 0  then -- removed and _groupUnits[_x]:isExist() as isExist doesnt work on single units!
                table.insert(_filteredUnits, _groupUnits[_x])
                end
            end
        end
    end

    return _filteredUnits
end

function ctld.getAliveGroup(_groupName)

    local _group = Group.getByName(_groupName)

    if _group and _group:isExist() == true and #_group:getUnits() > 0 then
        return _group
    end

    return nil
end

-- Получает статус JTAC и выводит его только вызвавшей группе.
function ctld.getJTACStatus(_args)
    local _playerUnit = ctld.getTransportUnit(_args[1])

    if _playerUnit == nil then
        return
    end

    local _side = _playerUnit:getCoalition()
    local _messageParts = { "Статус наводчика:" }
    local _hasStatus = false

    for _jtacGroupName, _jtacDetails in pairs(ctld.jtacUnits) do
        local _jtacUnit = Unit.getByName(_jtacDetails.name)

        if _jtacUnit ~= nil and _jtacUnit:getLife() > 0 and _jtacUnit:isActive()
                and _jtacUnit:getCoalition() == _side then
            _hasStatus = true
            local _enemyUnit = ctld.getCurrentUnit(_jtacUnit, _jtacGroupName)

            if _enemyUnit ~= nil and _enemyUnit:getLife() > 0 and _enemyUnit:isActive() then
                local _laserCode = ctld.jtacLaserPointCodes[_jtacGroupName] or "UNKNOWN"
                local _frequency = "не задана"
                local _modulation = "FM"
                if _jtacDetails.radio then
                    _frequency = tostring(_jtacDetails.radio.freq or "не задана")
                    _modulation = tostring(_jtacDetails.radio.mod or "FM")
                end

                local _position = ctld.getPositionString(_enemyUnit)
                if _position == "" then _position = "недоступны" end
                _position = string.gsub(_position, "^%s*@%s*", "")

                table.insert(_messageParts, "Вижу визуально: " .. _enemyUnit:getTypeName())
                table.insert(_messageParts, "Частота: " .. _frequency .. " " .. _modulation)
                table.insert(_messageParts, "Код лазера: " .. tostring(_laserCode))
                table.insert(_messageParts, "Координаты: " .. _position)
                table.insert(_messageParts, "------------------")
            else
                table.insert(_messageParts, "Веду поиск цели.")
                table.insert(_messageParts, "------------------")
            end
        end
    end

    if not _hasStatus then
        table.insert(_messageParts, "Нет активного наводчика.")
        table.insert(_messageParts, "------------------")
    end

    local _groupId = ctld.getGroupId(_playerUnit)
    if _groupId then
        trigger.action.outTextForGroup(_groupId, table.concat(_messageParts, "\n"), 20)
        trigger.action.outSoundForGroup(_groupId, "switch.wav")
    end
end



function ctld.isInfantry(_unit)

    local _typeName = _unit:getTypeName()

    -- привести тип к строке.
    _typeName = string.lower(_typeName .. "")

    local _soldierType = { "infantry", "paratrooper", "stinger", "manpad", "mortar" }

    for _key, _value in pairs(_soldierType) do
        if string.match(_typeName, _value) then
            return true
        end
    end

    return false
end

-- Считать, что всё, что не является солдатом, — техника.
function ctld.isVehicle(_unit)

    if ctld.isInfantry(_unit) then
        return false
    end

    return true
end

-- Вводимое значение может быть в диапазоне 1111–1788,
-- но первая цифра серии должна быть 1 или 2,
-- а последние три цифры должны быть от 1 до 8.
-- Раньше диапазон работал с ошибкой: использовались не 1–8, а 0–7.
-- Поэтому функция ниже использует диапазон 1–7.
function ctld.generateLaserCode()

    ctld.jtacGeneratedLaserCodes = {}

    -- сгенерировать список лазерных кодов.
    local _code = 1111

    local _count = 1

    while _code < 1777 and _count < 30 do

        while true do

            _code = _code + 1

            if not ctld.containsDigit(_code, 8)
                    and not ctld.containsDigit(_code, 9)
                    and not ctld.containsDigit(_code, 0) then

                table.insert(ctld.jtacGeneratedLaserCodes, _code)

                --env.info(_code.." Code")
                break
            end
        end
        _count = _count + 1
    end
end

function ctld.containsDigit(_number, _numberToFind)

    local _thisNumber = _number
    local _thisDigit = 0

    while _thisNumber ~= 0 do

        _thisDigit = _thisNumber % 10
        _thisNumber = math.floor(_thisNumber / 10)

        if _thisDigit == _numberToFind then
            return true
        end
    end

    return false
end

-- 200 - 400 in 10KHz
-- 400 - 850 in 10 KHz
-- 850 - 1250 in 50 KHz
function ctld.getPositionString(_unit)

    if ctld.JTAC_location == false then
        return ""
    end

    local _lat, _lon = coord.LOtoLL(_unit:getPosition().p)

    local _latLngStr = mist.tostringLL(_lat, _lon, 3, ctld.location_DMS)

    local _mgrsString = mist.tostringMGRS(coord.LLtoMGRS(coord.LOtoLL(_unit:getPosition().p)), 5)

    return " @ " .. _latLngStr .. " - MGRS " .. _mgrsString
end


-- ***************** НАСТРОЙКА СКРИПТА ****************
function ctld.initialize(force)
    ctld.logInfo(string.format("Initializing version %s", ctld.Version))
    ctld.logTrace(string.format("ctld.alreadyInitialized=%s", ctld.p(ctld.alreadyInitialized)))
    ctld.logTrace(string.format("force=%s", ctld.p(force)))

    if ctld.alreadyInitialized and not force then
        ctld.logInfo(string.format("Bypassing initialization because ctld.alreadyInitialized = true"))
        return
    end

    assert(mist ~= nil, "\n\n** HEY MISSION-DESIGNER! **\n\nMiST has not been loaded!\n\nMake sure MiST 3.6 or higher is running\n*before* running this script!\n")

    ctld.addedTo = {}
    ctld.spawnedCratesRED = {} -- хранит созданные ящики
    ctld.spawnedCratesBLUE = {} -- хранит созданные ящики

    ctld.droppedTroopsRED = {} -- хранит выгруженные группы пехоты
    ctld.droppedTroopsBLUE = {} -- хранит выгруженные группы пехоты

    ctld.inTransitTroops = {}

    ctld.inTransitSlingLoadCrates = {} -- хранит ящики, перевозимые вертолётами вместо штатной внешней подвески
    ctld.transportCargoUnitIds = {} -- идентификаторы объектов транспорта для сброса груза после респауна слота

    ctld.completeAASystems = {} -- хранит собранные группы из нескольких ящиков

    -- используется для определения содержимого ящика.
    ctld.crateLookupTable = {}

    ctld.missionEditorCargoCrates = {} -- ящики редактора миссий для условия cratesInZone
    ctld.hoverStatus = {} -- отслеживает зависание вертолёта над ящиком

    ctld.callbacks = {} -- функции обратного вызова


    -- удалить войска в пути при уничтожении вертолёта / транспортного самолёта.
    --ctld.eventHandler = {}
    --function ctld.eventHandler:onEvent(_event)
    --
    --    if _event == nil or _event.initiator == nil then
    --        env.info("CTLD null event")
    --    elseif _event.id == 9 then
    --        -- Пилот погиб
    --        ctld.inTransitTroops[_event.initiator:getName()] = nil
    --
    --    elseif world.event.S_EVENT_EJECTION == _event.id or _event.id == 8 then
    --        -- env.info("Event unit - Pilot Ejected or Unit Dead")
    --        ctld.inTransitTroops[_event.initiator:getName()] = nil
    --
    --        -- env.info(_event.initiator:getName())
    --    end
    --
    --end

    -- создать таблицу поиска ящиков.
    for _subMenuName, _crates in pairs(ctld.spawnableCrates) do

        for _, _crate in pairs(_crates) do
            -- преобразовать число в строку, иначе получится бессмысленно большая таблица.
            -- строка работает как «хеш-таблица» и содержит только нужное число элементов.
            ctld.crateLookupTable[tostring(_crate.weight)] = _crate
        end
    end


    -- обработать зоны погрузки.
    for _, _zone in pairs(ctld.pickupZones) do

        local _zoneName = _zone[1]
        local _zoneColor = _zone[2]
        local _zoneActive = _zone[4]

        if _zoneColor == "green" then
            _zone[2] = trigger.smokeColor.Green
        elseif _zoneColor == "red" then
            _zone[2] = trigger.smokeColor.Red
        elseif _zoneColor == "white" then
            _zone[2] = trigger.smokeColor.White
        elseif _zoneColor == "orange" then
            _zone[2] = trigger.smokeColor.Orange
        elseif _zoneColor == "blue" then
            _zone[2] = trigger.smokeColor.Blue
        else
            _zone[2] = -1 -- дым не используется
        end

        -- добавить счётчик для войск или юнитов.
        if _zone[3] == -1 then
            _zone[3] = 10000;
        end

        -- изменить флаг активности на 1 / 0.
        if _zoneActive == "yes" then
            _zone[4] = 1
        else
            _zone[4] = 0
        end
    end

    -- добавить общий счётчик.

    for _,_loadGroup in pairs(ctld.loadableGroups) do

        _loadGroup.total = 0
        if _loadGroup.aa then
            _loadGroup.total = _loadGroup.aa + _loadGroup.total
        end

        if _loadGroup.inf then
            _loadGroup.total = _loadGroup.inf + _loadGroup.total
        end


        if _loadGroup.mg then
            _loadGroup.total = _loadGroup.mg + _loadGroup.total
        end

        if _loadGroup.at then
            _loadGroup.total = _loadGroup.at + _loadGroup.total
        end

        if _loadGroup.mortar then
            _loadGroup.total = _loadGroup.mortar + _loadGroup.total
        end

    end


    -- Периодические задачи запускаются один раз. Повторная инициализация
    -- обновляет таблицы CTLD, но не дублирует фоновые циклы.
    if not ctld.backgroundLoopsStarted then
        ctld.backgroundLoopsStarted = true
        timer.scheduleFunction(function()

            timer.scheduleFunction(ctld.refreshSmoke, nil, timer.getTime() + 5)
            timer.scheduleFunction(ctld.addF10MenuOptions, nil, timer.getTime() + 5)

            if ctld.enableCrates == true and ctld.slingLoad == false and ctld.hoverPickup == true then
                timer.scheduleFunction(ctld.checkHoverStatus, nil, timer.getTime() + 1)
            end

        end,nil, timer.getTime()+1 )
    end

    -- Обработчик гибели групп, созданных CTLD, также регистрируется один раз.
    if not ctld.generatedCombatHandlerRegistered then
        world.addEventHandler(ctld.generatedCombatEventHandler)
        ctld.generatedCombatHandlerRegistered = true
    end

    --env.info("CTLD event handler added")

    env.info("Generating Laser Codes")
    ctld.generateLaserCode()
    env.info("Generated Laser Codes")



    -- поиск ящиков.
    -- По неизвестной причине ящики не возвращаются coalition.getStaticObjects().
    -- Вместо этого искать ящики в редакторе миссий.
    env.info("Searching for Crates")
    for _coalitionName, _coalitionData in pairs(env.mission.coalition) do

        if (_coalitionName == 'red' or _coalitionName == 'blue')
                and type(_coalitionData) == 'table' then
            if _coalitionData.country then --there is a country table
            for _, _countryData in pairs(_coalitionData.country) do

                if type(_countryData) == 'table' then
                    for _objectTypeName, _objectTypeData in pairs(_countryData) do
                        if _objectTypeName == "static" then

                            if ((type(_objectTypeData) == 'table')
                                    and _objectTypeData.group
                                    and (type(_objectTypeData.group) == 'table')
                                    and (#_objectTypeData.group > 0)) then

                                for _groupId, _group in pairs(_objectTypeData.group) do
                                    if _group and _group.units and type(_group.units) == 'table' then
                                        for _unitNum, _unit in pairs(_group.units) do
                                            if _unit.canCargo == true then
                                                local _cargoName = env.getValueDictByKey(_unit.name)
                                                ctld.missionEditorCargoCrates[_cargoName] = _cargoName
                                                env.info("Crate Found: " .. _unit.name.." - Unit: ".._cargoName)
                                            end
                                        end
                                    end
                                end
                            end
                        end
                    end
                end
            end
            end
        end
    end
    env.info("END search for crates")

    -- не инициализировать более одного раза.
    ctld.alreadyInitialized = true

    env.info("CTLD READY")
end


-- Инициализировать генератор случайных чисел для большей случайности.
math.random(); math.random(); math.random()

--- Включить/выключить окна ошибок, отображаемые на экране.
env.setErrorMessageBoxEnabled(false)

-- Инициализировать CTLD через 2 секунды, чтобы другие скрипты успели изменить настройки до запуска.
ctld.logInfo(string.format("Loading version %s in 2 seconds", ctld.Version))
timer.scheduleFunction(ctld.initialize, nil, timer.getTime() + 2)

-- ОТЛАДОЧНАЯ ФУНКЦИЯ
--        for key, value in pairs(getmetatable(_spawnedCrate)) do
--            env.info(tostring(key))
--            env.info(tostring(value))
--        end
